<?php

declare(strict_types=1);

require_once __DIR__ . '/includes/api_bootstrap.php';
require_once __DIR__ . '/includes/checkout_service.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Allow: POST');
    json_error('Método no permitido.', 405);
}

$isJsonRequest = stripos((string) ($_SERVER['HTTP_ACCEPT'] ?? ''), 'application/json') !== false
    || strtolower((string) ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '')) === 'xmlhttprequest';

$data = request_data();
require_csrf($data);

$user = require_api_auth();
$userId = (int) $user['id_usuario'];

$metodoRecibido = strtolower(trim((string) ($data['metodo_pago'] ?? '')));
$metodosPermitidos = [
    'tarjeta' => 'tarjeta',
    'tarjeta_credito' => 'tarjeta',
    'tarjeta_debito' => 'tarjeta',
    'card' => 'tarjeta',
    'paypal' => 'paypal',
    'yape' => 'yape',
];

if (!isset($metodosPermitidos[$metodoRecibido])) {
    if ($isJsonRequest) {
        json_error('Selecciona un método de pago válido.', 422);
    }

    $_SESSION['checkout_error'] = 'Selecciona un método de pago válido.';
    header('Location: checkout.php', true, 303);
    exit;
}

$metodoPago = $metodosPermitidos[$metodoRecibido];

try {
    $resultado = procesar_compra_simulada(db(), $userId, $metodoPago);
} catch (CheckoutException $exception) {
    if ($isJsonRequest) {
        json_error($exception->getMessage(), $exception->statusCode());
    }

    $_SESSION['checkout_error'] = $exception->getMessage();
    header('Location: checkout.php', true, 303);
    exit;
}

$redirect = 'biblioteca.php?pago=ok';

$_SESSION['pago_exitoso'] = [
    'referencia' => $resultado['referencia'],
    'total' => $resultado['total'],
    'libros' => $resultado['libros'],
    'metodo_pago' => $resultado['metodo_pago'],
];

if ($isJsonRequest) {
    json_response([
        'success' => true,
        'message' => 'Pago simulado aprobado. Tus libros ya están en tu biblioteca.',
        'data' => [
            'redirect' => $redirect,
            'id_pedido' => $resultado['id_pedido'],
            'total' => $resultado['total'],
            'libros' => $resultado['libros'],
            'metodo_pago' => $resultado['metodo_pago'],
            'referencia' => $resultado['referencia'],
        ],
    ], 201);
}

header('Location: ' . $redirect, true, 303);
exit;
