<?php

declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/cart.php';

$user = require_page_auth();
$pdo = db();
$cart = cart_get($pdo, (int) $user['id_usuario']);

$checkoutError = $_SESSION['checkout_error'] ?? null;
unset($_SESSION['checkout_error']);

$pageTitle = 'Pago seguro';
$activePage = 'catalogo';
$pageScripts = ['assets/js/checkout.js'];

require __DIR__ . '/includes/header.php';
?>
<main class="container py-4 py-lg-5">
    <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb mb-0">
            <li class="breadcrumb-item"><a href="index.php">Catálogo</a></li>
            <li class="breadcrumb-item active" aria-current="page">Pago seguro</li>
        </ol>
    </nav>

    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-end gap-3 mb-4">
        <div>
            <span class="badge bg-light text-dark border mb-2">Compra protegida</span>
            <h1 class="h2 fw-bold mb-1">Finalizar compra</h1>
            <p class="text-muted mb-0">Completa tus datos de pago para recibir tus libros al instante.</p>
        </div>
        <span class="secure-badge">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                 stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                <rect x="4" y="10" width="16" height="10" rx="2"></rect>
                <path d="M8 10V7a4 4 0 0 1 8 0v3"></path>
                <path d="M12 14v2"></path>
            </svg>
            Pago seguro simulado
        </span>
    </div>

    <?php if ($checkoutError !== null): ?>
        <div class="alert alert-danger" role="alert"><?= e((string) $checkoutError) ?></div>
    <?php endif; ?>

    <?php if ($cart['items'] === []): ?>
        <div class="card border-0 shadow-sm text-center py-5">
            <div class="card-body">
                <h2 class="h4 fw-bold">Tu carrito está vacío</h2>
                <p class="text-muted mb-4">Agrega un libro al carrito para continuar con el pago.</p>
                <a class="btn btn-primary" href="index.php">Explorar el catálogo</a>
            </div>
        </div>
    <?php else: ?>
        <div class="row g-4 g-lg-5 align-items-start">
            <div class="col-lg-7 order-2 order-lg-1">
                <form id="payment-form" class="card border-0 shadow-sm" method="post"
                      action="procesar_pago_mock.php" novalidate>
                    <div class="card-body p-4 p-lg-5">
                        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">

                        <h2 class="h4 fw-bold mb-1">Método de pago</h2>
                        <p class="text-muted mb-4">Elige cómo deseas pagar. El cobro es una demostración.</p>

                        <div class="payment-methods mb-4" role="radiogroup" aria-label="Método de pago">
                            <label class="payment-option is-selected" for="metodo-tarjeta">
                                <input class="form-check-input" type="radio" name="metodo_pago"
                                       id="metodo-tarjeta" value="tarjeta" checked>
                                <span class="payment-icon payment-icon--card" aria-hidden="true">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                         stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                        <rect x="2" y="5" width="20" height="14" rx="2"></rect>
                                        <path d="M2 10h20"></path>
                                        <path d="M6 15h4"></path>
                                    </svg>
                                </span>
                                <span class="payment-option-text">
                                    <strong>Tarjeta</strong>
                                    <small>Crédito o débito</small>
                                </span>
                            </label>

                            <label class="payment-option" for="metodo-paypal">
                                <input class="form-check-input" type="radio" name="metodo_pago"
                                       id="metodo-paypal" value="paypal">
                                <span class="payment-icon payment-icon--paypal" aria-hidden="true">P</span>
                                <span class="payment-option-text">
                                    <strong>PayPal</strong>
                                    <small>Saldo o cuenta vinculada</small>
                                </span>
                            </label>

                            <label class="payment-option" for="metodo-yape">
                                <input class="form-check-input" type="radio" name="metodo_pago"
                                       id="metodo-yape" value="yape">
                                <span class="payment-icon payment-icon--yape" aria-hidden="true">Y</span>
                                <span class="payment-option-text">
                                    <strong>Yape</strong>
                                    <small>Pago móvil peruano</small>
                                </span>
                            </label>
                        </div>

                        <div class="alert alert-danger d-none" id="payment-error" role="alert"></div>

                        <fieldset id="card-fields">
                            <legend class="h5 fw-bold mb-3">Datos de la tarjeta</legend>

                            <div class="row g-3">
                                <div class="col-12">
                                    <label class="form-label" for="card-name">Nombre del titular</label>
                                    <input class="form-control" type="text" id="card-name" name="titular"
                                           autocomplete="cc-name" maxlength="80" placeholder="Como aparece en la tarjeta"
                                           aria-describedby="error-card-name">
                                    <div class="invalid-feedback" id="error-card-name"></div>
                                </div>

                                <div class="col-12">
                                    <label class="form-label" for="card-number">Número de tarjeta</label>
                                    <div class="input-group">
                                        <span class="input-group-text">
                                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                                 stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                                 aria-hidden="true">
                                                <rect x="2" y="5" width="20" height="14" rx="2"></rect>
                                                <path d="M2 10h20"></path>
                                            </svg>
                                        </span>
                                        <input class="form-control" type="text" id="card-number"
                                               name="numero_tarjeta" inputmode="numeric" maxlength="19"
                                               autocomplete="cc-number" placeholder="0000 0000 0000 0000"
                                               aria-describedby="error-card-number">
                                    </div>
                                    <div class="invalid-feedback" id="error-card-number"></div>
                                </div>

                                <div class="col-6">
                                    <label class="form-label" for="card-expiry">Vencimiento</label>
                                    <input class="form-control" type="text" id="card-expiry" name="vencimiento"
                                           inputmode="numeric" maxlength="5" autocomplete="cc-exp"
                                           placeholder="MM/AA" aria-describedby="error-card-expiry">
                                    <div class="invalid-feedback" id="error-card-expiry"></div>
                                </div>

                                <div class="col-6">
                                    <label class="form-label" for="card-cvv">CVV</label>
                                    <input class="form-control" type="password" id="card-cvv" name="cvv"
                                           inputmode="numeric" maxlength="4" autocomplete="cc-csc"
                                           placeholder="123" aria-describedby="error-card-cvv">
                                    <div class="invalid-feedback" id="error-card-cvv"></div>
                                </div>
                            </div>

                            <p class="small text-muted mt-3 mb-0">
                                No almacenamos los datos de tu tarjeta. Esta pasarela es una simulación.
                            </p>
                        </fieldset>

                        <div class="alert alert-info d-none mt-4 mb-0" id="method-info" role="status"></div>

                        <button class="btn btn-primary btn-lg w-100 mt-4" type="submit" id="pay-button">
                            Pagar S/ <?= number_format((float) $cart['total'], 2, '.', ',') ?>
                        </button>

                        <p class="small text-muted text-center mt-3 mb-0">
                            Al pagar aceptas que se trata de una compra digital de demostración.
                        </p>
                    </div>
                </form>
            </div>

            <div class="col-lg-5 order-1 order-lg-2">
                <aside class="card border-0 shadow-sm checkout-summary">
                    <div class="card-body p-4">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h2 class="h5 fw-bold mb-0">Resumen del pedido</h2>
                            <span class="badge bg-dark">
                                <?= (int) $cart['count'] ?> <?= $cart['count'] === 1 ? 'libro' : 'libros' ?>
                            </span>
                        </div>

                        <ul class="list-unstyled checkout-items mb-4">
                            <?php foreach ($cart['items'] as $item): ?>
                                <?php $cover = trim((string) ($item['portada_url'] ?? '')); ?>
                                <li class="checkout-item">
                                    <img class="checkout-cover"
                                         src="<?= e($cover !== '' ? $cover : 'assets/img/portada-no-disponible.svg') ?>"
                                         alt="Portada de <?= e((string) $item['titulo']) ?>" loading="lazy"
                                         onerror="this.onerror=null;this.src='assets/img/portada-no-disponible.svg'">
                                    <div class="flex-grow-1 min-w-0">
                                        <div class="fw-semibold small line-clamp-title"><?= e((string) $item['titulo']) ?></div>
                                        <div class="text-muted small"><?= e((string) ($item['autor'] ?? 'Autor desconocido')) ?></div>
                                        <div class="small text-muted"><?= (int) $item['cantidad_paginas'] ?> páginas · PDF</div>
                                    </div>
                                    <span class="fw-semibold small">
                                        S/ <?= number_format((float) $item['precio'], 2, '.', ',') ?>
                                    </span>
                                </li>
                            <?php endforeach; ?>
                        </ul>

                        <div class="d-flex justify-content-between align-items-center py-3 border-top">
                            <span class="text-muted">Método</span>
                            <span class="fw-semibold" id="selected-method-label">Tarjeta</span>
                        </div>

                        <div class="d-flex justify-content-between align-items-center pb-2">
                            <span class="text-muted">Subtotal</span>
                            <span>S/ <?= number_format((float) $cart['total'], 2, '.', ',') ?></span>
                        </div>
                        <div class="d-flex justify-content-between align-items-center pb-3">
                            <span class="text-muted">Envío digital</span>
                            <span class="text-success fw-semibold">Gratis</span>
                        </div>

                        <div class="d-flex justify-content-between align-items-center border-top pt-3">
                            <span class="h5 fw-bold mb-0">Total a pagar</span>
                            <strong class="fs-4 text-primary">
                                S/ <?= number_format((float) $cart['total'], 2, '.', ',') ?>
                            </strong>
                        </div>

                        <div class="checkout-trust mt-4">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                 stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                <path d="M12 3 5 6v5c0 4.5 3 8.2 7 10 4-1.8 7-5.5 7-10V6l-7-3z"></path>
                                <path d="m9 12 2 2 4-4"></path>
                            </svg>
                            <span>Acceso inmediato en tu biblioteca después de confirmar el pago.</span>
                        </div>
                    </div>
                </aside>
            </div>
        </div>
    <?php endif; ?>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
