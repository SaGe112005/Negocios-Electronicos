(() => {
    'use strict';

    const csrfMeta = document.querySelector('meta[name="csrf-token"]');
    const state = {
        user: null,
        csrf: csrfMeta ? csrfMeta.getAttribute('content') : '',
        cart: { items: [], total: 0, count: 0 },
    };

    let resolveReady;
    const ready = new Promise((resolve) => {
        resolveReady = resolve;
    });

    const escapeHtml = (value) => String(value ?? '').replace(/[&<>"']/g, (character) => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;',
    }[character]));

    const formatMoney = (value) => {
        const amount = Number(value) || 0;
        return 'S/ ' + new Intl.NumberFormat('es-PE', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
        }).format(amount);
    };

    const setCsrf = (token) => {
        if (!token) {
            return;
        }
        state.csrf = token;
        if (csrfMeta) {
            csrfMeta.setAttribute('content', token);
        }
    };

    const getModal = (id) => {
        const element = document.getElementById(id);
        return element ? bootstrap.Modal.getOrCreateInstance(element) : null;
    };

    const switchModal = (fromId, toId) => {
        const fromElement = document.getElementById(fromId);
        const toModal = getModal(toId);
        if (!toModal) {
            return;
        }

        if (fromElement && fromElement.classList.contains('show')) {
            const instance = bootstrap.Modal.getInstance(fromElement);
            fromElement.addEventListener('hidden.bs.modal', () => toModal.show(), { once: true });
            if (instance) {
                instance.hide();
            }
        } else {
            toModal.show();
        }
    };

    const openLogin = () => switchModal('registerModal', 'loginModal');
    const openRegister = () => switchModal('loginModal', 'registerModal');

    const showToast = (message, type = 'success') => {
        const container = document.getElementById('toast-container');
        if (!container) {
            return;
        }

        const toastElement = document.createElement('div');
        toastElement.className = `toast align-items-center text-white bg-${type} border-0`;
        toastElement.setAttribute('role', 'alert');
        toastElement.setAttribute('aria-live', 'assertive');
        toastElement.setAttribute('aria-atomic', 'true');
        toastElement.innerHTML = `
            <div class="d-flex">
                <div class="toast-body">${escapeHtml(message)}</div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Cerrar"></button>
            </div>`;

        container.appendChild(toastElement);
        toastElement.addEventListener('hidden.bs.toast', () => toastElement.remove());
        bootstrap.Toast.getOrCreateInstance(toastElement, { delay: 3500 }).show();
    };

    const apiFetch = async (url, options = {}) => {
        const settings = {
            credentials: 'same-origin',
            ...options,
            headers: new Headers(options.headers || {}),
        };
        const method = (settings.method || 'GET').toUpperCase();

        if (settings.body && typeof settings.body !== 'string' && !(settings.body instanceof FormData)) {
            settings.body = JSON.stringify(settings.body);
            settings.headers.set('Content-Type', 'application/json');
        }

        settings.headers.set('Accept', 'application/json');

        if (method !== 'GET' && state.csrf) {
            settings.headers.set('X-CSRF-Token', state.csrf);
        }

        const response = await fetch(url, settings);
        const contentType = response.headers.get('content-type') || '';
        let payload = null;

        if (contentType.includes('application/json')) {
            try {
                payload = await response.json();
            } catch (error) {
                payload = null;
            }
        }

        if (!response.ok || !payload || payload.success !== true) {
            const requestError = new Error(
                (payload && payload.message) || 'No se pudo completar la solicitud.'
            );
            requestError.status = response.status;
            requestError.payload = payload;
            throw requestError;
        }

        if (payload.data && payload.data.csrf) {
            setCsrf(payload.data.csrf);
        }

        return payload;
    };

    const updateAuthUi = () => {
        const isLogged = state.user !== null;
        document.querySelectorAll('[data-auth-guest]').forEach((element) => {
            element.classList.toggle('d-none', isLogged);
        });
        document.querySelectorAll('[data-auth-user]').forEach((element) => {
            element.classList.toggle('d-none', !isLogged);
        });
        document.querySelectorAll('[data-user-name]').forEach((element) => {
            element.textContent = state.user ? state.user.nombre_completo : '';
        });
    };

    const notifyAuthChanged = () => {
        document.dispatchEvent(new CustomEvent('auth:changed', {
            detail: { user: state.user },
        }));
    };

    const refreshSession = async () => {
        try {
            const payload = await apiFetch('api/auth/sesion.php');
            state.user = payload.data.user || null;
            setCsrf(payload.data.csrf);
        } catch (error) {
            state.user = null;
        }

        updateAuthUi();
        notifyAuthChanged();
        return state.user;
    };

    const renderCart = () => {
        const cart = state.cart || { items: [], total: 0, count: 0 };
        const itemsContainer = document.getElementById('cart-items');
        const countElements = document.querySelectorAll('#cart-count');
        const totalElement = document.getElementById('cart-total');
        const checkoutButton = document.getElementById('checkout-button');
        const clearButton = document.getElementById('clear-cart-button');
        const message = document.getElementById('cart-message');

        countElements.forEach((element) => {
            element.textContent = String(cart.count);
        });

        if (totalElement) {
            totalElement.textContent = formatMoney(cart.total);
        }

        if (message) {
            message.classList.add('d-none');
            message.textContent = '';
        }

        if (checkoutButton) {
            checkoutButton.disabled = cart.count === 0;
            checkoutButton.textContent = state.user
                ? 'Finalizar compra'
                : 'Iniciar sesión para pagar';
        }

        if (clearButton) {
            clearButton.disabled = cart.count === 0;
        }

        if (!itemsContainer) {
            return;
        }

        if (cart.count === 0) {
            itemsContainer.innerHTML = `
                <div class="text-center py-5">
                    <h6 class="mb-2">Tu carrito está vacío</h6>
                    <p class="small text-muted mb-3">Agrega libros desde el catálogo para comenzar.</p>
                    <a href="index.php" class="btn btn-outline-primary btn-sm">Explorar catálogo</a>
                </div>`;
            return;
        }

        itemsContainer.innerHTML = cart.items.map((item) => {
            const cover = item.portada_url || 'assets/img/portada-no-disponible.svg';
            return `
                <div class="cart-item">
                    <img class="cart-thumb" src="${escapeHtml(cover)}" alt="Portada de ${escapeHtml(item.titulo)}"
                         onerror="this.onerror=null;this.src='assets/img/portada-no-disponible.svg'">
                    <div class="flex-grow-1 min-w-0">
                        <div class="fw-semibold small line-clamp-title">${escapeHtml(item.titulo)}</div>
                        <div class="text-muted small">${escapeHtml(item.autor || 'Autor no disponible')}</div>
                        <div class="fw-semibold mt-1">${formatMoney(item.precio)}</div>
                    </div>
                    <button type="button" class="btn btn-sm btn-outline-danger align-self-start"
                            data-remove-cart="${item.id_libro}" aria-label="Quitar ${escapeHtml(item.titulo)}">
                        Quitar
                    </button>
                </div>`;
        }).join('');
    };

    const refreshCart = async () => {
        try {
            const payload = await apiFetch('api/carrito.php');
            state.cart = payload.data;
        } catch (error) {
            state.cart = { items: [], total: 0, count: 0 };
        }

        renderCart();
        return state.cart;
    };

    const setButtonBusy = (button, busy, busyText = 'Procesando...') => {
        if (!button) {
            return;
        }

        if (busy) {
            button.dataset.originalText = button.textContent;
            button.textContent = busyText;
            button.disabled = true;
        } else {
            button.textContent = button.dataset.originalText || button.textContent;
            button.disabled = false;
        }
    };

    const showFormError = (element, message) => {
        if (!element) {
            return;
        }
        element.textContent = message;
        element.classList.remove('d-none');
    };

    const hideFormError = (element) => {
        if (!element) {
            return;
        }
        element.textContent = '';
        element.classList.add('d-none');
    };

    const finishAuthentication = async (payload, form, errorElement, modalId, message) => {
        state.user = payload.data.user;
        setCsrf(payload.data.csrf);
        updateAuthUi();
        form.reset();
        form.classList.remove('was-validated');
        hideFormError(errorElement);

        const modal = getModal(modalId);
        if (modal) {
            modal.hide();
        }

        await refreshCart();
        notifyAuthChanged();
        showToast(message);
    };

    const bindAuthEvents = () => {
        document.addEventListener('click', (event) => {
            if (event.target.closest('[data-open-login]')) {
                event.preventDefault();
                openLogin();
            }
            if (event.target.closest('[data-open-register]')) {
                event.preventDefault();
                openRegister();
            }
        });

        const loginForm = document.getElementById('login-form');
        const registerForm = document.getElementById('register-form');
        const loginError = document.getElementById('login-error');
        const registerError = document.getElementById('register-error');

        if (loginForm) {
            loginForm.addEventListener('submit', async (event) => {
                event.preventDefault();
                hideFormError(loginError);

                if (!loginForm.checkValidity()) {
                    loginForm.classList.add('was-validated');
                    return;
                }

                const submitButton = document.getElementById('login-submit');
                setButtonBusy(submitButton, true, 'Ingresando...');

                try {
                    const payload = await apiFetch('api/auth/login.php', {
                        method: 'POST',
                        body: {
                            correo: loginForm.correo.value.trim(),
                            password: loginForm.password.value,
                        },
                    });

                    await finishAuthentication(
                        payload,
                        loginForm,
                        loginError,
                        'loginModal',
                        'Bienvenido de nuevo.'
                    );
                } catch (error) {
                    showFormError(loginError, error.message);
                } finally {
                    setButtonBusy(submitButton, false);
                }
            });
        }

        if (registerForm) {
            registerForm.addEventListener('submit', async (event) => {
                event.preventDefault();
                hideFormError(registerError);

                if (!registerForm.checkValidity()) {
                    registerForm.classList.add('was-validated');
                    return;
                }

                if (registerForm.password.value !== registerForm.password_confirm.value) {
                    showFormError(registerError, 'Las contraseñas no coinciden.');
                    return;
                }

                const submitButton = document.getElementById('register-submit');
                setButtonBusy(submitButton, true, 'Creando cuenta...');

                try {
                    const payload = await apiFetch('api/auth/registro.php', {
                        method: 'POST',
                        body: {
                            nombre_completo: registerForm.nombre_completo.value.trim(),
                            correo: registerForm.correo.value.trim(),
                            password: registerForm.password.value,
                            password_confirm: registerForm.password_confirm.value,
                        },
                    });

                    await finishAuthentication(
                        payload,
                        registerForm,
                        registerError,
                        'registerModal',
                        'Tu cuenta fue creada correctamente.'
                    );
                } catch (error) {
                    showFormError(registerError, error.message);
                } finally {
                    setButtonBusy(submitButton, false);
                }
            });
        }

        const logoutButton = document.getElementById('logout-button');
        if (logoutButton) {
            logoutButton.addEventListener('click', async () => {
                logoutButton.disabled = true;

                try {
                    await apiFetch('api/auth/logout.php', {
                        method: 'POST',
                        body: {},
                    });
                    state.user = null;
                    state.cart = { items: [], total: 0, count: 0 };
                    updateAuthUi();
                    renderCart();
                    showToast('Sesión cerrada correctamente.', 'dark');

                    if (document.getElementById('biblioteca-grid')) {
                        window.setTimeout(() => {
                            window.location.href = 'index.php';
                        }, 400);
                        return;
                    }

                    await refreshSession();
                    await refreshCart();
                } catch (error) {
                    showToast(error.message, 'danger');
                } finally {
                    logoutButton.disabled = false;
                }
            });
        }
    };

    const addToCart = async (button) => {
        const id = button.getAttribute('data-add-to-cart');
        if (!id) {
            return;
        }

        setButtonBusy(button, true, 'Agregando...');

        try {
            const payload = await apiFetch('api/carrito.php', {
                method: 'POST',
                body: { accion: 'agregar', id_libro: Number(id) },
            });
            state.cart = payload.data;
            renderCart();
            showToast(payload.message);
        } catch (error) {
            showToast(error.message, 'danger');
        } finally {
            setButtonBusy(button, false);
        }
    };

    const removeFromCart = async (button) => {
        const id = button.getAttribute('data-remove-cart');
        if (!id) {
            return;
        }

        button.disabled = true;

        try {
            const payload = await apiFetch('api/carrito.php', {
                method: 'POST',
                body: { accion: 'eliminar', id_libro: Number(id) },
            });
            state.cart = payload.data;
            renderCart();
            showToast(payload.message, 'dark');
        } catch (error) {
            showToast(error.message, 'danger');
            button.disabled = false;
        }
    };

    const clearCart = async () => {
        const button = document.getElementById('clear-cart-button');
        setButtonBusy(button, true, 'Vaciando...');

        try {
            const payload = await apiFetch('api/carrito.php', {
                method: 'POST',
                body: { accion: 'vaciar' },
            });
            state.cart = payload.data;
            renderCart();
            showToast(payload.message, 'dark');
        } catch (error) {
            showToast(error.message, 'danger');
        } finally {
            setButtonBusy(button, false);
            if (button) {
                button.disabled = state.cart.count === 0;
            }
        }
    };

    const checkout = () => {
        if (state.cart.count === 0) {
            return;
        }

        const offcanvasElement = document.getElementById('cartOffcanvas');
        const offcanvasInstance = offcanvasElement
            ? bootstrap.Offcanvas.getInstance(offcanvasElement)
            : null;
        if (offcanvasInstance) {
            offcanvasInstance.hide();
        }

        if (!state.user) {
            window.setTimeout(openLogin, 300);
            return;
        }

        window.setTimeout(() => {
            window.location.href = 'checkout.php';
        }, 250);
    };

    const bindCartEvents = () => {
        document.addEventListener('click', (event) => {
            const addButton = event.target.closest('[data-add-to-cart]');
            if (addButton) {
                event.preventDefault();
                addToCart(addButton);
                return;
            }

            const removeButton = event.target.closest('[data-remove-cart]');
            if (removeButton) {
                event.preventDefault();
                removeFromCart(removeButton);
            }
        });

        const clearButton = document.getElementById('clear-cart-button');
        if (clearButton) {
            clearButton.addEventListener('click', clearCart);
        }

        const checkoutButton = document.getElementById('checkout-button');
        if (checkoutButton) {
            checkoutButton.addEventListener('click', checkout);
        }
    };

    const bindChatEvents = () => {
        const widget = document.getElementById('chat-widget');
        const toggle = document.getElementById('chat-toggle');
        const closeButton = document.getElementById('chat-close');
        const panel = document.getElementById('chat-panel');
        const messages = document.getElementById('chat-messages');
        const form = document.getElementById('chat-form');
        const input = document.getElementById('chat-input');
        const sendButton = document.getElementById('chat-send');

        if (!widget || !toggle || !panel || !messages || !form || !input || !sendButton) {
            return;
        }

        const chatStorageKey = 'tienda_libros_chat_history';
        const maxHistoryMessages = 20;
        const initialChatMessage = 'hola soy neiky, tu asistente virtual que trabaja 24/7 sin ningun tipo de pago';
        const initialHistory = [{ role: 'assistant', content: initialChatMessage }];
        let isOpen = false;

        const loadHistory = () => {
            try {
                const stored = window.sessionStorage.getItem(chatStorageKey);
                if (!stored) {
                    return initialHistory.slice();
                }

                const parsed = JSON.parse(stored);
                if (!Array.isArray(parsed)) {
                    return initialHistory.slice();
                }

                const cleanHistory = parsed
                    .filter((item) => item
                        && (item.role === 'user' || item.role === 'assistant')
                        && typeof item.content === 'string'
                        && item.content.trim() !== '')
                    .map((item) => ({ role: item.role, content: item.content }));

                if (cleanHistory.length === 0) {
                    return initialHistory.slice();
                }

                if (cleanHistory[0].role !== 'assistant' || cleanHistory[0].content !== initialChatMessage) {
                    cleanHistory.unshift({ role: 'assistant', content: initialChatMessage });
                }

                return cleanHistory.slice(-maxHistoryMessages);
            } catch (error) {
                return initialHistory.slice();
            }
        };

        const saveHistory = (history) => {
            try {
                window.sessionStorage.setItem(
                    chatStorageKey,
                    JSON.stringify(history.slice(-maxHistoryMessages))
                );
            } catch (error) {
                return;
            }
        };

        let chatHistory = loadHistory();

        const setOpen = (open) => {
            isOpen = open;
            panel.classList.toggle('is-open', open);
            panel.setAttribute('aria-hidden', open ? 'false' : 'true');
            toggle.setAttribute('aria-expanded', open ? 'true' : 'false');

            if (open) {
                window.setTimeout(() => input.focus(), 150);
            }
        };

        const appendMessage = (text, type = 'bot', options = {}) => {
            const element = document.createElement('div');
            element.className = `chat-message ${type}${options.system ? ' system' : ''}`;

            if (options.author) {
                const author = document.createElement('span');
                author.className = 'chat-message-author';
                author.textContent = options.author;
                element.appendChild(author);
            }

            const content = document.createElement('span');
            content.textContent = String(text);
            element.appendChild(content);
            messages.appendChild(element);
            messages.scrollTop = messages.scrollHeight;
            return element;
        };

        const renderHistory = (history) => {
            messages.innerHTML = '';
            history.forEach((item) => {
                const isInitial = item.role === 'assistant' && item.content === initialChatMessage;
                appendMessage(item.content, item.role === 'user' ? 'user' : 'bot', {
                    author: item.role === 'assistant' ? 'Neiky' : '',
                    system: isInitial,
                });
            });
        };

        renderHistory(chatHistory);
        saveHistory(chatHistory);

        const sendMessage = async (message) => {
            const cleanMessage = String(message || '').trim();
            if (!cleanMessage) {
                return;
            }

            const historyForRequest = chatHistory.slice();
            appendMessage(cleanMessage, 'user');
            chatHistory = [...chatHistory, { role: 'user', content: cleanMessage }];
            saveHistory(chatHistory);
            input.value = '';
            input.disabled = true;
            sendButton.disabled = true;
            const typingMessage = appendMessage('Escribiendo...', 'bot');

            try {
                const payload = await apiFetch('chat_procesar.php', {
                    method: 'POST',
                    body: {
                        mensaje: cleanMessage,
                        historial: historyForRequest,
                    },
                });
                const reply = String((payload.data && payload.data.respuesta) || '').trim();
                if (!reply) {
                    throw new Error('El asistente no devolvió una respuesta válida.');
                }

                typingMessage.remove();
                appendMessage(reply, 'bot', { author: 'Neiky' });
                chatHistory = [...chatHistory, { role: 'assistant', content: reply }];
                saveHistory(chatHistory);
            } catch (error) {
                typingMessage.remove();
                appendMessage(error.message || 'No pude procesar tu mensaje. Inténtalo de nuevo.', 'error');
            } finally {
                input.disabled = false;
                sendButton.disabled = false;
                input.focus();
                messages.scrollTop = messages.scrollHeight;
            }
        };

        toggle.addEventListener('click', () => setOpen(!isOpen));

        if (closeButton) {
            closeButton.addEventListener('click', () => setOpen(false));
        }

        form.addEventListener('submit', (event) => {
            event.preventDefault();
            sendMessage(input.value);
        });

        document.addEventListener('click', (event) => {
            const opener = event.target.closest('[data-chat-open]');
            if (opener) {
                event.preventDefault();
                setOpen(true);
                return;
            }

            const suggestion = event.target.closest('[data-chat-suggestion]');
            if (suggestion && widget.contains(suggestion)) {
                event.preventDefault();
                if (!isOpen) {
                    setOpen(true);
                }
                sendMessage(suggestion.getAttribute('data-chat-suggestion') || '');
            }
        });

        document.addEventListener('keydown', (event) => {
            if (event.key === 'Escape' && isOpen) {
                setOpen(false);
            }
        });
    };

    const handleQueryMessages = () => {
        const params = new URLSearchParams(window.location.search);

        if (params.get('login') === '1') {
            window.setTimeout(openLogin, 250);
            params.delete('login');
            const query = params.toString();
            window.history.replaceState(null, '', window.location.pathname + (query ? '?' + query : ''));
        }

        if (params.get('compra') === 'ok') {
            window.setTimeout(() => {
                showToast('Compra completada. Tus libros ya están disponibles para descargar.');
            }, 400);
            params.delete('compra');
            const query = params.toString();
            window.history.replaceState(null, '', window.location.pathname + (query ? '?' + query : ''));
        }

        if (params.get('pago') === 'ok') {
            window.setTimeout(() => {
                showToast('Pago simulado aprobado. Tus libros ya están en tu biblioteca.');
            }, 400);
            params.delete('pago');
            const query = params.toString();
            window.history.replaceState(null, '', window.location.pathname + (query ? '?' + query : ''));
        }
    };

    const init = async () => {
        bindAuthEvents();
        bindCartEvents();
        bindChatEvents();
        handleQueryMessages();
        await refreshSession();
        await refreshCart();
        resolveReady();
    };

    window.App = {
        state,
        ready,
        apiFetch,
        escapeHtml,
        formatMoney,
        showToast,
        refreshSession,
        refreshCart,
        updateAuthUi,
        openLogin,
        openRegister,
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init, { once: true });
    } else {
        init();
    }
})();
