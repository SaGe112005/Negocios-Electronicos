(() => {
    'use strict';

    const grid = document.getElementById('biblioteca-grid');
    if (!grid || !window.App) {
        return;
    }

    const loading = document.getElementById('biblioteca-cargando');
    const emptyState = document.getElementById('biblioteca-vacia');
    const errorBox = document.getElementById('biblioteca-error');

    const showError = (message) => {
        if (!errorBox) {
            return;
        }
        errorBox.textContent = message;
        errorBox.classList.remove('d-none');
    };

    const formatDate = (value) => {
        if (!value) {
            return '';
        }

        const normalized = value.replace(' ', 'T');
        const date = new Date(normalized);
        if (Number.isNaN(date.getTime())) {
            return value;
        }

        return new Intl.DateTimeFormat('es-ES', {
            day: '2-digit',
            month: 'long',
            year: 'numeric',
        }).format(date);
    };

    const renderBook = (book) => {
        const cover = book.portada_url || 'assets/img/portada-no-disponible.svg';
        return `
            <div class="col-6 col-md-4 col-lg-3">
                <article class="card library-card border-0 shadow-sm">
                    <img class="book-cover" src="${App.escapeHtml(cover)}"
                         alt="Portada de ${App.escapeHtml(book.titulo)}" loading="lazy"
                         onerror="this.onerror=null;this.src='assets/img/portada-no-disponible.svg'">
                    <div class="card-body d-flex flex-column p-3">
                        <span class="badge bg-light text-dark border align-self-start mb-2">
                            ${App.escapeHtml(book.categoria || 'Sin categoría')}
                        </span>
                        <h2 class="h6 fw-bold mb-1">${App.escapeHtml(book.titulo)}</h2>
                        <p class="small text-muted mb-2">${App.escapeHtml(book.autor || 'Autor desconocido')}</p>
                        <p class="small text-muted mb-3">
                            Adquirido el ${App.escapeHtml(formatDate(book.fecha_adquisicion))}
                        </p>
                        <a class="btn btn-primary btn-sm mt-auto" href="${App.escapeHtml(book.url_descarga)}"
                           download>Descargar PDF</a>
                    </div>
                </article>
            </div>`;
    };

    const loadLibrary = async () => {
        if (loading) {
            loading.classList.remove('d-none');
        }
        if (errorBox) {
            errorBox.classList.add('d-none');
        }
        if (emptyState) {
            emptyState.classList.add('d-none');
        }

        try {
            const payload = await App.apiFetch('api/biblioteca.php');
            const books = payload.data.libros;

            grid.innerHTML = books.map(renderBook).join('');
            if (emptyState) {
                emptyState.classList.toggle('d-none', books.length !== 0);
            }
        } catch (error) {
            if (error.status === 401) {
                window.location.href = 'index.php?login=1';
                return;
            }
            showError(error.message);
        } finally {
            if (loading) {
                loading.classList.add('d-none');
            }
        }
    };

    const boot = () => {
        document.addEventListener('library:changed', loadLibrary);
        App.ready.then(loadLibrary);
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot, { once: true });
    } else {
        boot();
    }
})();
