(() => {
    'use strict';

    const form = document.getElementById('payment-form');
    if (!form || !window.App) {
        return;
    }

    const cardFields = document.getElementById('card-fields');
    const methodInfo = document.getElementById('method-info');
    const methodLabel = document.getElementById('selected-method-label');
    const errorBox = document.getElementById('payment-error');
    const payButton = document.getElementById('pay-button');
    const radios = Array.from(form.querySelectorAll('input[name="metodo_pago"]'));

    const cardName = document.getElementById('card-name');
    const cardNumber = document.getElementById('card-number');
    const cardExpiry = document.getElementById('card-expiry');
    const cardCvv = document.getElementById('card-cvv');

    if (!cardFields || !methodInfo || !methodLabel || !errorBox || !payButton ||
        !cardName || !cardNumber || !cardExpiry || !cardCvv) {
        return;
    }

    let processing = false;

    const methodNames = {
        tarjeta: 'Tarjeta',
        paypal: 'PayPal',
        yape: 'Yape',
    };

    const methodDescriptions = {
        paypal: 'El pago se simulará como aprobado con tu cuenta de PayPal. No se abrirá ninguna ventana externa.',
        yape: 'El pago se simulará como aprobado desde la aplicación Yape. No necesitas escanear ningún código.',
    };

    const selectedMethod = () => {
        const checked = radios.find((radio) => radio.checked);
        return checked ? checked.value : 'tarjeta';
    };

    const feedbackFor = (input) => document.getElementById('error-' + input.id);

    const clearError = (input) => {
        input.classList.remove('is-invalid');
        const feedback = feedbackFor(input);
        if (feedback) {
            feedback.textContent = '';
            feedback.classList.remove('d-block');
        }
    };

    const setError = (input, message) => {
        input.classList.add('is-invalid');
        const feedback = feedbackFor(input);
        if (feedback) {
            feedback.textContent = message;
            feedback.classList.add('d-block');
        }
    };

    const hideErrorBox = () => {
        errorBox.textContent = '';
        errorBox.classList.add('d-none');
    };

    const showErrorBox = (message) => {
        errorBox.textContent = message;
        errorBox.classList.remove('d-none');
        errorBox.scrollIntoView({ behavior: 'smooth', block: 'center' });
    };

    const syncMethod = () => {
        const method = selectedMethod();

        radios.forEach((radio) => {
            const option = radio.closest('.payment-option');
            if (option) {
                option.classList.toggle('is-selected', radio.checked);
            }
        });

        methodLabel.textContent = methodNames[method] || 'Tarjeta';
        cardFields.classList.toggle('d-none', method !== 'tarjeta');

        [cardName, cardNumber, cardExpiry, cardCvv].forEach(clearError);

        if (method === 'tarjeta') {
            methodInfo.classList.add('d-none');
            methodInfo.textContent = '';
        } else {
            methodInfo.textContent = methodDescriptions[method] || '';
            methodInfo.classList.remove('d-none');
        }

        hideErrorBox();
    };

    const digitsOnly = (value, maxLength) => value.replace(/\D/g, '').slice(0, maxLength);

    const formatCardNumber = (value) => {
        const digits = digitsOnly(value, 16);
        return digits.replace(/(\d{4})(?=\d)/g, '$1 ');
    };

    const formatExpiry = (value) => {
        const digits = digitsOnly(value, 4);
        if (digits.length <= 2) {
            return digits;
        }
        return digits.slice(0, 2) + '/' + digits.slice(2);
    };

    const nameError = (value) => {
        const name = value.trim();
        if (name === '') {
            return 'Escribe el nombre del titular.';
        }
        if (!/^[A-Za-zÁÉÍÓÚÜÑáéíóúüñ][A-Za-zÁÉÍÓÚÜÑáéíóúüñ\s.'-]{2,79}$/.test(name)) {
            return 'El nombre debe tener al menos 3 caracteres y solo letras.';
        }
        return '';
    };

    const numberError = (value) => {
        const digits = value.replace(/\D/g, '');
        if (digits === '') {
            return 'Escribe el número de la tarjeta.';
        }
        if (!/^\d{16}$/.test(digits)) {
            return 'El número de tarjeta debe tener exactamente 16 dígitos.';
        }
        return '';
    };

    const expiryError = (value) => {
        const expiry = value.trim();
        if (expiry === '') {
            return 'Escribe la fecha de vencimiento.';
        }

        const match = /^(0[1-9]|1[0-2])\/(\d{2})$/.exec(expiry);
        if (!match) {
            return 'Usa el formato MM/AA.';
        }

        const month = Number(match[1]);
        const year = 2000 + Number(match[2]);
        const now = new Date();

        if (year < now.getFullYear() || (year === now.getFullYear() && month < now.getMonth() + 1)) {
            return 'La tarjeta está vencida.';
        }

        return '';
    };

    const cvvError = (value) => {
        const cvv = value.trim();
        if (cvv === '') {
            return 'Escribe el CVV.';
        }
        if (!/^\d{3,4}$/.test(cvv)) {
            return 'El CVV debe tener 3 o 4 dígitos.';
        }
        return '';
    };

    const validateCard = () => {
        const checks = [
            [cardName, nameError(cardName.value)],
            [cardNumber, numberError(cardNumber.value)],
            [cardExpiry, expiryError(cardExpiry.value)],
            [cardCvv, cvvError(cardCvv.value)],
        ];

        let firstInvalid = null;

        checks.forEach(([input, message]) => {
            if (message) {
                setError(input, message);
                if (firstInvalid === null) {
                    firstInvalid = input;
                }
            } else {
                clearError(input);
            }
        });

        if (firstInvalid !== null) {
            firstInvalid.focus();
            showErrorBox('Revisa los campos marcados en rojo antes de continuar.');
            return false;
        }

        hideErrorBox();
        return true;
    };

    const setProcessing = (busy) => {
        processing = busy;
        payButton.disabled = busy;
        radios.forEach((radio) => {
            radio.disabled = busy;
        });
        [cardName, cardNumber, cardExpiry, cardCvv].forEach((input) => {
            input.disabled = busy;
        });

        if (busy) {
            payButton.dataset.originalHtml = payButton.innerHTML;
            payButton.innerHTML = '<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>Procesando pago seguro...';
        } else if (payButton.dataset.originalHtml) {
            payButton.innerHTML = payButton.dataset.originalHtml;
        }
    };

    cardNumber.addEventListener('input', () => {
        cardNumber.value = formatCardNumber(cardNumber.value);
        clearError(cardNumber);
        hideErrorBox();
    });

    cardExpiry.addEventListener('input', () => {
        cardExpiry.value = formatExpiry(cardExpiry.value);
        clearError(cardExpiry);
        hideErrorBox();
    });

    cardCvv.addEventListener('input', () => {
        cardCvv.value = digitsOnly(cardCvv.value, 4);
        clearError(cardCvv);
        hideErrorBox();
    });

    cardName.addEventListener('input', () => {
        clearError(cardName);
        hideErrorBox();
    });

    cardName.addEventListener('blur', () => {
        if (cardName.value.trim() !== '') {
            const message = nameError(cardName.value);
            if (message) {
                setError(cardName, message);
            }
        }
    });

    cardNumber.addEventListener('blur', () => {
        if (cardNumber.value.trim() !== '') {
            const message = numberError(cardNumber.value);
            if (message) {
                setError(cardNumber, message);
            }
        }
    });

    cardExpiry.addEventListener('blur', () => {
        if (cardExpiry.value.trim() !== '') {
            const message = expiryError(cardExpiry.value);
            if (message) {
                setError(cardExpiry, message);
            }
        }
    });

    cardCvv.addEventListener('blur', () => {
        if (cardCvv.value.trim() !== '') {
            const message = cvvError(cardCvv.value);
            if (message) {
                setError(cardCvv, message);
            }
        }
    });

    radios.forEach((radio) => {
        radio.addEventListener('change', syncMethod);
    });

    form.addEventListener('submit', (event) => {
        event.preventDefault();

        if (processing) {
            return;
        }

        const method = selectedMethod();

        if (method === 'tarjeta' && !validateCard()) {
            return;
        }

        hideErrorBox();

        const body = { metodo_pago: method };

        if (method === 'tarjeta') {
            body.titular = cardName.value.trim();
            body.numero_tarjeta = cardNumber.value.replace(/\D/g, '');
            body.vencimiento = cardExpiry.value.trim();
            body.cvv = cardCvv.value.trim();
        }

        setProcessing(true);

        window.setTimeout(async () => {
            try {
                const payload = await App.apiFetch('procesar_pago_mock.php', {
                    method: 'POST',
                    headers: { 'X-Requested-With': 'XMLHttpRequest' },
                    body,
                });

                const redirect = payload && payload.data && payload.data.redirect
                    ? payload.data.redirect
                    : 'biblioteca.php?pago=ok';

                window.location.href = redirect;
            } catch (error) {
                setProcessing(false);

                if (error.status === 401) {
                    window.location.href = 'index.php?login=1';
                    return;
                }

                showErrorBox(error.message || 'No se pudo procesar el pago. Inténtalo de nuevo.');
            }
        }, 2500);
    });

    syncMethod();
})();
