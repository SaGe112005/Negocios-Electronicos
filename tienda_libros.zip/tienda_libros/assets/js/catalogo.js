(() => {
    'use strict';

    const grid = document.getElementById('catalogo-grid');
    if (!grid || !window.App) {
        return;
    }

    const loading = document.getElementById('catalogo-cargando');
    const emptyState = document.getElementById('catalogo-vacio');
    const errorBox = document.getElementById('catalogo-error');
    const resultTotal = document.getElementById('resultado-total');
    const pagination = document.getElementById('catalogo-paginacion');
    const categorySelect = document.getElementById('filtro-categoria');
    const authorSelect = document.getElementById('filtro-autor');
    const searchInput = document.getElementById('filtro-busqueda');
    const clearButton = document.getElementById('limpiar-filtros');
    const filterForm = document.getElementById('filtros-catalogo');

    const filters = {
        categoria: '',
        autor: '',
        busqueda: '',
        pagina: 1,
    };

    let filtersLoaded = false;
    let controller = null;
    let searchTimer = null;

    const showError = (message) => {
        if (!errorBox) {
            return;
        }
        errorBox.textContent = message;
        errorBox.classList.remove('d-none');
    };

    const hideError = () => {
        if (errorBox) {
            errorBox.classList.add('d-none');
            errorBox.textContent = '';
        }
    };

    const setLoading = (isLoading) => {
        if (loading) {
            loading.classList.toggle('d-none', !isLoading);
        }
    };

    const populateFilters = (data) => {
        if (filtersLoaded || !categorySelect || !authorSelect) {
            return;
        }

        data.filtros.categorias.forEach((categoria) => {
            const option = document.createElement('option');
            option.value = String(categoria.id_categoria);
            option.textContent = categoria.nombre;
            categorySelect.appendChild(option);
        });

        data.filtros.autores.forEach((autor) => {
            const option = document.createElement('option');
            option.value = String(autor.id_autor);
            option.textContent = autor.nombre_completo;
            authorSelect.appendChild(option);
        });

        filtersLoaded = true;
    };

    const renderBook = (book) => {
        const cover = book.portada_url || 'assets/img/portada-no-disponible.svg';
        const description = book.descripcion || 'Sin descripción disponible.';
        const action = book.en_biblioteca
            ? '<a class="btn btn-success btn-sm w-100" href="biblioteca.php">En mi biblioteca</a>'
            : `<button type="button" class="btn btn-primary btn-sm w-100"
                       data-add-to-cart="${book.id_libro}">Agregar al carrito</button>`;

        return `
            <div class="col-6 col-md-4 col-xl-3">
                <article class="card book-card border-0 shadow-sm">
                    <a class="d-block" href="detalle_libro.php?id=${book.id_libro}" target="_blank" rel="noopener"
                       aria-label="Ver detalle de ${App.escapeHtml(book.titulo)}">
                        <img class="book-cover" src="${App.escapeHtml(cover)}"
                             alt="Portada de ${App.escapeHtml(book.titulo)}" loading="lazy"
                             onerror="this.onerror=null;this.src='assets/img/portada-no-disponible.svg'">
                    </a>
                    <div class="card-body d-flex flex-column p-3">
                        <span class="badge bg-light text-dark border align-self-start mb-2">
                            ${App.escapeHtml(book.categoria || 'Sin categoría')}
                        </span>
                        <h3 class="h6 fw-bold mb-1">
                            <a class="text-decoration-none text-dark" href="detalle_libro.php?id=${book.id_libro}"
                               target="_blank" rel="noopener">${App.escapeHtml(book.titulo)}</a>
                        </h3>
                        <p class="small text-muted mb-2">${App.escapeHtml(book.autor || 'Autor desconocido')}</p>
                        <p class="book-description small text-muted">${App.escapeHtml(description)}</p>
                        <div class="mt-auto pt-2">
                            <div class="d-flex justify-content-between align-items-end mb-2">
                                <span class="fs-5 fw-bold">${App.formatMoney(book.precio)}</span>
                                <span class="small text-muted">${book.cantidad_paginas} págs.</span>
                            </div>
                            ${action}
                        </div>
                    </div>
                </article>
            </div>`;
    };

    const renderPagination = (meta) => {
        if (!pagination) {
            return;
        }

        pagination.innerHTML = '';
        if (meta.total_paginas <= 1) {
            return;
        }

        const current = meta.pagina;
        const total = meta.total_paginas;
        let start = Math.max(1, current - 2);
        let end = Math.min(total, start + 4);
        start = Math.max(1, end - 4);

        const addItem = (label, page, disabled = false, active = false) => {
            const item = document.createElement('li');
            item.className = `page-item${disabled ? ' disabled' : ''}${active ? ' active' : ''}`;
            item.innerHTML = `<button class="page-link" type="button" data-page="${page}"
                                      ${disabled ? 'disabled' : ''}>${label}</button>`;
            pagination.appendChild(item);
        };

        addItem('Anterior', current - 1, current === 1);

        for (let page = start; page <= end; page += 1) {
            addItem(String(page), page, false, page === current);
        }

        addItem('Siguiente', current + 1, current === total);
    };

    const loadCatalog = async (showLoader = true) => {
        if (controller) {
            controller.abort();
        }
        const requestController = new AbortController();
        controller = requestController;

        if (showLoader) {
            setLoading(true);
            grid.innerHTML = '';
        }
        hideError();
        if (emptyState) {
            emptyState.classList.add('d-none');
        }

        const params = new URLSearchParams();
        if (filters.categoria) {
            params.set('categoria', filters.categoria);
        }
        if (filters.autor) {
            params.set('autor', filters.autor);
        }
        if (filters.busqueda) {
            params.set('busqueda', filters.busqueda);
        }
        params.set('pagina', String(filters.pagina));

        try {
            const payload = await App.apiFetch(`api/catalogo.php?${params.toString()}`, {
                signal: requestController.signal,
            });
            const data = payload.data;
            const meta = data.paginacion;

            populateFilters(data);
            filters.pagina = meta.pagina;

            grid.innerHTML = data.libros.map(renderBook).join('');
            renderPagination(meta);

            if (resultTotal) {
                if (meta.total === 0) {
                    resultTotal.textContent = 'Sin resultados';
                } else {
                    const first = (meta.pagina - 1) * meta.por_pagina + 1;
                    const last = first + data.libros.length - 1;
                    resultTotal.textContent = `Mostrando ${first}-${last} de ${meta.total} libros`;
                }
            }

            if (emptyState) {
                emptyState.classList.toggle('d-none', data.libros.length !== 0);
            }
        } catch (error) {
            if (error.name === 'AbortError') {
                return;
            }
            showError(error.message);
            if (resultTotal) {
                resultTotal.textContent = '';
            }
        } finally {
            if (!requestController.signal.aborted) {
                setLoading(false);
            }
        }
    };

    const applyFilters = () => {
        filters.categoria = categorySelect ? categorySelect.value : '';
        filters.autor = authorSelect ? authorSelect.value : '';
        filters.busqueda = searchInput ? searchInput.value.trim() : '';
        filters.pagina = 1;
        loadCatalog();
    };

    const bindEvents = () => {
        if (filterForm) {
            filterForm.addEventListener('submit', (event) => event.preventDefault());
        }

        if (categorySelect) {
            categorySelect.addEventListener('change', applyFilters);
        }

        if (authorSelect) {
            authorSelect.addEventListener('change', applyFilters);
        }

        if (searchInput) {
            searchInput.addEventListener('input', () => {
                window.clearTimeout(searchTimer);
                searchTimer = window.setTimeout(applyFilters, 350);
            });
        }

        if (clearButton) {
            clearButton.addEventListener('click', () => {
                if (categorySelect) {
                    categorySelect.value = '';
                }
                if (authorSelect) {
                    authorSelect.value = '';
                }
                if (searchInput) {
                    searchInput.value = '';
                }
                filters.categoria = '';
                filters.autor = '';
                filters.busqueda = '';
                filters.pagina = 1;
                loadCatalog();
            });
        }

        if (pagination) {
            pagination.addEventListener('click', (event) => {
                const button = event.target.closest('[data-page]');
                if (!button || button.disabled) {
                    return;
                }

                const page = Number(button.getAttribute('data-page'));
                if (!Number.isInteger(page) || page < 1) {
                    return;
                }

                filters.pagina = page;
                loadCatalog();
                document.getElementById('catalogo')?.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start',
                });
            });
        }

        document.addEventListener('auth:changed', () => {
            loadCatalog(false);
        });

        document.addEventListener('library:changed', () => {
            loadCatalog(false);
        });
    };

    const boot = () => {
        bindEvents();
        App.ready.then(() => loadCatalog());
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot, { once: true });
    } else {
        boot();
    }
})();
