-- =====================================================================
-- Registro de transacciones de pago simuladas
-- =====================================================================

CREATE TABLE IF NOT EXISTS `transacciones_pago` (
  `id_transaccion` int(11) NOT NULL AUTO_INCREMENT,
  `id_pedido` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `metodo_pago` varchar(50) NOT NULL,
  `monto` decimal(10,2) NOT NULL,
  `estado` varchar(20) NOT NULL DEFAULT 'aprobado',
  `referencia` varchar(80) NOT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_transaccion`),
  UNIQUE KEY `uq_transacciones_pago_referencia` (`referencia`),
  KEY `idx_transacciones_pago_usuario` (`id_usuario`),
  KEY `idx_transacciones_pago_pedido` (`id_pedido`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
