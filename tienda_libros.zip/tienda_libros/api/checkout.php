<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/api_bootstrap.php';
require_once __DIR__ . '/../includes/checkout_service.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Allow: POST');
    json_error('Método no permitido.', 405);
}

$data = request_data();
require_csrf($data);

$user = require_api_auth();
$userId = (int) $user['id_usuario'];

try {
    $resultado = procesar_compra_simulada(db(), $userId, 'simulado');
} catch (CheckoutException $exception) {
    json_error($exception->getMessage(), $exception->statusCode());
}

json_response([
    'success' => true,
    'message' => 'Compra completada. Los libros ya están en tu biblioteca.',
    'data' => [
        'id_pedido' => $resultado['id_pedido'],
        'total' => $resultado['total'],
        'libros' => $resultado['libros'],
        'metodo_pago' => $resultado['metodo_pago'],
        'referencia' => $resultado['referencia'],
    ],
], 201);
