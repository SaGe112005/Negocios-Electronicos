<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/api_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    header('Allow: GET');
    json_error('Método no permitido.', 405);
}

$user = require_api_auth();
$idLibro = filter_var($_GET['id'] ?? 0, FILTER_VALIDATE_INT);

if ($idLibro === false || $idLibro <= 0) {
    json_error('El libro indicado no es válido.', 422);
}

$stmt = db()->prepare(
    'SELECT l.id_libro, l.titulo, l.archivo_pdf_url
     FROM biblioteca_digital bd
     INNER JOIN libros l ON l.id_libro = bd.id_libro
     WHERE bd.id_usuario = ? AND bd.id_libro = ?
     LIMIT 1'
);
$stmt->execute([(int) $user['id_usuario'], $idLibro]);
$book = $stmt->fetch();

if (!$book) {
    json_error('No tienes acceso a este archivo.', 403);
}

$relativePath = str_replace('\\', '/', (string) $book['archivo_pdf_url']);
$relativePath = ltrim($relativePath, '/');

if (str_starts_with($relativePath, 'archivos/')) {
    $relativePath = substr($relativePath, strlen('archivos/'));
}

$baseDir = realpath(__DIR__ . '/../archivos');
$filePath = $baseDir !== false
    ? realpath($baseDir . DIRECTORY_SEPARATOR . $relativePath)
    : false;

if (
    $baseDir === false
    || $filePath === false
    || !str_starts_with($filePath, $baseDir . DIRECTORY_SEPARATOR)
    || !is_file($filePath)
) {
    json_error('El archivo PDF no está disponible. Contacta al administrador.', 404);
}

$title = (string) $book['titulo'];
$asciiName = preg_replace('/[^A-Za-z0-9_\- ]+/', '_', $title) ?? 'libro';
$asciiName = trim($asciiName);
if ($asciiName === '') {
    $asciiName = 'libro_' . $idLibro;
}
$asciiName = substr($asciiName, 0, 80) . '.pdf';
$utf8Name = rawurlencode($title . '.pdf');

header('Content-Type: application/pdf');
header('Content-Length: ' . (string) filesize($filePath));
header('Content-Disposition: attachment; filename="' . $asciiName . '"; filename*=UTF-8\'\'' . $utf8Name);
header('Cache-Control: private, no-store, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');

session_write_close();
readfile($filePath);
exit;
