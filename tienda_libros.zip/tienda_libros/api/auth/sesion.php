<?php

declare(strict_types=1);

require_once __DIR__ . '/../../includes/api_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    header('Allow: GET');
    json_error('Método no permitido.', 405);
}

json_response([
    'success' => true,
    'data' => [
        'user' => auth_user(),
        'csrf' => csrf_token(),
    ],
]);
