<?php

declare(strict_types=1);

require_once __DIR__ . '/../../includes/api_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Allow: POST');
    json_error('Método no permitido.', 405);
}

$data = request_data();
require_csrf($data);

if (login_attempts_locked()) {
    json_error('Demasiados intentos fallidos. Espera unos minutos antes de volver a intentarlo.', 429);
}

$correo = strtolower(trim((string) ($data['correo'] ?? $data['email'] ?? '')));
$password = (string) ($data['password'] ?? '');

if ($correo === '' || $password === '') {
    json_error('Ingresa tu correo y contraseña.', 422);
}

if (!filter_var($correo, FILTER_VALIDATE_EMAIL) || strlen($password) > 200) {
    login_record_failure();
    json_error('Correo o contraseña incorrectos.', 401);
}

$stmt = db()->prepare(
    'SELECT id_usuario, nombre_completo, correo, password, rol
     FROM usuarios
     WHERE correo = ?
     LIMIT 1'
);
$stmt->execute([$correo]);
$user = $stmt->fetch();

$dummyHash = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.';
$hash = $user ? $user['password'] : $dummyHash;
$passwordOk = password_verify($password, $hash);

if (!$user || !$passwordOk) {
    login_record_failure();
    json_error('Correo o contraseña incorrectos.', 401);
}

if (password_needs_rehash($user['password'], PASSWORD_DEFAULT)) {
    $update = db()->prepare('UPDATE usuarios SET password = ? WHERE id_usuario = ?');
    $update->execute([password_hash($password, PASSWORD_DEFAULT), $user['id_usuario']]);
}

session_regenerate_id(true);

$payload = user_session_payload($user);
$_SESSION['user'] = $payload;
$newCsrf = rotate_csrf_token();
login_clear_attempts();

json_response([
    'success' => true,
    'message' => 'Sesión iniciada correctamente.',
    'data' => [
        'user' => $payload,
        'csrf' => $newCsrf,
    ],
]);
