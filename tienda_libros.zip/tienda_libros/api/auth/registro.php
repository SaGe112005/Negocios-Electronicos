<?php

declare(strict_types=1);

require_once __DIR__ . '/../../includes/api_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Allow: POST');
    json_error('Método no permitido.', 405);
}

$data = request_data();
require_csrf($data);

$nombre = preg_replace('/\s+/u', ' ', trim((string) ($data['nombre_completo'] ?? ''))) ?? '';
$correo = strtolower(trim((string) ($data['correo'] ?? '')));
$password = (string) ($data['password'] ?? '');
$passwordConfirm = (string) ($data['password_confirm'] ?? '');

$nameLength = function_exists('mb_strlen') ? mb_strlen($nombre, 'UTF-8') : strlen($nombre);

if ($nameLength < 2 || $nameLength > 150) {
    json_error('El nombre debe tener entre 2 y 150 caracteres.', 422);
}

if (!filter_var($correo, FILTER_VALIDATE_EMAIL) || strlen($correo) > 150) {
    json_error('Ingresa un correo electrónico válido.', 422);
}

if (strlen($password) < 8) {
    json_error('La contraseña debe tener al menos 8 caracteres.', 422);
}

if (strlen($password) > 72) {
    json_error('La contraseña no puede superar los 72 caracteres.', 422);
}

if ($passwordConfirm !== '' && !hash_equals($password, $passwordConfirm)) {
    json_error('Las contraseñas no coinciden.', 422);
}

try {
    $stmt = db()->prepare('SELECT id_usuario FROM usuarios WHERE correo = ? LIMIT 1');
    $stmt->execute([$correo]);

    if ($stmt->fetch()) {
        json_error('Ya existe una cuenta registrada con ese correo.', 409);
    }

    $insert = db()->prepare(
        'INSERT INTO usuarios (nombre_completo, correo, password, rol) VALUES (?, ?, ?, ?)'
    );
    $insert->execute([
        $nombre,
        $correo,
        password_hash($password, PASSWORD_DEFAULT),
        'cliente',
    ]);

    $userId = (int) db()->lastInsertId();
    $user = [
        'id_usuario' => $userId,
        'nombre_completo' => $nombre,
        'correo' => $correo,
        'rol' => 'cliente',
    ];

    session_regenerate_id(true);
    $_SESSION['user'] = user_session_payload($user);
    $newCsrf = rotate_csrf_token();
    login_clear_attempts();

    json_response([
        'success' => true,
        'message' => 'Cuenta creada correctamente.',
        'data' => [
            'user' => user_session_payload($user),
            'csrf' => $newCsrf,
        ],
    ], 201);
} catch (PDOException $exception) {
    if ((string) $exception->getCode() === '23000') {
        json_error('Ya existe una cuenta registrada con ese correo.', 409);
    }

    throw $exception;
}
