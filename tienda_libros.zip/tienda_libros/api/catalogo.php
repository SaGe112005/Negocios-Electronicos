<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/api_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    header('Allow: GET');
    json_error('Método no permitido.', 405);
}

header('Cache-Control: no-store, private');

$pdo = db();

$categoria = trim((string) ($_GET['categoria'] ?? ''));
$autor = trim((string) ($_GET['autor'] ?? ''));
$busqueda = trim((string) ($_GET['busqueda'] ?? ''));
$pagina = filter_var($_GET['pagina'] ?? 1, FILTER_VALIDATE_INT);

if ($categoria !== '' && (!ctype_digit($categoria) || (int) $categoria <= 0)) {
    json_error('La categoría seleccionada no es válida.', 422);
}

if ($autor !== '' && (!ctype_digit($autor) || (int) $autor <= 0)) {
    json_error('El autor seleccionado no es válido.', 422);
}

if (function_exists('mb_substr')) {
    $busqueda = mb_substr($busqueda, 0, 100, 'UTF-8');
} else {
    $busqueda = substr($busqueda, 0, 100);
}

if ($pagina === false || $pagina < 1) {
    $pagina = 1;
}

$porPagina = 12;
$where = ['l.activo = 1'];
$params = [];

if ($categoria !== '') {
    $where[] = 'l.id_categoria = ?';
    $params[] = (int) $categoria;
}

if ($autor !== '') {
    $where[] = 'l.id_autor = ?';
    $params[] = (int) $autor;
}

if ($busqueda !== '') {
    $like = '%' . $busqueda . '%';
    $where[] = '(l.titulo LIKE ? OR l.descripcion LIKE ? OR c.nombre LIKE ? OR a.nombre_completo LIKE ?)';
    array_push($params, $like, $like, $like, $like);
}

$from = ' FROM libros l
          LEFT JOIN categorias c ON c.id_categoria = l.id_categoria
          LEFT JOIN autores a ON a.id_autor = l.id_autor';
$whereSql = ' WHERE ' . implode(' AND ', $where);

$countStmt = $pdo->prepare('SELECT COUNT(*)' . $from . $whereSql);
$countStmt->execute($params);
$total = (int) $countStmt->fetchColumn();
$totalPaginas = max(1, (int) ceil($total / $porPagina));

if ($pagina > $totalPaginas) {
    $pagina = $totalPaginas;
}
$offset = ($pagina - 1) * $porPagina;

$sql = 'SELECT l.id_libro, l.titulo, l.descripcion, l.cantidad_paginas, l.precio,
               l.portada_url, c.id_categoria, c.nombre AS categoria,
               a.id_autor, a.nombre_completo AS autor'
    . $from . $whereSql
    . ' ORDER BY l.titulo ASC, l.id_libro ASC'
    . ' LIMIT ' . $porPagina . ' OFFSET ' . $offset;

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

$owned = [];
$user = auth_user();
if ($user !== null) {
    $ownedStmt = $pdo->prepare('SELECT id_libro FROM biblioteca_digital WHERE id_usuario = ?');
    $ownedStmt->execute([(int) $user['id_usuario']]);
    $owned = array_map('intval', $ownedStmt->fetchAll(PDO::FETCH_COLUMN));
}

$libros = array_map(static function (array $row) use ($owned): array {
    return [
        'id_libro' => (int) $row['id_libro'],
        'titulo' => $row['titulo'],
        'descripcion' => $row['descripcion'],
        'cantidad_paginas' => (int) $row['cantidad_paginas'],
        'precio' => (float) $row['precio'],
        'portada_url' => $row['portada_url'],
        'id_categoria' => $row['id_categoria'] !== null ? (int) $row['id_categoria'] : null,
        'categoria' => $row['categoria'],
        'id_autor' => $row['id_autor'] !== null ? (int) $row['id_autor'] : null,
        'autor' => $row['autor'],
        'en_biblioteca' => in_array((int) $row['id_libro'], $owned, true),
    ];
}, $rows);

$categorias = $pdo->query('SELECT id_categoria, nombre FROM categorias ORDER BY nombre ASC')->fetchAll();
$autores = $pdo->query('SELECT id_autor, nombre_completo FROM autores ORDER BY nombre_completo ASC')->fetchAll();

json_response([
    'success' => true,
    'data' => [
        'libros' => $libros,
        'filtros' => [
            'categorias' => array_map(static fn (array $row) => [
                'id_categoria' => (int) $row['id_categoria'],
                'nombre' => $row['nombre'],
            ], $categorias),
            'autores' => array_map(static fn (array $row) => [
                'id_autor' => (int) $row['id_autor'],
                'nombre_completo' => $row['nombre_completo'],
            ], $autores),
        ],
        'paginacion' => [
            'pagina' => $pagina,
            'por_pagina' => $porPagina,
            'total' => $total,
            'total_paginas' => $totalPaginas,
        ],
    ],
]);
