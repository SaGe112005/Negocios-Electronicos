<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/api_bootstrap.php';
require_once __DIR__ . '/../includes/cart.php';

header('Cache-Control: no-store, private');

$pdo = db();
$user = auth_user();
$userId = $user !== null ? (int) $user['id_usuario'] : null;
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    json_response([
        'success' => true,
        'data' => cart_get($pdo, $userId),
    ]);
}

if ($method !== 'POST') {
    header('Allow: GET, POST');
    json_error('Método no permitido.', 405);
}

$data = request_data();
require_csrf($data);

$accion = (string) ($data['accion'] ?? '');
$idLibro = null;

if ($accion === 'agregar' || $accion === 'eliminar') {
    $idLibro = filter_var($data['id_libro'] ?? 0, FILTER_VALIDATE_INT);

    if ($idLibro === false || $idLibro <= 0) {
        json_error('El libro indicado no es válido.', 422);
    }
}

$message = 'Carrito actualizado.';

if ($accion === 'agregar') {
    $stmt = $pdo->prepare('SELECT id_libro, titulo FROM libros WHERE id_libro = ? AND activo = 1 LIMIT 1');
    $stmt->execute([$idLibro]);
    $book = $stmt->fetch();

    if (!$book) {
        json_error('El libro no está disponible.', 404);
    }

    if ($userId !== null) {
        $ownedStmt = $pdo->prepare(
            'SELECT id_acceso FROM biblioteca_digital WHERE id_usuario = ? AND id_libro = ? LIMIT 1'
        );
        $ownedStmt->execute([$userId, $idLibro]);

        if ($ownedStmt->fetch()) {
            json_error('Ya tienes este libro en tu biblioteca.', 409);
        }
    }

    $ids = cart_ids();
    if (in_array((int) $idLibro, $ids, true)) {
        $message = 'Este libro ya está en el carrito.';
    } else {
        $ids[] = (int) $idLibro;
        cart_persist($ids);
        $message = 'Libro agregado al carrito.';
    }
} elseif ($accion === 'eliminar') {
    $ids = array_values(array_filter(
        cart_ids(),
        static fn (int $id) => $id !== (int) $idLibro
    ));
    cart_persist($ids);
    $message = 'Libro eliminado del carrito.';
} elseif ($accion === 'vaciar') {
    cart_clear();
    $message = 'Carrito vaciado.';
} else {
    json_error('Acción de carrito no válida.', 422);
}

json_response([
    'success' => true,
    'message' => $message,
    'data' => cart_get($pdo, $userId),
]);
