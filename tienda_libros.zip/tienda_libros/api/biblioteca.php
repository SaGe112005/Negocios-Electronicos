<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/api_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    header('Allow: GET');
    json_error('Método no permitido.', 405);
}

header('Cache-Control: no-store, private');

$user = require_api_auth();

$stmt = db()->prepare(
    'SELECT bd.id_acceso, bd.fecha_adquisicion,
            l.id_libro, l.titulo, l.descripcion, l.cantidad_paginas, l.precio, l.portada_url,
            c.nombre AS categoria, a.nombre_completo AS autor
     FROM biblioteca_digital bd
     INNER JOIN libros l ON l.id_libro = bd.id_libro
     LEFT JOIN categorias c ON c.id_categoria = l.id_categoria
     LEFT JOIN autores a ON a.id_autor = l.id_autor
     WHERE bd.id_usuario = ?
     ORDER BY bd.fecha_adquisicion DESC, bd.id_acceso DESC'
);
$stmt->execute([(int) $user['id_usuario']]);
$rows = $stmt->fetchAll();

$libros = array_map(static fn (array $row) => [
    'id_acceso' => (int) $row['id_acceso'],
    'id_libro' => (int) $row['id_libro'],
    'titulo' => $row['titulo'],
    'descripcion' => $row['descripcion'],
    'cantidad_paginas' => (int) $row['cantidad_paginas'],
    'precio' => (float) $row['precio'],
    'portada_url' => $row['portada_url'],
    'categoria' => $row['categoria'],
    'autor' => $row['autor'],
    'fecha_adquisicion' => $row['fecha_adquisicion'],
    'url_descarga' => 'api/descargar.php?id=' . (int) $row['id_libro'],
], $rows);

json_response([
    'success' => true,
    'data' => [
        'libros' => $libros,
        'total' => count($libros),
    ],
]);
