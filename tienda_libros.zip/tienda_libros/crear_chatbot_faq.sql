-- =====================================================================
-- Preguntas frecuentes del chatbot
-- =====================================================================

CREATE TABLE IF NOT EXISTS `chatbot_faq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `palabra_clave` varchar(100) NOT NULL,
  `respuesta` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_chatbot_faq_palabra_clave` (`palabra_clave`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `chatbot_faq` (`palabra_clave`, `respuesta`) VALUES
('formato', 'Todos nuestros libros están disponibles en formato PDF de alta calidad. Puedes leerlos en computadora, tablet o teléfono con cualquier lector de PDF.'),
('descarg', 'Después de completar la compra, el libro se agrega automáticamente a Mi Biblioteca. Desde allí puedes descargarlo tantas veces como necesites con tu cuenta.'),
('pago', 'El proceso de compra es simulado para esta demostración. En un entorno de producción aceptaríamos tarjetas de crédito, débito y PayPal.'),
('reembolso', 'Al tratarse de productos digitales, las compras no son reembolsables una vez descargado el PDF. Si tuviste un problema con tu compra, escríbenos y revisaremos tu caso.'),
('contact', 'Puedes escribirnos desde la página de Contacto o al correo soporte@tiendalibros.com. Atendemos de lunes a viernes de 9:00 a 18:00.')
ON DUPLICATE KEY UPDATE
  `respuesta` = VALUES(`respuesta`);
