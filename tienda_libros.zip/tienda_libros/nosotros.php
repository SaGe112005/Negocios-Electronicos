<?php

declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';

$pdo = db();
$stats = [
    'libros' => (int) $pdo->query('SELECT COUNT(*) FROM libros WHERE activo = 1')->fetchColumn(),
    'autores' => (int) $pdo->query('SELECT COUNT(*) FROM autores')->fetchColumn(),
    'categorias' => (int) $pdo->query('SELECT COUNT(*) FROM categorias')->fetchColumn(),
    'resenas' => (int) $pdo->query('SELECT COUNT(*) FROM comentarios_libros')->fetchColumn(),
];

$pageTitle = 'Nosotros';
$activePage = 'nosotros';

require __DIR__ . '/includes/header.php';
?>
<header class="hero text-white">
    <div class="container py-5">
        <div class="row align-items-center g-4">
            <div class="col-lg-8">
                <span class="badge bg-warning text-dark mb-3">Nuestra historia</span>
                <h1 class="display-5 fw-bold mb-3">Libros que acompañan, inspiran y transforman.</h1>
                <p class="lead text-white-50 mb-4">
                    Somos una tienda digital independiente enfocada en acercar grandes historias,
                    conocimiento técnico y herramientas para crecer personal y profesionalmente.
                </p>
                <div class="d-flex flex-column flex-sm-row gap-2">
                    <a class="btn btn-warning btn-lg" href="index.php">Explorar catálogo</a>
                    <a class="btn btn-outline-light btn-lg" href="contacto.php">Hablar con nosotros</a>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="hero-card p-4 rounded-4">
                    <div class="fw-semibold mb-2">Una biblioteca para todos</div>
                    <p class="small text-white-50 mb-3">
                        Curamos títulos de narrativa, fantasía, programación, finanzas y desarrollo personal.
                    </p>
                    <div class="d-flex align-items-center gap-2 small text-white-50">
                        <span class="brand-mark">TL</span>
                        <span>Compra simple, lectura inmediata.</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>

<main class="container py-4 py-lg-5">
    <section class="row g-3 mb-5">
        <div class="col-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 h-100 text-center">
                <div class="card-body p-4">
                    <div class="display-6 fw-bold text-primary"><?= $stats['libros'] ?></div>
                    <div class="text-muted small">Libros disponibles</div>
                </div>
            </div>
        </div>
        <div class="col-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 h-100 text-center">
                <div class="card-body p-4">
                    <div class="display-6 fw-bold text-primary"><?= $stats['autores'] ?></div>
                    <div class="text-muted small">Autores reunidos</div>
                </div>
            </div>
        </div>
        <div class="col-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 h-100 text-center">
                <div class="card-body p-4">
                    <div class="display-6 fw-bold text-primary"><?= $stats['categorias'] ?></div>
                    <div class="text-muted small">Categorías para elegir</div>
                </div>
            </div>
        </div>
        <div class="col-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 h-100 text-center">
                <div class="card-body p-4">
                    <div class="display-6 fw-bold text-primary"><?= $stats['resenas'] ?></div>
                    <div class="text-muted small">Reseñas de lectores</div>
                </div>
            </div>
        </div>
    </section>

    <section class="row g-4 g-lg-5 align-items-center mb-5">
        <div class="col-lg-6">
            <span class="badge bg-light text-dark border mb-3">Quiénes somos</span>
            <h2 class="h1 fw-bold mb-3">Una tienda creada por lectores, para lectores.</h2>
            <p class="text-muted mb-3">
                Creemos que un buen libro puede cambiar una tarde, una decisión o una forma de ver el mundo.
                Por eso seleccionamos títulos que combinan calidad, diversidad y utilidad.
            </p>
            <p class="text-muted mb-4">
                Nuestro catálogo reúne ficción contemporánea, clásicos imperdibles, fantasía, libros técnicos
                y obras de finanzas y crecimiento personal. Todo en formato digital, listo para descargar.
            </p>
            <div class="d-flex flex-wrap gap-2">
                <span class="badge bg-primary">Curaduría editorial</span>
                <span class="badge bg-primary">Acceso inmediato</span>
                <span class="badge bg-primary">Experiencia simple</span>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="row g-3">
                <div class="col-sm-6">
                    <div class="card border-0 shadow-sm rounded-4 h-100">
                        <div class="card-body p-4">
                            <span class="badge bg-primary mb-3">01</span>
                            <h3 class="h5 fw-bold">Misión</h3>
                            <p class="text-muted small mb-0">
                                Facilitar el acceso a libros digitales relevantes con una compra clara,
                                segura y sin fricción.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="card border-0 shadow-sm rounded-4 h-100">
                        <div class="card-body p-4">
                            <span class="badge bg-primary mb-3">02</span>
                            <h3 class="h5 fw-bold">Visión</h3>
                            <p class="text-muted small mb-0">
                                Ser una biblioteca digital de referencia para quienes buscan aprender,
                                entretenerse y descubrir nuevas voces.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="card border-0 shadow-sm rounded-4">
                        <div class="card-body p-4 d-flex flex-column flex-sm-row align-items-sm-center justify-content-between gap-3">
                            <div>
                                <h3 class="h5 fw-bold mb-1">Atención cercana</h3>
                                <p class="text-muted small mb-0">¿Tienes una duda? Nuestro equipo y el asistente virtual están para ayudarte.</p>
                            </div>
                            <a class="btn btn-outline-primary" href="contacto.php">Contactar</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="mb-5">
        <div class="text-center mb-4">
            <h2 class="h3 fw-bold mb-1">Lo que nos mueve</h2>
            <p class="text-muted mb-0">Tres principios que guían cada decisión de nuestra tienda.</p>
        </div>
        <div class="row g-4">
            <div class="col-md-4">
                <div class="card border-0 shadow-sm rounded-4 h-100">
                    <div class="card-body p-4">
                        <span class="badge bg-warning text-dark mb-3">Calidad</span>
                        <h3 class="h5 fw-bold">Selección con criterio</h3>
                        <p class="text-muted small mb-0">
                            Revisamos cada título para que el catálogo tenga profundidad, variedad y valor real para nuestros lectores.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border-0 shadow-sm rounded-4 h-100">
                    <div class="card-body p-4">
                        <span class="badge bg-warning text-dark mb-3">Accesibilidad</span>
                        <h3 class="h5 fw-bold">Leer donde quieras</h3>
                        <p class="text-muted small mb-0">
                            El formato PDF permite disfrutar de cada libro en computadora, tablet o teléfono sin depender de una plataforma cerrada.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border-0 shadow-sm rounded-4 h-100">
                    <div class="card-body p-4">
                        <span class="badge bg-warning text-dark mb-3">Confianza</span>
                        <h3 class="h5 fw-bold">Compra transparente</h3>
                        <p class="text-muted small mb-0">
                            Información clara, acceso inmediato a tus libros y un equipo dispuesto a escucharte antes y después de comprar.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="card border-0 shadow-sm rounded-4 overflow-hidden">
        <div class="card-body p-4 p-lg-5 text-white hero">
            <div class="row align-items-center g-4">
                <div class="col-lg-8">
                    <h2 class="h3 fw-bold mb-2">Tu próxima gran lectura está aquí.</h2>
                    <p class="text-white-50 mb-0">
                        Explora el catálogo, descubre nuevos autores y empieza a leer hoy mismo.
                    </p>
                </div>
                <div class="col-lg-4 text-lg-end">
                    <a class="btn btn-warning btn-lg" href="index.php">Ver catálogo</a>
                </div>
            </div>
        </div>
    </section>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
