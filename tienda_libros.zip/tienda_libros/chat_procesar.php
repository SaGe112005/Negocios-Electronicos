<?php

declare(strict_types=1);

require_once __DIR__ . '/includes/api_bootstrap.php';

function groq_api_key_from_env(string $path): string
{
    if (!is_file($path) || !is_readable($path)) {
        return '';
    }

    $config = @parse_ini_file($path, false, INI_SCANNER_RAW);
    if (!is_array($config)) {
        error_log('[tienda_libros][groq] No se pudo leer el archivo .env');
        return '';
    }

    $apiKey = $config['GROQ_API_KEY'] ?? '';
    if (!is_string($apiKey)) {
        return '';
    }

    $apiKey = trim($apiKey);
    if (strlen($apiKey) >= 2) {
        $first = $apiKey[0];
        $last = $apiKey[strlen($apiKey) - 1];
        if (($first === '"' && $last === '"') || ($first === "'" && $last === "'")) {
            $apiKey = substr($apiKey, 1, -1);
        }
    }

    return trim($apiKey);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Allow: POST');
    json_error('Método no permitido.', 405);
}

header('Cache-Control: no-store, private');

$data = request_data();

$ip = (string) ($_SERVER['REMOTE_ADDR'] ?? 'unknown');
$now = time();
$window = 60;
$limit = 10;
$rateKey = 'chat_rate_' . (string) preg_replace('/[^a-zA-Z0-9_.:-]/', '_', $ip);
$timestamps = $_SESSION[$rateKey] ?? [];

if (!is_array($timestamps)) {
    $timestamps = [];
}

$timestamps = array_values(array_filter(
    $timestamps,
    static fn ($timestamp): bool => is_numeric($timestamp) && (int) $timestamp > ($now - $window)
));

if (count($timestamps) >= $limit) {
    $retryAfter = max(1, $window - ($now - (int) min($timestamps)));
    header('Retry-After: ' . $retryAfter);
    json_error('¡Uf, vas muy rápido! Espera un minutito para seguir hablando.', 429, [
        'retry_after' => $retryAfter,
    ]);
}

$timestamps[] = $now;
$_SESSION[$rateKey] = $timestamps;
session_write_close();

$textLength = static fn (string $value): int => function_exists('mb_strlen')
    ? mb_strlen($value, 'UTF-8')
    : strlen($value);

$truncate = static function (string $value, int $maxLength) use ($textLength): string {
    if ($textLength($value) <= $maxLength) {
        return $value;
    }

    return function_exists('mb_substr')
        ? mb_substr($value, 0, $maxLength, 'UTF-8')
        : substr($value, 0, $maxLength);
};

$mensaje = trim((string) ($data['mensaje'] ?? ''));

if ($mensaje === '') {
    json_error('Escribe un mensaje para que pueda ayudarte.', 422);
}

if ($textLength($mensaje) > 500) {
    json_error('El mensaje no puede superar los 500 caracteres.', 422);
}

try {
    $faqStmt = db()->prepare(
        "SELECT respuesta FROM chatbot_faq
         WHERE ? LIKE CONCAT('%', palabra_clave, '%')
         LIMIT 1"
    );
    $faqStmt->execute([$mensaje]);
    $faqRespuesta = $faqStmt->fetchColumn();
} catch (Throwable $exception) {
    error_log('[tienda_libros][faq] No se pudo consultar chatbot_faq: ' . $exception->getMessage());
    $faqRespuesta = false;
}

if (is_string($faqRespuesta) && trim($faqRespuesta) !== '') {
    json_response([
        'success' => true,
        'data' => [
            'respuesta' => trim($faqRespuesta),
            'origen' => 'base_datos',
        ],
    ]);
}

$historial = $data['historial'] ?? [];
if (!is_array($historial)) {
    json_error('El historial de la conversación no es válido.', 422);
}

$historyMessages = [];
foreach (array_slice($historial, -20) as $item) {
    if (!is_array($item)) {
        continue;
    }

    $role = $item['role'] ?? '';
    $content = $item['content'] ?? '';

    if (!is_string($role) || !is_string($content) || !in_array($role, ['user', 'assistant'], true)) {
        continue;
    }

    $content = trim($content);
    if ($content === '') {
        continue;
    }

    $historyMessages[] = [
        'role' => $role,
        'content' => $truncate($content, 2000),
    ];
}

$historyCharacters = array_sum(array_map(
    static fn (array $item): int => $textLength($item['content']),
    $historyMessages
));

while ($historyMessages !== [] && $historyCharacters > 12000) {
    $removed = array_shift($historyMessages);
    $historyCharacters -= $textLength($removed['content']);
}

$systemPrompt = 'Eres Neiky, el asistente virtual exclusivo de \'Tienda de Libros\', una plataforma web de venta de libros 100% digitales. NUNCA preguntes en qué tienda está el usuario, porque ya están interactuando contigo dentro de la web oficial. Si preguntan cómo descargar un libro, indícales que tras el pago tendrán acceso inmediato y los PDFs estarán disponibles en su cuenta, dentro de la sección \'Mi Biblioteca\'. Responde con la personalidad de un niño curioso, muy amigable, humano y directo. Evita respuestas robóticas';

$messages = [
    ['role' => 'system', 'content' => $systemPrompt],
];

foreach ($historyMessages as $historyMessage) {
    $messages[] = $historyMessage;
}

$messages[] = ['role' => 'user', 'content' => $mensaje];

$apiKey = groq_api_key_from_env(__DIR__ . '/.env');
if ($apiKey === '') {
    error_log('[tienda_libros][groq] Falta GROQ_API_KEY en .env');
    json_error('El asistente no está configurado. Falta la API Key de Groq.', 503);
}

$model = 'openai/gpt-oss-20b';

$payload = [
    'model' => $model,
    'messages' => $messages,
    'temperature' => 0.7,
    'max_tokens' => 512,
    'top_p' => 0.9,
];

$jsonPayload = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
if ($jsonPayload === false) {
    error_log('[tienda_libros][groq] No se pudo codificar el payload JSON');
    json_error('No pude preparar la consulta del asistente.', 500);
}

if (!function_exists('curl_init')) {
    error_log('[tienda_libros][groq] La extensión cURL no está disponible');
    json_error('El asistente no está disponible en este servidor.', 503);
}

$ch = curl_init('https://api.groq.com/openai/v1/chat/completions');
curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => false,
    CURLOPT_CONNECTTIMEOUT => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_ENCODING => '',
    CURLOPT_HTTPHEADER => [
        'Authorization: Bearer ' . $apiKey,
        'Content-Type: application/json',
        'Accept: application/json',
    ],
    CURLOPT_POSTFIELDS => $jsonPayload,
]);

$rawResponse = curl_exec($ch);
$httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlError = curl_error($ch);
curl_close($ch);

if ($rawResponse === false) {
    error_log('[tienda_libros][groq] Error cURL: ' . $curlError);
    json_error('No pude comunicarme con el asistente. Inténtalo de nuevo.', 502);
}

$response = json_decode($rawResponse, true);
if (!is_array($response)) {
    error_log('[tienda_libros][groq] Respuesta no JSON: ' . substr((string) $rawResponse, 0, 1000));
    json_error('El asistente devolvió una respuesta no válida.', 502);
}

if ($httpCode < 200 || $httpCode >= 300) {
    $upstreamMessage = $response['error']['message'] ?? 'Error desconocido de Groq';
    error_log(sprintf('[tienda_libros][groq] HTTP %d: %s', $httpCode, (string) $upstreamMessage));

    if ($httpCode === 401 || $httpCode === 403) {
        json_error('La configuración del asistente no es válida. Revisa la API Key de Groq.', 502);
    }

    if ($httpCode === 429) {
        json_error('El asistente está recibiendo muchas solicitudes. Espera un momento e inténtalo de nuevo.', 429);
    }

    json_error('No pude obtener una respuesta del asistente. Inténtalo de nuevo.', 502);
}

$reply = $response['choices'][0]['message']['content'] ?? null;
if (!is_string($reply) || trim($reply) === '') {
    error_log('[tienda_libros][groq] Respuesta sin contenido utilizable');
    json_error('El asistente no devolvió una respuesta válida.', 502);
}

json_response([
    'success' => true,
    'data' => [
        'respuesta' => trim($reply),
    ],
]);
