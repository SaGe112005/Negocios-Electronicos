<?php

declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';

$user = require_page_auth();

$pagoExitoso = $_SESSION['pago_exitoso'] ?? null;
unset($_SESSION['pago_exitoso']);

$mostrarPagoOk = is_array($pagoExitoso) || (($_GET['pago'] ?? '') === 'ok');
$metodosPago = [
    'tarjeta' => 'Tarjeta de crédito o débito',
    'paypal' => 'PayPal',
    'yape' => 'Yape',
];

$pageTitle = 'Mi Biblioteca';
$activePage = 'biblioteca';
$pageScripts = ['assets/js/biblioteca.js'];

require __DIR__ . '/includes/header.php';
?>
<main class="container py-4 py-lg-5">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-end gap-3 mb-4">
        <div>
            <h1 class="h2 fw-bold mb-1">Mi Biblioteca</h1>
            <p class="text-muted mb-0">
                Hola, <?= e($user['nombre_completo']) ?>. Aquí puedes descargar los libros que has comprado.
            </p>
        </div>
        <a class="btn btn-outline-primary" href="index.php">Seguir comprando</a>
    </div>

    <?php if ($mostrarPagoOk): ?>
        <div class="alert alert-success d-flex align-items-start gap-3 shadow-sm" role="alert">
            <svg class="flex-shrink-0 mt-1" width="22" height="22" viewBox="0 0 24 24" fill="none"
                 stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                 aria-hidden="true">
                <circle cx="12" cy="12" r="9"></circle>
                <path d="m8 12 2.5 2.5L16 9"></path>
            </svg>
            <div>
                <strong class="d-block">Pago aprobado correctamente</strong>
                <span class="small">
                    Tu compra se completó con éxito y los libros ya están disponibles para descargar.
                    <?php if (is_array($pagoExitoso)): ?>
                        <?php
                        $metodoPago = $pagoExitoso['metodo_pago'] ?? '';
                        $nombreMetodo = $metodosPago[$metodoPago] ?? ucfirst((string) $metodoPago);
                        ?>
                        Método: <?= e($nombreMetodo) ?>. Referencia:
                        <strong><?= e((string) ($pagoExitoso['referencia'] ?? '')) ?></strong>.
                    <?php endif; ?>
                </span>
            </div>
        </div>
    <?php endif; ?>

    <div class="alert alert-danger d-none" id="biblioteca-error" role="alert"></div>

    <div id="biblioteca-cargando" class="text-center py-5">
        <div class="spinner-border text-primary" role="status"></div>
        <p class="text-muted mt-3 mb-0">Cargando tu biblioteca...</p>
    </div>

    <div class="row g-4" id="biblioteca-grid"></div>

    <div class="card border-0 shadow-sm text-center py-5 d-none" id="biblioteca-vacia">
        <div class="card-body">
            <h2 class="h4">Tu biblioteca está vacía</h2>
            <p class="text-muted">Cuando compres un libro aparecerá aquí con su enlace de descarga.</p>
            <a class="btn btn-primary" href="index.php">Explorar el catálogo</a>
        </div>
    </div>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
