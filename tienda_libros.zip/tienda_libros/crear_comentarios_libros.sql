-- =====================================================================
-- Tabla de comentarios/reseñas por libro
-- =====================================================================

CREATE TABLE IF NOT EXISTS `comentarios_libros` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_libro` int(11) NOT NULL,
  `nombre_usuario` varchar(150) NOT NULL,
  `calificacion` int(11) NOT NULL,
  `texto_comentario` text NOT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_comentarios_libros_libro` (`id_libro`),
  KEY `idx_comentarios_libros_fecha` (`fecha_creacion`),
  CONSTRAINT `chk_comentarios_libros_calificacion` CHECK (`calificacion` BETWEEN 1 AND 5),
  CONSTRAINT `fk_comentarios_libros_libro` FOREIGN KEY (`id_libro`)
    REFERENCES `libros` (`id_libro`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
