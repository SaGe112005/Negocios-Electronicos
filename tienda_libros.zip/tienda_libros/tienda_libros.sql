-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 23-10-2026 a las 04:05:01
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `tienda_libros`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `autores`
--

CREATE TABLE `autores` (
  `id_autor` int(11) NOT NULL,
  `nombre_completo` varchar(150) NOT NULL,
  `biografia` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `autores`
--

INSERT INTO `autores` (`id_autor`, `nombre_completo`, `biografia`) VALUES
(1, 'Robert Kiyosaki', 'Biografía ficticia de Robert Kiyosaki.'),
(2, 'J.K. Rowling', 'Biografía ficticia de J.K. Rowling.'),
(3, 'Linus Torvalds', 'Biografía ficticia de Linus Torvalds.'),
(4, 'Stephen King', 'Biografía ficticia de Stephen King.'),
(5, 'Isabel Allende', 'Biografía ficticia de Isabel Allende.');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `biblioteca_digital`
--

CREATE TABLE `biblioteca_digital` (
  `id_acceso` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_libro` int(11) NOT NULL,
  `fecha_adquisicion` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE `categorias` (
  `id_categoria` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `descripcion` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`id_categoria`, `nombre`, `descripcion`) VALUES
(1, 'Novelas', 'Descripción genérica para Novelas'),
(2, 'Autosuperación', 'Descripción genérica para Autosuperación'),
(3, 'Programación', 'Descripción genérica para Programación'),
(4, 'Fantasía', 'Descripción genérica para Fantasía'),
(5, 'Finanzas', 'Descripción genérica para Finanzas');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalles_pedido`
--

CREATE TABLE `detalles_pedido` (
  `id_detalle` int(11) NOT NULL,
  `id_pedido` int(11) NOT NULL,
  `id_libro` int(11) NOT NULL,
  `precio_unitario` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `libros`
--

CREATE TABLE `libros` (
  `id_libro` int(11) NOT NULL,
  `id_categoria` int(11) DEFAULT NULL,
  `id_autor` int(11) DEFAULT NULL,
  `titulo` varchar(255) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `cantidad_paginas` int(11) DEFAULT NULL,
  `precio` decimal(10,2) NOT NULL,
  `portada_url` varchar(255) DEFAULT NULL,
  `archivo_pdf_url` varchar(255) NOT NULL,
  `activo` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `libros`
--

INSERT INTO `libros` (`id_libro`, `id_categoria`, `id_autor`, `titulo`, `descripcion`, `cantidad_paginas`, `precio`, `portada_url`, `archivo_pdf_url`, `activo`) VALUES
(1, 3, 5, 'Libro de Prueba #1', 'Sinopsis generada automáticamente para el libro 1. Contiene información valiosa y formato estructurado.', 317, 22.99, 'https://picsum.photos/seed/9803/300/450', 'archivos/libro_1.pdf', 1),
(2, 2, 5, 'Libro de Prueba #2', 'Sinopsis generada automáticamente para el libro 2. Contiene información valiosa y formato estructurado.', 563, 22.99, 'https://picsum.photos/seed/6397/300/450', 'archivos/libro_2.pdf', 1),
(3, 1, 4, 'Libro de Prueba #3', 'Sinopsis generada automáticamente para el libro 3. Contiene información valiosa y formato estructurado.', 441, 15.99, 'https://picsum.photos/seed/7948/300/450', 'archivos/libro_3.pdf', 1),
(4, 5, 3, 'Libro de Prueba #4', 'Sinopsis generada automáticamente para el libro 4. Contiene información valiosa y formato estructurado.', 143, 25.99, 'https://picsum.photos/seed/3207/300/450', 'archivos/libro_4.pdf', 1),
(5, 5, 1, 'Libro de Prueba #5', 'Sinopsis generada automáticamente para el libro 5. Contiene información valiosa y formato estructurado.', 169, 28.99, 'https://picsum.photos/seed/1902/300/450', 'archivos/libro_5.pdf', 1),
(6, 4, 1, 'Libro de Prueba #6', 'Sinopsis generada automáticamente para el libro 6. Contiene información valiosa y formato estructurado.', 206, 36.99, 'https://picsum.photos/seed/5040/300/450', 'archivos/libro_6.pdf', 1),
(7, 4, 3, 'Libro de Prueba #7', 'Sinopsis generada automáticamente para el libro 7. Contiene información valiosa y formato estructurado.', 429, 32.99, 'https://picsum.photos/seed/1129/300/450', 'archivos/libro_7.pdf', 1),
(8, 4, 1, 'Libro de Prueba #8', 'Sinopsis generada automáticamente para el libro 8. Contiene información valiosa y formato estructurado.', 217, 31.99, 'https://picsum.photos/seed/4962/300/450', 'archivos/libro_8.pdf', 1),
(9, 2, 1, 'Libro de Prueba #9', 'Sinopsis generada automáticamente para el libro 9. Contiene información valiosa y formato estructurado.', 227, 37.99, 'https://picsum.photos/seed/1503/300/450', 'archivos/libro_9.pdf', 1),
(10, 1, 4, 'Libro de Prueba #10', 'Sinopsis generada automáticamente para el libro 10. Contiene información valiosa y formato estructurado.', 496, 46.99, 'https://picsum.photos/seed/1112/300/450', 'archivos/libro_10.pdf', 1),
(11, 3, 1, 'Libro de Prueba #11', 'Sinopsis generada automáticamente para el libro 11. Contiene información valiosa y formato estructurado.', 381, 47.99, 'https://picsum.photos/seed/3565/300/450', 'archivos/libro_11.pdf', 1),
(12, 4, 5, 'Libro de Prueba #12', 'Sinopsis generada automáticamente para el libro 12. Contiene información valiosa y formato estructurado.', 274, 17.99, 'https://picsum.photos/seed/7076/300/450', 'archivos/libro_12.pdf', 1),
(13, 1, 1, 'Libro de Prueba #13', 'Sinopsis generada automáticamente para el libro 13. Contiene información valiosa y formato estructurado.', 598, 37.99, 'https://picsum.photos/seed/3020/300/450', 'archivos/libro_13.pdf', 1),
(14, 4, 4, 'Libro de Prueba #14', 'Sinopsis generada automáticamente para el libro 14. Contiene información valiosa y formato estructurado.', 241, 49.99, 'https://picsum.photos/seed/7550/300/450', 'archivos/libro_14.pdf', 1),
(15, 2, 2, 'Libro de Prueba #15', 'Sinopsis generada automáticamente para el libro 15. Contiene información valiosa y formato estructurado.', 131, 37.99, 'https://picsum.photos/seed/4195/300/450', 'archivos/libro_15.pdf', 1),
(16, 3, 4, 'Libro de Prueba #16', 'Sinopsis generada automáticamente para el libro 16. Contiene información valiosa y formato estructurado.', 336, 38.99, 'https://picsum.photos/seed/5499/300/450', 'archivos/libro_16.pdf', 1),
(17, 1, 1, 'Libro de Prueba #17', 'Sinopsis generada automáticamente para el libro 17. Contiene información valiosa y formato estructurado.', 393, 17.99, 'https://picsum.photos/seed/9612/300/450', 'archivos/libro_17.pdf', 1),
(18, 5, 5, 'Libro de Prueba #18', 'Sinopsis generada automáticamente para el libro 18. Contiene información valiosa y formato estructurado.', 318, 20.99, 'https://picsum.photos/seed/7813/300/450', 'archivos/libro_18.pdf', 1),
(19, 4, 3, 'Libro de Prueba #19', 'Sinopsis generada automáticamente para el libro 19. Contiene información valiosa y formato estructurado.', 193, 43.99, 'https://picsum.photos/seed/825/300/450', 'archivos/libro_19.pdf', 1),
(20, 3, 5, 'Libro de Prueba #20', 'Sinopsis generada automáticamente para el libro 20. Contiene información valiosa y formato estructurado.', 452, 45.99, 'https://picsum.photos/seed/7172/300/450', 'archivos/libro_20.pdf', 1),
(21, 2, 3, 'Libro de Prueba #21', 'Sinopsis generada automáticamente para el libro 21. Contiene información valiosa y formato estructurado.', 236, 24.99, 'https://picsum.photos/seed/9948/300/450', 'archivos/libro_21.pdf', 1),
(22, 4, 1, 'Libro de Prueba #22', 'Sinopsis generada automáticamente para el libro 22. Contiene información valiosa y formato estructurado.', 411, 43.99, 'https://picsum.photos/seed/9582/300/450', 'archivos/libro_22.pdf', 1),
(23, 4, 4, 'Libro de Prueba #23', 'Sinopsis generada automáticamente para el libro 23. Contiene información valiosa y formato estructurado.', 284, 32.99, 'https://picsum.photos/seed/2432/300/450', 'archivos/libro_23.pdf', 1),
(24, 4, 4, 'Libro de Prueba #24', 'Sinopsis generada automáticamente para el libro 24. Contiene información valiosa y formato estructurado.', 248, 36.99, 'https://picsum.photos/seed/3244/300/450', 'archivos/libro_24.pdf', 1),
(25, 3, 3, 'Libro de Prueba #25', 'Sinopsis generada automáticamente para el libro 25. Contiene información valiosa y formato estructurado.', 560, 22.99, 'https://picsum.photos/seed/2042/300/450', 'archivos/libro_25.pdf', 1),
(26, 5, 1, 'Libro de Prueba #26', 'Sinopsis generada automáticamente para el libro 26. Contiene información valiosa y formato estructurado.', 592, 22.99, 'https://picsum.photos/seed/195/300/450', 'archivos/libro_26.pdf', 1),
(27, 4, 5, 'Libro de Prueba #27', 'Sinopsis generada automáticamente para el libro 27. Contiene información valiosa y formato estructurado.', 530, 35.99, 'https://picsum.photos/seed/6640/300/450', 'archivos/libro_27.pdf', 1),
(28, 3, 3, 'Libro de Prueba #28', 'Sinopsis generada automáticamente para el libro 28. Contiene información valiosa y formato estructurado.', 294, 31.99, 'https://picsum.photos/seed/6272/300/450', 'archivos/libro_28.pdf', 1),
(29, 5, 4, 'Libro de Prueba #29', 'Sinopsis generada automáticamente para el libro 29. Contiene información valiosa y formato estructurado.', 294, 21.99, 'https://picsum.photos/seed/2058/300/450', 'archivos/libro_29.pdf', 1),
(30, 5, 4, 'Libro de Prueba #30', 'Sinopsis generada automáticamente para el libro 30. Contiene información valiosa y formato estructurado.', 497, 40.99, 'https://picsum.photos/seed/1440/300/450', 'archivos/libro_30.pdf', 1),
(31, 2, 3, 'Libro de Prueba #31', 'Sinopsis generada automáticamente para el libro 31. Contiene información valiosa y formato estructurado.', 349, 11.99, 'https://picsum.photos/seed/2810/300/450', 'archivos/libro_31.pdf', 1),
(32, 2, 4, 'Libro de Prueba #32', 'Sinopsis generada automáticamente para el libro 32. Contiene información valiosa y formato estructurado.', 188, 10.99, 'https://picsum.photos/seed/8687/300/450', 'archivos/libro_32.pdf', 1),
(33, 3, 3, 'Libro de Prueba #33', 'Sinopsis generada automáticamente para el libro 33. Contiene información valiosa y formato estructurado.', 263, 43.99, 'https://picsum.photos/seed/660/300/450', 'archivos/libro_33.pdf', 1),
(34, 1, 5, 'Libro de Prueba #34', 'Sinopsis generada automáticamente para el libro 34. Contiene información valiosa y formato estructurado.', 132, 33.99, 'https://picsum.photos/seed/2055/300/450', 'archivos/libro_34.pdf', 1),
(35, 2, 4, 'Libro de Prueba #35', 'Sinopsis generada automáticamente para el libro 35. Contiene información valiosa y formato estructurado.', 495, 49.99, 'https://picsum.photos/seed/9198/300/450', 'archivos/libro_35.pdf', 1),
(36, 2, 5, 'Libro de Prueba #36', 'Sinopsis generada automáticamente para el libro 36. Contiene información valiosa y formato estructurado.', 356, 34.99, 'https://picsum.photos/seed/5413/300/450', 'archivos/libro_36.pdf', 1),
(37, 1, 5, 'Libro de Prueba #37', 'Sinopsis generada automáticamente para el libro 37. Contiene información valiosa y formato estructurado.', 558, 26.99, 'https://picsum.photos/seed/2733/300/450', 'archivos/libro_37.pdf', 1),
(38, 2, 4, 'Libro de Prueba #38', 'Sinopsis generada automáticamente para el libro 38. Contiene información valiosa y formato estructurado.', 458, 43.99, 'https://picsum.photos/seed/3621/300/450', 'archivos/libro_38.pdf', 1),
(39, 3, 4, 'Libro de Prueba #39', 'Sinopsis generada automáticamente para el libro 39. Contiene información valiosa y formato estructurado.', 493, 46.99, 'https://picsum.photos/seed/7740/300/450', 'archivos/libro_39.pdf', 1),
(40, 5, 3, 'Libro de Prueba #40', 'Sinopsis generada automáticamente para el libro 40. Contiene información valiosa y formato estructurado.', 560, 10.99, 'https://picsum.photos/seed/6110/300/450', 'archivos/libro_40.pdf', 1),
(41, 3, 2, 'Libro de Prueba #41', 'Sinopsis generada automáticamente para el libro 41. Contiene información valiosa y formato estructurado.', 516, 17.99, 'https://picsum.photos/seed/6458/300/450', 'archivos/libro_41.pdf', 1),
(42, 1, 4, 'Libro de Prueba #42', 'Sinopsis generada automáticamente para el libro 42. Contiene información valiosa y formato estructurado.', 480, 28.99, 'https://picsum.photos/seed/8202/300/450', 'archivos/libro_42.pdf', 1),
(43, 2, 4, 'Libro de Prueba #43', 'Sinopsis generada automáticamente para el libro 43. Contiene información valiosa y formato estructurado.', 516, 9.99, 'https://picsum.photos/seed/9817/300/450', 'archivos/libro_43.pdf', 1),
(44, 5, 2, 'Libro de Prueba #44', 'Sinopsis generada automáticamente para el libro 44. Contiene información valiosa y formato estructurado.', 599, 17.99, 'https://picsum.photos/seed/6276/300/450', 'archivos/libro_44.pdf', 1),
(45, 1, 3, 'Libro de Prueba #45', 'Sinopsis generada automáticamente para el libro 45. Contiene información valiosa y formato estructurado.', 410, 19.99, 'https://picsum.photos/seed/8696/300/450', 'archivos/libro_45.pdf', 1),
(46, 3, 4, 'Libro de Prueba #46', 'Sinopsis generada automáticamente para el libro 46. Contiene información valiosa y formato estructurado.', 358, 26.99, 'https://picsum.photos/seed/2702/300/450', 'archivos/libro_46.pdf', 1),
(47, 3, 2, 'Libro de Prueba #47', 'Sinopsis generada automáticamente para el libro 47. Contiene información valiosa y formato estructurado.', 153, 45.99, 'https://picsum.photos/seed/4117/300/450', 'archivos/libro_47.pdf', 1),
(48, 2, 4, 'Libro de Prueba #48', 'Sinopsis generada automáticamente para el libro 48. Contiene información valiosa y formato estructurado.', 133, 22.99, 'https://picsum.photos/seed/5606/300/450', 'archivos/libro_48.pdf', 1),
(49, 1, 5, 'Libro de Prueba #49', 'Sinopsis generada automáticamente para el libro 49. Contiene información valiosa y formato estructurado.', 526, 22.99, 'https://picsum.photos/seed/8171/300/450', 'archivos/libro_49.pdf', 1),
(50, 3, 5, 'Libro de Prueba #50', 'Sinopsis generada automáticamente para el libro 50. Contiene información valiosa y formato estructurado.', 289, 37.99, 'https://picsum.photos/seed/9892/300/450', 'archivos/libro_50.pdf', 1),
(51, 3, 1, 'Libro de Prueba #51', 'Sinopsis generada automáticamente para el libro 51. Contiene información valiosa y formato estructurado.', 146, 47.99, 'https://picsum.photos/seed/6333/300/450', 'archivos/libro_51.pdf', 1),
(52, 4, 5, 'Libro de Prueba #52', 'Sinopsis generada automáticamente para el libro 52. Contiene información valiosa y formato estructurado.', 599, 20.99, 'https://picsum.photos/seed/7098/300/450', 'archivos/libro_52.pdf', 1),
(53, 2, 5, 'Libro de Prueba #53', 'Sinopsis generada automáticamente para el libro 53. Contiene información valiosa y formato estructurado.', 193, 25.99, 'https://picsum.photos/seed/1722/300/450', 'archivos/libro_53.pdf', 1),
(54, 1, 3, 'Libro de Prueba #54', 'Sinopsis generada automáticamente para el libro 54. Contiene información valiosa y formato estructurado.', 381, 40.99, 'https://picsum.photos/seed/4015/300/450', 'archivos/libro_54.pdf', 1),
(55, 4, 5, 'Libro de Prueba #55', 'Sinopsis generada automáticamente para el libro 55. Contiene información valiosa y formato estructurado.', 166, 19.99, 'https://picsum.photos/seed/1257/300/450', 'archivos/libro_55.pdf', 1),
(56, 1, 5, 'Libro de Prueba #56', 'Sinopsis generada automáticamente para el libro 56. Contiene información valiosa y formato estructurado.', 231, 33.99, 'https://picsum.photos/seed/7053/300/450', 'archivos/libro_56.pdf', 1),
(57, 2, 4, 'Libro de Prueba #57', 'Sinopsis generada automáticamente para el libro 57. Contiene información valiosa y formato estructurado.', 271, 33.99, 'https://picsum.photos/seed/2182/300/450', 'archivos/libro_57.pdf', 1),
(58, 2, 2, 'Libro de Prueba #58', 'Sinopsis generada automáticamente para el libro 58. Contiene información valiosa y formato estructurado.', 367, 45.99, 'https://picsum.photos/seed/3634/300/450', 'archivos/libro_58.pdf', 1),
(59, 3, 5, 'Libro de Prueba #59', 'Sinopsis generada automáticamente para el libro 59. Contiene información valiosa y formato estructurado.', 459, 32.99, 'https://picsum.photos/seed/8545/300/450', 'archivos/libro_59.pdf', 1),
(60, 4, 4, 'Libro de Prueba #60', 'Sinopsis generada automáticamente para el libro 60. Contiene información valiosa y formato estructurado.', 413, 23.99, 'https://picsum.photos/seed/4052/300/450', 'archivos/libro_60.pdf', 1),
(61, 1, 2, 'Libro de Prueba #61', 'Sinopsis generada automáticamente para el libro 61. Contiene información valiosa y formato estructurado.', 231, 41.99, 'https://picsum.photos/seed/6156/300/450', 'archivos/libro_61.pdf', 1),
(62, 1, 3, 'Libro de Prueba #62', 'Sinopsis generada automáticamente para el libro 62. Contiene información valiosa y formato estructurado.', 510, 47.99, 'https://picsum.photos/seed/4012/300/450', 'archivos/libro_62.pdf', 1),
(63, 1, 5, 'Libro de Prueba #63', 'Sinopsis generada automáticamente para el libro 63. Contiene información valiosa y formato estructurado.', 226, 10.99, 'https://picsum.photos/seed/9837/300/450', 'archivos/libro_63.pdf', 1),
(64, 4, 2, 'Libro de Prueba #64', 'Sinopsis generada automáticamente para el libro 64. Contiene información valiosa y formato estructurado.', 552, 12.99, 'https://picsum.photos/seed/8620/300/450', 'archivos/libro_64.pdf', 1),
(65, 3, 4, 'Libro de Prueba #65', 'Sinopsis generada automáticamente para el libro 65. Contiene información valiosa y formato estructurado.', 415, 34.99, 'https://picsum.photos/seed/6813/300/450', 'archivos/libro_65.pdf', 1),
(66, 3, 4, 'Libro de Prueba #66', 'Sinopsis generada automáticamente para el libro 66. Contiene información valiosa y formato estructurado.', 185, 9.99, 'https://picsum.photos/seed/830/300/450', 'archivos/libro_66.pdf', 1),
(67, 5, 5, 'Libro de Prueba #67', 'Sinopsis generada automáticamente para el libro 67. Contiene información valiosa y formato estructurado.', 548, 10.99, 'https://picsum.photos/seed/4399/300/450', 'archivos/libro_67.pdf', 1),
(68, 4, 4, 'Libro de Prueba #68', 'Sinopsis generada automáticamente para el libro 68. Contiene información valiosa y formato estructurado.', 351, 17.99, 'https://picsum.photos/seed/1074/300/450', 'archivos/libro_68.pdf', 1),
(69, 5, 3, 'Libro de Prueba #69', 'Sinopsis generada automáticamente para el libro 69. Contiene información valiosa y formato estructurado.', 122, 11.99, 'https://picsum.photos/seed/7910/300/450', 'archivos/libro_69.pdf', 1),
(70, 3, 3, 'Libro de Prueba #70', 'Sinopsis generada automáticamente para el libro 70. Contiene información valiosa y formato estructurado.', 214, 18.99, 'https://picsum.photos/seed/6502/300/450', 'archivos/libro_70.pdf', 1),
(71, 2, 5, 'Libro de Prueba #71', 'Sinopsis generada automáticamente para el libro 71. Contiene información valiosa y formato estructurado.', 353, 41.99, 'https://picsum.photos/seed/6146/300/450', 'archivos/libro_71.pdf', 1),
(72, 2, 2, 'Libro de Prueba #72', 'Sinopsis generada automáticamente para el libro 72. Contiene información valiosa y formato estructurado.', 127, 18.99, 'https://picsum.photos/seed/9009/300/450', 'archivos/libro_72.pdf', 1),
(73, 4, 1, 'Libro de Prueba #73', 'Sinopsis generada automáticamente para el libro 73. Contiene información valiosa y formato estructurado.', 383, 36.99, 'https://picsum.photos/seed/8367/300/450', 'archivos/libro_73.pdf', 1),
(74, 4, 5, 'Libro de Prueba #74', 'Sinopsis generada automáticamente para el libro 74. Contiene información valiosa y formato estructurado.', 554, 12.99, 'https://picsum.photos/seed/5898/300/450', 'archivos/libro_74.pdf', 1),
(75, 1, 1, 'Libro de Prueba #75', 'Sinopsis generada automáticamente para el libro 75. Contiene información valiosa y formato estructurado.', 441, 26.99, 'https://picsum.photos/seed/9133/300/450', 'archivos/libro_75.pdf', 1),
(76, 5, 4, 'Libro de Prueba #76', 'Sinopsis generada automáticamente para el libro 76. Contiene información valiosa y formato estructurado.', 188, 31.99, 'https://picsum.photos/seed/9002/300/450', 'archivos/libro_76.pdf', 1),
(77, 3, 3, 'Libro de Prueba #77', 'Sinopsis generada automáticamente para el libro 77. Contiene información valiosa y formato estructurado.', 533, 28.99, 'https://picsum.photos/seed/1398/300/450', 'archivos/libro_77.pdf', 1),
(78, 3, 4, 'Libro de Prueba #78', 'Sinopsis generada automáticamente para el libro 78. Contiene información valiosa y formato estructurado.', 435, 11.99, 'https://picsum.photos/seed/3206/300/450', 'archivos/libro_78.pdf', 1),
(79, 5, 4, 'Libro de Prueba #79', 'Sinopsis generada automáticamente para el libro 79. Contiene información valiosa y formato estructurado.', 518, 14.99, 'https://picsum.photos/seed/5773/300/450', 'archivos/libro_79.pdf', 1),
(80, 3, 1, 'Libro de Prueba #80', 'Sinopsis generada automáticamente para el libro 80. Contiene información valiosa y formato estructurado.', 489, 10.99, 'https://picsum.photos/seed/2627/300/450', 'archivos/libro_80.pdf', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `lista_deseos`
--

CREATE TABLE `lista_deseos` (
  `id_deseo` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_libro` int(11) NOT NULL,
  `fecha_agregado` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidos`
--

CREATE TABLE `pedidos` (
  `id_pedido` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `fecha_pedido` timestamp NOT NULL DEFAULT current_timestamp(),
  `total` decimal(10,2) NOT NULL,
  `estado_pago` enum('pendiente','completado','fallido') DEFAULT 'pendiente',
  `metodo_pago` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `resenas`
--

CREATE TABLE `resenas` (
  `id_resena` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_libro` int(11) NOT NULL,
  `calificacion` int(11) DEFAULT NULL CHECK (`calificacion` between 1 and 5),
  `comentario` text DEFAULT NULL,
  `fecha_resena` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL,
  `nombre_completo` varchar(150) NOT NULL,
  `correo` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp(),
  `rol` enum('cliente','admin') DEFAULT 'cliente'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `autores`
--
ALTER TABLE `autores`
  ADD PRIMARY KEY (`id_autor`);

--
-- Indices de la tabla `biblioteca_digital`
--
ALTER TABLE `biblioteca_digital`
  ADD PRIMARY KEY (`id_acceso`),
  ADD KEY `id_usuario` (`id_usuario`),
  ADD KEY `id_libro` (`id_libro`);

--
-- Indices de la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id_categoria`);

--
-- Indices de la tabla `detalles_pedido`
--
ALTER TABLE `detalles_pedido`
  ADD PRIMARY KEY (`id_detalle`),
  ADD KEY `id_pedido` (`id_pedido`),
  ADD KEY `id_libro` (`id_libro`);

--
-- Indices de la tabla `libros`
--
ALTER TABLE `libros`
  ADD PRIMARY KEY (`id_libro`),
  ADD KEY `id_categoria` (`id_categoria`),
  ADD KEY `id_autor` (`id_autor`);

--
-- Indices de la tabla `lista_deseos`
--
ALTER TABLE `lista_deseos`
  ADD PRIMARY KEY (`id_deseo`),
  ADD KEY `id_usuario` (`id_usuario`),
  ADD KEY `id_libro` (`id_libro`);

--
-- Indices de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`id_pedido`),
  ADD KEY `id_usuario` (`id_usuario`);

--
-- Indices de la tabla `resenas`
--
ALTER TABLE `resenas`
  ADD PRIMARY KEY (`id_resena`),
  ADD KEY `id_usuario` (`id_usuario`),
  ADD KEY `id_libro` (`id_libro`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_usuario`),
  ADD UNIQUE KEY `correo` (`correo`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `autores`
--
ALTER TABLE `autores`
  MODIFY `id_autor` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `biblioteca_digital`
--
ALTER TABLE `biblioteca_digital`
  MODIFY `id_acceso` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id_categoria` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `detalles_pedido`
--
ALTER TABLE `detalles_pedido`
  MODIFY `id_detalle` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `libros`
--
ALTER TABLE `libros`
  MODIFY `id_libro` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;

--
-- AUTO_INCREMENT de la tabla `lista_deseos`
--
ALTER TABLE `lista_deseos`
  MODIFY `id_deseo` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `id_pedido` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `resenas`
--
ALTER TABLE `resenas`
  MODIFY `id_resena` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `biblioteca_digital`
--
ALTER TABLE `biblioteca_digital`
  ADD CONSTRAINT `biblioteca_digital_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE,
  ADD CONSTRAINT `biblioteca_digital_ibfk_2` FOREIGN KEY (`id_libro`) REFERENCES `libros` (`id_libro`) ON DELETE CASCADE;

--
-- Filtros para la tabla `detalles_pedido`
--
ALTER TABLE `detalles_pedido`
  ADD CONSTRAINT `detalles_pedido_ibfk_1` FOREIGN KEY (`id_pedido`) REFERENCES `pedidos` (`id_pedido`) ON DELETE CASCADE,
  ADD CONSTRAINT `detalles_pedido_ibfk_2` FOREIGN KEY (`id_libro`) REFERENCES `libros` (`id_libro`);

--
-- Filtros para la tabla `libros`
--
ALTER TABLE `libros`
  ADD CONSTRAINT `libros_ibfk_1` FOREIGN KEY (`id_categoria`) REFERENCES `categorias` (`id_categoria`) ON DELETE SET NULL,
  ADD CONSTRAINT `libros_ibfk_2` FOREIGN KEY (`id_autor`) REFERENCES `autores` (`id_autor`) ON DELETE SET NULL;

--
-- Filtros para la tabla `lista_deseos`
--
ALTER TABLE `lista_deseos`
  ADD CONSTRAINT `lista_deseos_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE,
  ADD CONSTRAINT `lista_deseos_ibfk_2` FOREIGN KEY (`id_libro`) REFERENCES `libros` (`id_libro`) ON DELETE CASCADE;

--
-- Filtros para la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD CONSTRAINT `pedidos_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE;

--
-- Filtros para la tabla `resenas`
--
ALTER TABLE `resenas`
  ADD CONSTRAINT `resenas_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE,
  ADD CONSTRAINT `resenas_ibfk_2` FOREIGN KEY (`id_libro`) REFERENCES `libros` (`id_libro`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
