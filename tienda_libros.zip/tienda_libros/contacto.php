<?php

declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';

$valores = [
    'nombre' => '',
    'correo' => '',
    'asunto' => '',
    'mensaje' => '',
];
$errores = [];
$enviado = false;

$textLength = static fn (string $value): int => function_exists('mb_strlen')
    ? mb_strlen($value, 'UTF-8')
    : strlen($value);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $valores['nombre'] = trim((string) ($_POST['nombre'] ?? ''));
    $valores['correo'] = trim((string) ($_POST['correo'] ?? ''));
    $valores['asunto'] = trim((string) ($_POST['asunto'] ?? ''));
    $valores['mensaje'] = trim((string) ($_POST['mensaje'] ?? ''));

    if (!verify_csrf($_POST)) {
        $errores[] = 'La solicitud no pudo validarse. Recarga la página e inténtalo de nuevo.';
    }

    if ($valores['nombre'] === '') {
        $errores[] = 'Escribe tu nombre.';
    } elseif ($textLength($valores['nombre']) > 150) {
        $errores[] = 'El nombre no puede superar los 150 caracteres.';
    }

    if ($valores['correo'] === '' || filter_var($valores['correo'], FILTER_VALIDATE_EMAIL) === false) {
        $errores[] = 'Escribe un correo electrónico válido.';
    } elseif ($textLength($valores['correo']) > 150) {
        $errores[] = 'El correo no puede superar los 150 caracteres.';
    }

    if ($valores['asunto'] === '') {
        $errores[] = 'Indica el asunto de tu mensaje.';
    } elseif ($textLength($valores['asunto']) > 150) {
        $errores[] = 'El asunto no puede superar los 150 caracteres.';
    }

    if ($valores['mensaje'] === '') {
        $errores[] = 'Escribe tu mensaje.';
    } elseif ($textLength($valores['mensaje']) > 2000) {
        $errores[] = 'El mensaje no puede superar los 2000 caracteres.';
    }

    if ($errores === []) {
        try {
            $insert = db()->prepare(
                'INSERT INTO mensajes_contacto (nombre, correo, asunto, mensaje) VALUES (?, ?, ?, ?)'
            );
            $insert->execute([
                $valores['nombre'],
                $valores['correo'],
                $valores['asunto'],
                $valores['mensaje'],
            ]);

            $enviado = true;
            $valores = [
                'nombre' => '',
                'correo' => '',
                'asunto' => '',
                'mensaje' => '',
            ];
        } catch (PDOException $exception) {
            error_log(sprintf(
                '[tienda_libros] No se pudo guardar el mensaje de contacto: %s',
                $exception->getMessage()
            ));
            $errores[] = 'No se pudo enviar el mensaje. Inténtalo de nuevo más tarde.';
        }
    }
}

$pageTitle = 'Contacto';
$activePage = 'contacto';

require __DIR__ . '/includes/header.php';
?>
<header class="bg-dark text-white py-5">
    <div class="container py-3">
        <div class="row justify-content-center text-center">
            <div class="col-lg-8">
                <span class="badge bg-warning text-dark mb-3">Estamos para ayudarte</span>
                <h1 class="display-5 fw-bold mb-3">Hablemos de libros, compras o cualquier duda.</h1>
                <p class="lead text-white-50 mb-0">
                    Escríbenos y te responderemos lo antes posible. También puedes consultar las preguntas
                    frecuentes o usar el chat de ayuda.
                </p>
            </div>
        </div>
    </div>
</header>

<main class="container py-4 py-lg-5">
    <div class="row g-4 g-lg-5">
        <div class="col-lg-5">
            <span class="badge bg-light text-dark border mb-3">Canales de atención</span>
            <h2 class="h3 fw-bold mb-3">Cercanía en cada paso</h2>
            <p class="text-muted mb-4">
                Antes de comprar, durante la descarga o después de leer: si necesitas ayuda,
                estamos disponibles para acompañarte.
            </p>

            <div class="row g-3">
                <div class="col-12">
                    <div class="card border-0 shadow-sm rounded-4">
                        <div class="card-body p-4 d-flex gap-3">
                            <span class="brand-mark flex-shrink-0">@</span>
                            <div>
                                <h3 class="h6 fw-bold mb-1">Correo electrónico</h3>
                                <a class="text-decoration-none" href="mailto:soporte@tiendalibros.com">soporte@tiendalibros.com</a>
                                <p class="small text-muted mb-0">Respondemos en horario laboral.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="card border-0 shadow-sm rounded-4">
                        <div class="card-body p-4 d-flex gap-3">
                            <span class="brand-mark flex-shrink-0">T</span>
                            <div>
                                <h3 class="h6 fw-bold mb-1">Teléfono</h3>
                                <a class="text-decoration-none" href="tel:+5215555555555">+52 1 55 5555 5555</a>
                                <p class="small text-muted mb-0">Lunes a viernes de 9:00 a 18:00.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="card border-0 shadow-sm rounded-4">
                        <div class="card-body p-4 d-flex gap-3">
                            <span class="brand-mark flex-shrink-0">H</span>
                            <div>
                                <h3 class="h6 fw-bold mb-1">Horario</h3>
                                <p class="mb-0">Lunes a viernes: 9:00 a 18:00</p>
                                <p class="small text-muted mb-0">Sábados: 10:00 a 14:00</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-7">
            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-body p-4 p-lg-5">
                    <h2 class="h4 fw-bold mb-1">Envíanos un mensaje</h2>
                    <p class="text-muted mb-4">Completa el formulario y cuéntanos cómo podemos ayudarte.</p>

                    <?php if ($enviado): ?>
                        <div class="alert alert-success" role="alert">
                            Gracias por escribirnos. Tu mensaje fue recibido y te responderemos a la brevedad.
                        </div>
                    <?php endif; ?>

                    <?php if ($errores !== []): ?>
                        <div class="alert alert-danger" role="alert">
                            <ul class="mb-0 ps-3">
                                <?php foreach ($errores as $error): ?>
                                    <li><?= e($error) ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <form method="post" action="contacto.php" novalidate>
                        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label" for="contacto-nombre">Nombre</label>
                                <input class="form-control" type="text" id="contacto-nombre" name="nombre"
                                       maxlength="150" required value="<?= e($valores['nombre']) ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label" for="contacto-correo">Correo electrónico</label>
                                <input class="form-control" type="email" id="contacto-correo" name="correo"
                                       maxlength="150" required value="<?= e($valores['correo']) ?>">
                            </div>
                            <div class="col-12">
                                <label class="form-label" for="contacto-asunto">Asunto</label>
                                <input class="form-control" type="text" id="contacto-asunto" name="asunto"
                                       maxlength="150" required value="<?= e($valores['asunto']) ?>">
                            </div>
                            <div class="col-12">
                                <label class="form-label" for="contacto-mensaje">Mensaje</label>
                                <textarea class="form-control" id="contacto-mensaje" name="mensaje" rows="6"
                                          maxlength="2000" required><?= e($valores['mensaje']) ?></textarea>
                                <div class="form-text">Máximo 2000 caracteres.</div>
                            </div>
                        </div>
                        <button class="btn btn-primary btn-lg mt-4" type="submit">Enviar mensaje</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <section class="mt-5" id="faq">
        <div class="text-center mb-4">
            <h2 class="h3 fw-bold mb-1">Preguntas frecuentes</h2>
            <p class="text-muted mb-0">Respuestas rápidas a las dudas más comunes.</p>
        </div>
        <div class="accordion shadow-sm rounded-4 overflow-hidden" id="faqAccordion">
            <div class="accordion-item border-0">
                <h3 class="accordion-header" id="faqHeadingOne">
                    <button class="accordion-button" type="button" data-bs-toggle="collapse"
                            data-bs-target="#faqOne" aria-expanded="true" aria-controls="faqOne">
                        ¿En qué formato están los libros?
                    </button>
                </h3>
                <div id="faqOne" class="accordion-collapse collapse show" aria-labelledby="faqHeadingOne"
                     data-bs-parent="#faqAccordion">
                    <div class="accordion-body text-muted">
                        Todos nuestros libros se entregan en formato PDF de alta calidad, compatible con computadora,
                        tablet y teléfono.
                    </div>
                </div>
            </div>
            <div class="accordion-item border-0">
                <h3 class="accordion-header" id="faqHeadingTwo">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                            data-bs-target="#faqTwo" aria-expanded="false" aria-controls="faqTwo">
                        ¿Cómo descargo mi libro después de comprarlo?
                    </button>
                </h3>
                <div id="faqTwo" class="accordion-collapse collapse" aria-labelledby="faqHeadingTwo"
                     data-bs-parent="#faqAccordion">
                    <div class="accordion-body text-muted">
                        Al finalizar la compra, el libro se agrega a Mi Biblioteca. Desde allí puedes descargarlo
                        con tu cuenta cuando quieras.
                    </div>
                </div>
            </div>
            <div class="accordion-item border-0" id="pagos">
                <h3 class="accordion-header" id="faqHeadingThree">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                            data-bs-target="#faqThree" aria-expanded="false" aria-controls="faqThree">
                        ¿Qué métodos de pago aceptan?
                    </button>
                </h3>
                <div id="faqThree" class="accordion-collapse collapse" aria-labelledby="faqHeadingThree"
                     data-bs-parent="#faqAccordion">
                    <div class="accordion-body text-muted">
                        El proceso actual es una demostración simulada. En producción aceptaríamos tarjetas de
                        crédito, débito y PayPal.
                    </div>
                </div>
            </div>
            <div class="accordion-item border-0">
                <h3 class="accordion-header" id="faqHeadingFour">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                            data-bs-target="#faqFour" aria-expanded="false" aria-controls="faqFour">
                        ¿Puedo solicitar un reembolso?
                    </button>
                </h3>
                <div id="faqFour" class="accordion-collapse collapse" aria-labelledby="faqHeadingFour"
                     data-bs-parent="#faqAccordion">
                    <div class="accordion-body text-muted">
                        Al ser productos digitales, las compras no son reembolsables una vez descargado el PDF.
                        Si tuviste un problema, contáctanos y revisaremos tu caso.
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
