<?php

declare(strict_types=1);
?>
<div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="loginModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="loginModalLabel">Iniciar sesión</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
            </div>
            <div class="modal-body">
                <div class="alert alert-danger d-none" id="login-error" role="alert"></div>
                <form id="login-form" novalidate>
                    <div class="mb-3">
                        <label class="form-label" for="login-correo">Correo electrónico</label>
                        <input class="form-control" type="email" id="login-correo" name="correo"
                               autocomplete="email" maxlength="150" required>
                    </div>
                    <div class="mb-4">
                        <label class="form-label" for="login-password">Contraseña</label>
                        <input class="form-control" type="password" id="login-password" name="password"
                               autocomplete="current-password" maxlength="72" required>
                    </div>
                    <button class="btn btn-primary w-100" type="submit" id="login-submit">Entrar</button>
                </form>
                <p class="text-center small text-muted mt-3 mb-0">
                    ¿No tienes una cuenta?
                    <button type="button" class="btn btn-link btn-sm p-0 align-baseline" data-open-register>Regístrate aquí</button>
                </p>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="registerModal" tabindex="-1" aria-labelledby="registerModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="registerModalLabel">Crear cuenta</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
            </div>
            <div class="modal-body">
                <div class="alert alert-danger d-none" id="register-error" role="alert"></div>
                <form id="register-form" novalidate>
                    <div class="mb-3">
                        <label class="form-label" for="register-nombre">Nombre completo</label>
                        <input class="form-control" type="text" id="register-nombre" name="nombre_completo"
                               autocomplete="name" minlength="2" maxlength="150" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="register-correo">Correo electrónico</label>
                        <input class="form-control" type="email" id="register-correo" name="correo"
                               autocomplete="email" maxlength="150" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="register-password">Contraseña</label>
                        <input class="form-control" type="password" id="register-password" name="password"
                               autocomplete="new-password" minlength="8" maxlength="72" required>
                        <div class="form-text">Mínimo 8 caracteres.</div>
                    </div>
                    <div class="mb-4">
                        <label class="form-label" for="register-password-confirm">Confirmar contraseña</label>
                        <input class="form-control" type="password" id="register-password-confirm" name="password_confirm"
                               autocomplete="new-password" minlength="8" maxlength="72" required>
                    </div>
                    <button class="btn btn-primary w-100" type="submit" id="register-submit">Crear mi cuenta</button>
                </form>
                <p class="text-center small text-muted mt-3 mb-0">
                    ¿Ya tienes una cuenta?
                    <button type="button" class="btn btn-link btn-sm p-0 align-baseline" data-open-login>Inicia sesión</button>
                </p>
            </div>
        </div>
    </div>
</div>

<div class="offcanvas offcanvas-end" tabindex="-1" id="cartOffcanvas" aria-labelledby="cartOffcanvasLabel">
    <div class="offcanvas-header border-bottom">
        <h5 class="offcanvas-title" id="cartOffcanvasLabel">Tu carrito</h5>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Cerrar"></button>
    </div>
    <div class="offcanvas-body d-flex flex-column">
        <div id="cart-items" class="flex-grow-1">
            <div class="text-center py-5">
                <div class="spinner-border spinner-border-sm text-primary" role="status"></div>
                <p class="small text-muted mt-2 mb-0">Cargando carrito...</p>
            </div>
        </div>
        <div class="border-top pt-3 mt-3">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <span class="text-muted">Total</span>
                <strong class="fs-5" id="cart-total">S/ 0.00</strong>
            </div>
            <div class="alert alert-danger d-none py-2 small" id="cart-message" role="alert"></div>
            <button class="btn btn-primary w-100" type="button" id="checkout-button">Finalizar compra</button>
            <button class="btn btn-link text-muted w-100 mt-1" type="button" id="clear-cart-button">Vaciar carrito</button>
            <p class="small text-muted text-center mt-2 mb-0">Pago simulado para demostración. Recibirás acceso inmediato en PDF.</p>
        </div>
    </div>
</div>

<div class="toast-container position-fixed bottom-0 end-0 p-3" id="toast-container"></div>
