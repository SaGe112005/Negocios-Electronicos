<?php

declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';

if (session_status() === PHP_SESSION_NONE) {
    $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');

    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.cookie_httponly', '1');
    ini_set('session.cookie_samesite', 'Lax');
    ini_set('session.gc_maxlifetime', '7200');

    if ($isHttps) {
        ini_set('session.cookie_secure', '1');
    }

    session_name('TIENDALIBROSSESSID');
    session_start();
}

header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('Referrer-Policy: strict-origin-when-cross-origin');

function e(?string $value): string
{
    return htmlspecialchars($value ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function json_response(array $payload, int $status = 200): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function json_error(string $message, int $status = 400, array $extra = []): never
{
    json_response(array_merge([
        'success' => false,
        'message' => $message,
    ], $extra), $status);
}

function request_data(): array
{
    $data = $_POST;
    $contentType = $_SERVER['CONTENT_TYPE'] ?? '';

    if (stripos($contentType, 'application/json') !== false) {
        $raw = file_get_contents('php://input');
        if ($raw !== false && trim($raw) !== '') {
            $decoded = json_decode($raw, true);
            if (!is_array($decoded)) {
                json_error('El cuerpo JSON enviado no es válido.', 400);
            }
            $data = array_merge($data, $decoded);
        }
    }

    return $data;
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf_token'];
}

function rotate_csrf_token(): string
{
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf_token'];
}

function verify_csrf(array $data = []): bool
{
    $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? ($data['csrf_token'] ?? '');
    $sessionToken = $_SESSION['csrf_token'] ?? '';

    return is_string($token) && $sessionToken !== '' && hash_equals($sessionToken, $token);
}

function require_csrf(array $data = []): void
{
    if (!verify_csrf($data)) {
        json_error('La solicitud no pudo validarse. Recarga la página e inténtalo de nuevo.', 419);
    }
}

function auth_user(): ?array
{
    $user = $_SESSION['user'] ?? null;
    return is_array($user) ? $user : null;
}

function require_api_auth(): array
{
    $user = auth_user();
    if ($user === null) {
        json_error('Debes iniciar sesión para continuar.', 401);
    }

    return $user;
}

function require_page_auth(): array
{
    $user = auth_user();
    if ($user === null) {
        header('Location: index.php?login=1');
        exit;
    }

    return $user;
}

function user_session_payload(array $user): array
{
    return [
        'id_usuario' => (int) $user['id_usuario'],
        'nombre_completo' => $user['nombre_completo'],
        'correo' => $user['correo'],
        'rol' => $user['rol'],
    ];
}

function login_attempts_locked(): bool
{
    $attempts = $_SESSION['login_attempts'] ?? [];
    if (!is_array($attempts)) {
        return false;
    }

    $cutoff = time() - 600;
    $attempts = array_values(array_filter($attempts, static fn ($timestamp) => (int) $timestamp >= $cutoff));
    $_SESSION['login_attempts'] = $attempts;

    return count($attempts) >= 5;
}

function login_record_failure(): void
{
    $attempts = $_SESSION['login_attempts'] ?? [];
    if (!is_array($attempts)) {
        $attempts = [];
    }
    $attempts[] = time();
    $_SESSION['login_attempts'] = $attempts;
}

function login_clear_attempts(): void
{
    unset($_SESSION['login_attempts']);
}
