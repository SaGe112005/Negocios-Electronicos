<?php

declare(strict_types=1);

function cart_ids(): array
{
    $cart = $_SESSION['cart'] ?? [];
    if (!is_array($cart)) {
        return [];
    }

    $ids = array_map('intval', $cart);
    $ids = array_filter($ids, static fn (int $id) => $id > 0);

    return array_values(array_unique($ids));
}

function cart_persist(array $ids): void
{
    $_SESSION['cart'] = array_values(array_unique(array_map('intval', $ids)));
}

function cart_clear(): void
{
    unset($_SESSION['cart']);
}

function cart_get(PDO $pdo, ?int $userId = null): array
{
    $ids = cart_ids();
    if ($ids === []) {
        return [
            'items' => [],
            'total' => 0.0,
            'count' => 0,
        ];
    }

    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $sql = "SELECT l.id_libro, l.titulo, l.precio, l.portada_url, l.cantidad_paginas,
                   c.nombre AS categoria, a.nombre_completo AS autor
            FROM libros l
            LEFT JOIN categorias c ON c.id_categoria = l.id_categoria
            LEFT JOIN autores a ON a.id_autor = l.id_autor
            WHERE l.activo = 1 AND l.id_libro IN ($placeholders)";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($ids);
    $books = [];
    foreach ($stmt->fetchAll() as $book) {
        $books[(int) $book['id_libro']] = $book;
    }

    $owned = [];
    if ($userId !== null) {
        $ownedStmt = $pdo->prepare(
            "SELECT id_libro FROM biblioteca_digital WHERE id_usuario = ? AND id_libro IN ($placeholders)"
        );
        $ownedStmt->execute(array_merge([$userId], $ids));
        $owned = array_map('intval', $ownedStmt->fetchAll(PDO::FETCH_COLUMN));
    }

    $items = [];
    $total = 0.0;
    $validIds = [];

    foreach ($ids as $id) {
        if (!isset($books[$id]) || in_array($id, $owned, true)) {
            continue;
        }

        $book = $books[$id];
        $price = (float) $book['precio'];
        $total += $price;
        $validIds[] = $id;

        $items[] = [
            'id_libro' => $id,
            'titulo' => $book['titulo'],
            'precio' => $price,
            'portada_url' => $book['portada_url'],
            'cantidad_paginas' => (int) $book['cantidad_paginas'],
            'categoria' => $book['categoria'],
            'autor' => $book['autor'],
        ];
    }

    if ($validIds !== $ids) {
        cart_persist($validIds);
    }

    return [
        'items' => $items,
        'total' => round($total, 2),
        'count' => count($items),
    ];
}
