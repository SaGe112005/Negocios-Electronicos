<?php

declare(strict_types=1);

require_once __DIR__ . '/cart.php';

final class CheckoutException extends RuntimeException
{
    public function __construct(string $message, private int $statusCode = 400)
    {
        parent::__construct($message);
    }

    public function statusCode(): int
    {
        return $this->statusCode;
    }
}

function ensure_transacciones_pago_table(PDO $pdo): void
{
    static $ensured = false;

    if ($ensured) {
        return;
    }

    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS transacciones_pago (
            id_transaccion INT(11) NOT NULL AUTO_INCREMENT,
            id_pedido INT(11) NOT NULL,
            id_usuario INT(11) NOT NULL,
            metodo_pago VARCHAR(50) NOT NULL,
            monto DECIMAL(10,2) NOT NULL,
            estado VARCHAR(20) NOT NULL DEFAULT 'aprobado',
            referencia VARCHAR(80) NOT NULL,
            creado_en TIMESTAMP NOT NULL DEFAULT current_timestamp(),
            PRIMARY KEY (id_transaccion),
            UNIQUE KEY uq_transacciones_pago_referencia (referencia),
            KEY idx_transacciones_pago_usuario (id_usuario),
            KEY idx_transacciones_pago_pedido (id_pedido)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci"
    );

    $ensured = true;
}

function generar_referencia_pago(): string
{
    return 'MOCK-' . date('YmdHis') . '-' . strtoupper(bin2hex(random_bytes(4)));
}

function procesar_compra_simulada(PDO $pdo, int $userId, string $metodoPago): array
{
    $cart = cart_get($pdo, $userId);
    if ($cart['items'] === []) {
        throw new CheckoutException('Tu carrito está vacío.', 400);
    }

    $ids = array_map(
        static fn (array $item): int => (int) $item['id_libro'],
        $cart['items']
    );
    $placeholders = implode(',', array_fill(0, count($ids), '?'));

    ensure_transacciones_pago_table($pdo);

    $pdo->beginTransaction();

    try {
        $booksStmt = $pdo->prepare(
            "SELECT id_libro, titulo, precio
             FROM libros
             WHERE activo = 1 AND id_libro IN ($placeholders)
             FOR UPDATE"
        );
        $booksStmt->execute($ids);

        $books = [];
        foreach ($booksStmt->fetchAll() as $book) {
            $books[(int) $book['id_libro']] = $book;
        }

        if (count($books) !== count($ids)) {
            $pdo->rollBack();
            throw new CheckoutException('Alguno de los libros ya no está disponible. Revisa tu carrito.', 409);
        }

        $ownedStmt = $pdo->prepare(
            "SELECT id_libro FROM biblioteca_digital
             WHERE id_usuario = ? AND id_libro IN ($placeholders)
             FOR UPDATE"
        );
        $ownedStmt->execute(array_merge([$userId], $ids));

        if ($ownedStmt->fetch()) {
            $pdo->rollBack();
            throw new CheckoutException('Ya tienes uno o más de estos libros en tu biblioteca.', 409);
        }

        $total = 0.0;
        foreach ($ids as $id) {
            $total += (float) $books[$id]['precio'];
        }
        $total = round($total, 2);

        $orderStmt = $pdo->prepare(
            "INSERT INTO pedidos (id_usuario, total, estado_pago, metodo_pago)
             VALUES (?, ?, 'completado', ?)"
        );
        $orderStmt->execute([$userId, $total, $metodoPago]);
        $orderId = (int) $pdo->lastInsertId();

        $detailStmt = $pdo->prepare(
            'INSERT INTO detalles_pedido (id_pedido, id_libro, precio_unitario) VALUES (?, ?, ?)'
        );

        $libraryStmt = $pdo->prepare(
            'INSERT INTO biblioteca_digital (id_usuario, id_libro) VALUES (?, ?)'
        );

        foreach ($ids as $id) {
            $detailStmt->execute([$orderId, $id, (float) $books[$id]['precio']]);
            $libraryStmt->execute([$userId, $id]);
        }

        $reference = generar_referencia_pago();
        $transactionStmt = $pdo->prepare(
            "INSERT INTO transacciones_pago
                (id_pedido, id_usuario, metodo_pago, monto, estado, referencia)
             VALUES (?, ?, ?, ?, 'aprobado', ?)"
        );
        $transactionStmt->execute([$orderId, $userId, $metodoPago, $total, $reference]);

        $pdo->commit();
        cart_clear();

        return [
            'id_pedido' => $orderId,
            'total' => $total,
            'libros' => count($ids),
            'metodo_pago' => $metodoPago,
            'referencia' => $reference,
        ];
    } catch (Throwable $exception) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        throw $exception;
    }
}
