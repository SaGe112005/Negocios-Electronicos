<?php

declare(strict_types=1);

$pageTitle = $pageTitle ?? 'Tienda de Libros Digitales';
$activePage = $activePage ?? '';
$navUser = auth_user();
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Compra y descarga libros digitales en PDF de forma segura.">
    <meta name="csrf-token" content="<?= e(csrf_token()) ?>">
    <title><?= e($pageTitle) ?> | Tienda de Libros</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/app.css">
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top shadow-sm">
    <div class="container">
        <a class="navbar-brand fw-bold d-flex align-items-center gap-2" href="index.php">
            <span class="brand-mark">TL</span>
            <span>Tienda de Libros</span>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar"
                aria-controls="mainNavbar" aria-expanded="false" aria-label="Abrir navegación">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="mainNavbar">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link <?= $activePage === 'catalogo' ? 'active' : '' ?>" href="index.php">Catálogo</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $activePage === 'nosotros' ? 'active' : '' ?>" href="nosotros.php">Nosotros</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $activePage === 'contacto' ? 'active' : '' ?>" href="contacto.php">Contacto</a>
                </li>
                <li class="nav-item <?= $navUser === null ? 'd-none' : '' ?>" data-auth-user>
                    <a class="nav-link <?= $activePage === 'biblioteca' ? 'active' : '' ?>" href="biblioteca.php">Mi Biblioteca</a>
                </li>
            </ul>
            <div class="d-flex flex-wrap align-items-center gap-2">
                <div class="d-flex gap-2 <?= $navUser !== null ? 'd-none' : '' ?>" data-auth-guest>
                    <button class="btn btn-outline-light btn-sm" type="button" data-open-login>Iniciar sesión</button>
                    <button class="btn btn-warning btn-sm" type="button" data-open-register>Registrarse</button>
                </div>
                <div class="dropdown <?= $navUser === null ? 'd-none' : '' ?>" data-auth-user>
                    <button class="btn btn-outline-light btn-sm dropdown-toggle" type="button"
                            id="userMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                        <span data-user-name><?= e($navUser['nombre_completo'] ?? '') ?></span>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userMenuButton">
                        <li><a class="dropdown-item" href="biblioteca.php">Mi Biblioteca</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><button class="dropdown-item text-danger" type="button" id="logout-button">Cerrar sesión</button></li>
                    </ul>
                </div>
                <button class="btn btn-light btn-sm position-relative" type="button" data-bs-toggle="offcanvas"
                        data-bs-target="#cartOffcanvas" aria-controls="cartOffcanvas">
                    Carrito
                    <span id="cart-count" class="badge rounded-pill bg-danger ms-1">0</span>
                </button>
            </div>
        </div>
    </div>
</nav>
