<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

set_exception_handler(static function (Throwable $exception): void {
    error_log(sprintf(
        '[tienda_libros] %s en %s:%d',
        $exception->getMessage(),
        $exception->getFile(),
        $exception->getLine()
    ));

    if (!headers_sent()) {
        http_response_code(500);
        header('Content-Type: application/json; charset=utf-8');
    }

    echo json_encode([
        'success' => false,
        'message' => 'Ocurrió un error interno. Inténtalo de nuevo más tarde.',
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
});
