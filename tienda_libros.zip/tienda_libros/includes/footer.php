<?php

declare(strict_types=1);

$pageScripts = $pageScripts ?? [];
?>
<footer class="site-footer text-white-50 pt-5 pb-4 mt-5">
    <div class="container">
        <div class="row g-4 g-lg-5">
            <div class="col-lg-4">
                <a class="navbar-brand fw-bold d-inline-flex align-items-center gap-2 text-white mb-3" href="index.php">
                    <span class="brand-mark">TL</span>
                    <span>Tienda de Libros</span>
                </a>
                <p class="small mb-3">
                    Una biblioteca digital curada para lectores curiosos: narrativa, fantasía,
                    programación, finanzas y crecimiento personal en formato PDF.
                </p>
                <p class="small mb-1">
                    <a href="mailto:soporte@tiendalibros.com">soporte@tiendalibros.com</a>
                </p>
                <p class="small mb-0">Lunes a viernes, 9:00 a 18:00.</p>
            </div>

            <div class="col-6 col-lg-2">
                <h2 class="h6 text-white text-uppercase small fw-bold mb-3">Explorar</h2>
                <ul class="list-unstyled small d-grid gap-2 mb-0">
                    <li><a class="footer-link" href="index.php">Catálogo</a></li>
                    <li><a class="footer-link" href="nosotros.php">Nosotros</a></li>
                    <li><a class="footer-link" href="contacto.php">Contacto</a></li>
                    <li><a class="footer-link" href="biblioteca.php">Mi Biblioteca</a></li>
                </ul>
            </div>

            <div class="col-6 col-lg-2">
                <h2 class="h6 text-white text-uppercase small fw-bold mb-3">Soporte</h2>
                <ul class="list-unstyled small d-grid gap-2 mb-0">
                    <li><a class="footer-link" href="contacto.php#faq">Preguntas frecuentes</a></li>
                    <li><a class="footer-link" href="#" data-chat-open>Chat de ayuda</a></li>
                    <li><a class="footer-link" href="contacto.php#pagos">Métodos de pago</a></li>
                    <li><a class="footer-link" href="contacto.php#faq">Reembolsos</a></li>
                </ul>
            </div>

            <div class="col-lg-4">
                <h2 class="h6 text-white text-uppercase small fw-bold mb-3">Compra con confianza</h2>
                <p class="small mb-3">
                    Acceso inmediato después de la compra, descargas protegidas por cuenta y
                    libros disponibles en tu biblioteca digital.
                </p>
                <a class="btn btn-outline-light btn-sm" href="index.php">Explorar títulos</a>
            </div>
        </div>

        <div class="row g-4 align-items-center footer-trust mt-4 pt-4">
            <div class="col-lg-5">
                <h2 class="h6 text-white text-uppercase small fw-bold mb-3">Seguridad y confianza</h2>
                <div class="d-flex align-items-start gap-3">
                    <span class="trust-icon" aria-hidden="true">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                             stroke-linecap="round" stroke-linejoin="round">
                            <path d="M12 3 5 6v5c0 4.5 3 8.2 7 10 4-1.8 7-5.5 7-10V6l-7-3z"></path>
                            <path d="m9 12 2 2 4-4"></path>
                        </svg>
                    </span>
                    <p class="small mb-0">
                        Pagos procesados con cifrado SSL, descargas protegidas por cuenta y
                        soporte para resolver cualquier inconveniente con tu compra.
                    </p>
                </div>
            </div>

            <div class="col-sm-6 col-lg-4">
                <h2 class="h6 text-white text-uppercase small fw-bold mb-3">Métodos de pago</h2>
                <ul class="list-unstyled d-flex flex-wrap gap-2 mb-0" aria-label="Métodos de pago aceptados">
                    <li>
                        <span class="payment-badge payment-badge--visa" role="img" aria-label="Visa">
                            <svg viewBox="0 0 24 24" aria-hidden="true">
                                <path d="M9.112 8.262 5.97 15.758H3.92L2.374 9.775c-.094-.368-.175-.503-.461-.658C1.447 8.864.677 8.627 0 8.479l.046-.217h3.3a.904.904 0 0 1 .894.764l.817 4.338 2.018-5.102zm8.033 5.049c.008-1.979-2.736-2.088-2.717-2.972.006-.269.262-.555.822-.628a3.66 3.66 0 0 1 1.913.336l.34-1.59a5.207 5.207 0 0 0-1.814-.333c-1.917 0-3.266 1.02-3.278 2.479-.012 1.079.963 1.68 1.698 2.04.756.367 1.01.603 1.006.931-.005.504-.602.725-1.16.734-.975.015-1.54-.263-1.992-.473l-.351 1.642c.453.208 1.289.39 2.156.398 2.037 0 3.37-1.006 3.377-2.564m5.061 2.447H24l-1.565-7.496h-1.656a.883.883 0 0 0-.826.55l-2.909 6.946h2.036l.405-1.12h2.488zm-2.163-2.656 1.02-2.815.588 2.815zm-8.16-4.84-1.603 7.496H8.34l1.605-7.496z"></path>
                            </svg>
                            <span>Visa</span>
                        </span>
                    </li>
                    <li>
                        <span class="payment-badge payment-badge--mastercard" role="img" aria-label="Mastercard">
                            <svg viewBox="0 0 24 24" aria-hidden="true">
                                <path d="M11.343 18.031c.058.049.12.098.181.146-1.177.783-2.59 1.238-4.107 1.238C3.32 19.416 0 16.096 0 12c0-4.095 3.32-7.416 7.416-7.416 1.518 0 2.931.456 4.105 1.238-.06.051-.12.098-.165.15C9.6 7.489 8.595 9.688 8.595 12c0 2.311 1.001 4.51 2.748 6.031zm5.241-13.447c-1.52 0-2.931.456-4.105 1.238.06.051.12.098.165.15C14.4 7.489 15.405 9.688 15.405 12c0 2.31-1.001 4.507-2.748 6.031-.058.049-.12.098-.181.146 1.177.783 2.588 1.238 4.107 1.238C20.68 19.416 24 16.096 24 12c0-4.094-3.32-7.416-7.416-7.416zM12 6.174c-.096.075-.189.15-.28.231C10.156 7.764 9.169 9.765 9.169 12c0 2.236.987 4.236 2.551 5.595.09.08.185.158.28.232.096-.074.189-.152.28-.232 1.563-1.359 2.551-3.359 2.551-5.595 0-2.235-.987-4.236-2.551-5.595-.09-.08-.184-.156-.28-.231z"></path>
                            </svg>
                            <span>Mastercard</span>
                        </span>
                    </li>
                    <li>
                        <span class="payment-badge payment-badge--paypal" role="img" aria-label="PayPal">
                            <svg viewBox="0 0 24 24" aria-hidden="true">
                                <path d="M7.016 19.198h-4.2a.562.562 0 0 1-.555-.65L5.093.584A.692.692 0 0 1 5.776 0h7.222c3.417 0 5.904 2.488 5.846 5.5-.006.25-.027.5-.066.747A6.794 6.794 0 0 1 12.071 12H8.743a.69.69 0 0 0-.682.583l-.325 2.056-.013.083-.692 4.39-.015.087zM19.79 6.142c-.01.087-.01.175-.023.261a7.76 7.76 0 0 1-7.695 6.598H9.007l-.283 1.795-.013.083-.692 4.39-.134.843-.014.088H6.86l-.497 3.15a.562.562 0 0 0 .555.65h3.612c.34 0 .63-.249.683-.585l.952-6.031a.692.692 0 0 1 .683-.584h2.126a6.793 6.793 0 0 0 6.707-5.752c.306-1.95-.466-3.744-1.89-4.906z"></path>
                            </svg>
                            <span>PayPal</span>
                        </span>
                    </li>
                </ul>
            </div>

            <div class="col-sm-6 col-lg-3">
                <h2 class="h6 text-white text-uppercase small fw-bold mb-3">Síguenos</h2>
                <div class="d-flex gap-2">
                    <a class="social-link" href="https://www.instagram.com/" target="_blank"
                       rel="noopener noreferrer" aria-label="Instagram">
                        <svg viewBox="0 0 24 24" aria-hidden="true">
                            <path d="M7.0301.084c-1.2768.0602-2.1487.264-2.911.5634-.7888.3075-1.4575.72-2.1228 1.3877-.6652.6677-1.075 1.3368-1.3802 2.127-.2954.7638-.4956 1.6365-.552 2.914-.0564 1.2775-.0689 1.6882-.0626 4.947.0062 3.2586.0206 3.6671.0825 4.9473.061 1.2765.264 2.1482.5635 2.9107.308.7889.72 1.4573 1.388 2.1228.6679.6655 1.3365 1.0743 2.1285 1.38.7632.295 1.6361.4961 2.9134.552 1.2773.056 1.6884.069 4.9462.0627 3.2578-.0062 3.668-.0207 4.9478-.0814 1.28-.0607 2.147-.2652 2.9098-.5633.7889-.3086 1.4578-.72 2.1228-1.3881.665-.6682 1.0745-1.3378 1.3795-2.1284.2957-.7632.4966-1.636.552-2.9124.056-1.2809.0692-1.6898.063-4.948-.0063-3.2583-.021-3.6668-.0817-4.9465-.0607-1.2797-.264-2.1487-.5633-2.9117-.3084-.7889-.72-1.4568-1.3876-2.1228C21.2982 1.33 20.628.9208 19.8378.6165 19.074.321 18.2017.1197 16.9244.0645 15.6471.0093 15.236-.005 11.977.0014 8.718.0076 8.31.0215 7.0301.0839m.1402 21.6932c-1.17-.0509-1.8053-.2453-2.2287-.408-.5606-.216-.96-.4771-1.3819-.895-.422-.4178-.6811-.8186-.9-1.378-.1644-.4234-.3624-1.058-.4171-2.228-.0595-1.2645-.072-1.6442-.079-4.848-.007-3.2037.0053-3.583.0607-4.848.05-1.169.2456-1.805.408-2.2282.216-.5613.4762-.96.895-1.3816.4188-.4217.8184-.6814 1.3783-.9003.423-.1651 1.0575-.3614 2.227-.4171 1.2655-.06 1.6447-.072 4.848-.079 3.2033-.007 3.5835.005 4.8495.0608 1.169.0508 1.8053.2445 2.228.408.5608.216.96.4754 1.3816.895.4217.4194.6816.8176.9005 1.3787.1653.4217.3617 1.056.4169 2.2263.0602 1.2655.0739 1.645.0796 4.848.0058 3.203-.0055 3.5834-.061 4.848-.051 1.17-.245 1.8055-.408 2.2294-.216.5604-.4763.96-.8954 1.3814-.419.4215-.8181.6811-1.3783.9-.4224.1649-1.0577.3617-2.2262.4174-1.2656.0595-1.6448.072-4.8493.079-3.2045.007-3.5825-.006-4.848-.0608M16.953 5.5864A1.44 1.44 0 1 0 18.39 4.144a1.44 1.44 0 0 0-1.437 1.4424M5.8385 12.012c.0067 3.4032 2.7706 6.1557 6.173 6.1493 3.4026-.0065 6.157-2.7701 6.1506-6.1733-.0065-3.4032-2.771-6.1565-6.174-6.1498-3.403.0067-6.156 2.771-6.1496 6.1738M8 12.0077a4 4 0 1 1 4.008 3.9921A3.9996 3.9996 0 0 1 8 12.0077"></path>
                        </svg>
                    </a>
                    <a class="social-link" href="https://www.facebook.com/" target="_blank"
                       rel="noopener noreferrer" aria-label="Facebook">
                        <svg viewBox="0 0 24 24" aria-hidden="true">
                            <path d="M9.101 23.691v-7.98H6.627v-3.667h2.474v-1.58c0-4.085 1.848-5.978 5.858-5.978.401 0 .955.042 1.468.103a8.68 8.68 0 0 1 1.141.195v3.325a8.623 8.623 0 0 0-.653-.036 26.805 26.805 0 0 0-.733-.009c-.707 0-1.259.096-1.675.309a1.686 1.686 0 0 0-.679.622c-.258.42-.374.995-.374 1.752v1.297h3.919l-.386 2.103-.287 1.564h-3.246v8.245C19.396 23.238 24 18.179 24 12.044c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.628 3.874 10.35 9.101 11.647Z"></path>
                        </svg>
                    </a>
                </div>
            </div>
        </div>

        <hr class="border-secondary opacity-25 my-4">

        <div class="d-flex flex-column flex-md-row justify-content-between gap-2 small">
            <span>&copy; <?= date('Y') ?> Tienda de Libros. Todos los derechos reservados.</span>
            <span>Libros digitales en formato PDF.</span>
        </div>
    </div>
</footer>

<div class="chat-widget" id="chat-widget">
    <section class="chat-panel" id="chat-panel" aria-label="Asistente virtual" aria-hidden="true">
        <div class="chat-header">
            <div>
                <strong class="d-block">Asistente Tienda de Libros</strong>
                <span class="small text-white-50">Respuestas inmediatas</span>
            </div>
            <button type="button" class="btn-close btn-close-white" id="chat-close" aria-label="Cerrar chat"></button>
        </div>

        <div class="chat-messages" id="chat-messages" aria-live="polite">
            <div class="chat-message bot system">
                <span class="chat-message-author">Neiky · Asistente virtual</span>
                <span>hola soy neiky, tu asistente virtual que trabaja 24/7 sin ningun tipo de pago</span>
            </div>
        </div>

        <div class="chat-suggestions">
            <button type="button" class="btn btn-sm btn-outline-secondary chat-suggestion"
                    data-chat-suggestion="¿Qué formato tienen los libros?">Formatos</button>
            <button type="button" class="btn btn-sm btn-outline-secondary chat-suggestion"
                    data-chat-suggestion="¿Cómo descargo mi libro?">Descargas</button>
            <button type="button" class="btn btn-sm btn-outline-secondary chat-suggestion"
                    data-chat-suggestion="¿Qué métodos de pago aceptan?">Pagos</button>
        </div>

        <form class="chat-form" id="chat-form">
            <label class="visually-hidden" for="chat-input">Mensaje</label>
            <input class="form-control form-control-sm" id="chat-input" name="mensaje" type="text"
                   maxlength="500" placeholder="Escribe tu mensaje..." autocomplete="off" required>
            <button class="btn btn-primary btn-sm" id="chat-send" type="submit">Enviar</button>
        </form>
    </section>

    <button class="chat-toggle" type="button" id="chat-toggle" aria-controls="chat-panel"
            aria-expanded="false" aria-label="Hablar con neiky">
        <span class="chat-toggle-icon" aria-hidden="true">🤖</span>
        <span>Hablar con neiky</span>
    </button>
</div>

<?php require __DIR__ . '/modals.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/app.js"></script>
<?php foreach ($pageScripts as $script): ?>
    <script src="<?= e($script) ?>"></script>
<?php endforeach; ?>
</body>
</html>
