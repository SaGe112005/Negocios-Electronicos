<?php

declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';

$idLibro = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT, [
    'options' => ['min_range' => 1],
]);

if ($idLibro === false) {
    http_response_code(400);
    $pageTitle = 'Libro no válido';
    $activePage = 'catalogo';
    require __DIR__ . '/includes/header.php';
    ?>
    <main class="container py-5">
        <div class="card border-0 shadow-sm">
            <div class="card-body p-4 p-lg-5 text-center">
                <h1 class="h3 fw-bold mb-2">El libro solicitado no es válido</h1>
                <p class="text-muted mb-4">El identificador recibido no corresponde a un libro del catálogo.</p>
                <a class="btn btn-primary" href="index.php">Volver al catálogo</a>
            </div>
        </div>
    </main>
    <?php
    require __DIR__ . '/includes/footer.php';
    exit;
}

$pdo = db();
$stmt = $pdo->prepare(
    'SELECT l.id_libro, l.titulo, l.descripcion, l.cantidad_paginas, l.precio, l.portada_url,
            c.nombre AS categoria, a.nombre_completo AS autor
     FROM libros l
     LEFT JOIN categorias c ON c.id_categoria = l.id_categoria
     LEFT JOIN autores a ON a.id_autor = l.id_autor
     WHERE l.id_libro = ? AND l.activo = 1'
);
$stmt->execute([$idLibro]);
$libro = $stmt->fetch();

if ($libro === false) {
    http_response_code(404);
    $pageTitle = 'Libro no encontrado';
    $activePage = 'catalogo';
    require __DIR__ . '/includes/header.php';
    ?>
    <main class="container py-5">
        <div class="card border-0 shadow-sm">
            <div class="card-body p-4 p-lg-5 text-center">
                <h1 class="h3 fw-bold mb-2">Libro no encontrado</h1>
                <p class="text-muted mb-4">El libro que buscas no existe o ya no está disponible.</p>
                <a class="btn btn-primary" href="index.php">Volver al catálogo</a>
            </div>
        </div>
    </main>
    <?php
    require __DIR__ . '/includes/footer.php';
    exit;
}

$user = auth_user();
$commentErrors = [];
$commentValues = [
    'nombre_usuario' => $user !== null ? (string) $user['nombre_completo'] : '',
    'calificacion' => '5',
    'texto_comentario' => '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $commentValues['nombre_usuario'] = trim((string) ($_POST['nombre_usuario'] ?? ''));
    $commentValues['calificacion'] = trim((string) ($_POST['calificacion'] ?? ''));
    $commentValues['texto_comentario'] = trim((string) ($_POST['texto_comentario'] ?? ''));

    if (!verify_csrf($_POST)) {
        $commentErrors[] = 'La solicitud no pudo validarse. Recarga la página e inténtalo de nuevo.';
    }

    $nombreUsuario = $commentValues['nombre_usuario'];
    $calificacion = filter_var($commentValues['calificacion'], FILTER_VALIDATE_INT, [
        'options' => ['min_range' => 1, 'max_range' => 5],
    ]);
    $textoComentario = $commentValues['texto_comentario'];
    $textLength = static fn (string $value): int => function_exists('mb_strlen')
        ? mb_strlen($value, 'UTF-8')
        : strlen($value);

    if ($nombreUsuario === '') {
        $commentErrors[] = 'Escribe tu nombre para publicar la reseña.';
    } elseif ($textLength($nombreUsuario) > 150) {
        $commentErrors[] = 'El nombre no puede superar los 150 caracteres.';
    }

    if ($calificacion === false) {
        $commentErrors[] = 'Selecciona una calificación entre 1 y 5 estrellas.';
    }

    if ($textoComentario === '') {
        $commentErrors[] = 'Escribe el texto de tu reseña.';
    } elseif ($textLength($textoComentario) > 2000) {
        $commentErrors[] = 'La reseña no puede superar los 2000 caracteres.';
    }

    if ($commentErrors === []) {
        try {
            $insert = $pdo->prepare(
                'INSERT INTO comentarios_libros (id_libro, nombre_usuario, calificacion, texto_comentario)
                 VALUES (?, ?, ?, ?)'
            );
            $insert->execute([$idLibro, $nombreUsuario, (int) $calificacion, $textoComentario]);

            header('Location: detalle_libro.php?id=' . $idLibro . '&comentario=ok#comentarios', true, 303);
            exit;
        } catch (PDOException $exception) {
            error_log(sprintf(
                '[tienda_libros] No se pudo guardar la reseña del libro %d: %s',
                $idLibro,
                $exception->getMessage()
            ));
            $commentErrors[] = 'No se pudo guardar la reseña. Inténtalo de nuevo más tarde.';
        }
    }
}

$stmt = $pdo->prepare(
    'SELECT id, nombre_usuario, calificacion, texto_comentario, fecha_creacion
     FROM comentarios_libros
     WHERE id_libro = ?
     ORDER BY fecha_creacion DESC, id DESC'
);
$stmt->execute([$idLibro]);
$comentarios = $stmt->fetchAll();

$totalComentarios = count($comentarios);
$promedio = null;
if ($totalComentarios > 0) {
    $suma = array_sum(array_map(static fn (array $comentario): int => (int) $comentario['calificacion'], $comentarios));
    $promedio = round($suma / $totalComentarios, 1);
}

$mostrarExito = ($_GET['comentario'] ?? '') === 'ok';

$renderStars = static function (int $rating): string {
    $rating = max(0, min(5, $rating));
    return str_repeat('★', $rating) . str_repeat('☆', 5 - $rating);
};

$pageTitle = (string) $libro['titulo'];
$activePage = 'catalogo';
$portada = $libro['portada_url'] ?: 'assets/img/portada-no-disponible.svg';
$precio = 'S/ ' . number_format((float) $libro['precio'], 2, '.', ',');
$sinopsis = nl2br(e((string) ($libro['descripcion'] ?: 'Sin sinopsis disponible.')));

require __DIR__ . '/includes/header.php';
?>
<main class="container py-4 py-lg-5">
    <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb mb-0">
            <li class="breadcrumb-item"><a href="index.php">Catálogo</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?= e((string) $libro['titulo']) ?></li>
        </ol>
    </nav>

    <div class="row g-4 g-lg-5 align-items-start">
        <div class="col-md-4 col-lg-3">
            <div class="position-sticky" style="top: 6rem;">
                <img class="detail-cover img-fluid rounded-3 shadow-sm" src="<?= e($portada) ?>"
                     alt="Portada de <?= e((string) $libro['titulo']) ?>"
                     onerror="this.onerror=null;this.src='assets/img/portada-no-disponible.svg'">
            </div>
        </div>
        <div class="col-md-8 col-lg-9">
            <span class="badge bg-light text-dark border mb-3">
                <?= e((string) ($libro['categoria'] ?: 'Sin categoría')) ?>
            </span>
            <h1 class="display-6 fw-bold mb-2"><?= e((string) $libro['titulo']) ?></h1>
            <p class="fs-5 text-muted mb-3">
                por <?= e((string) ($libro['autor'] ?: 'Autor desconocido')) ?>
            </p>

            <div class="d-flex flex-wrap align-items-center gap-2 mb-4">
                <?php if ($promedio !== null): ?>
                    <span class="rating-stars text-warning" aria-hidden="true"><?= e($renderStars((int) round($promedio))) ?></span>
                    <span class="fw-semibold"><?= e(number_format($promedio, 1, '.', ',')) ?> de 5</span>
                    <span class="text-muted small">(<?= $totalComentarios ?> <?= $totalComentarios === 1 ? 'reseña' : 'reseñas' ?>)</span>
                <?php else: ?>
                    <span class="text-muted small">Todavía no hay reseñas. ¡Sé el primero en opinar!</span>
                <?php endif; ?>
            </div>

            <div class="d-flex align-items-baseline gap-2 mb-4">
                <span class="display-6 fw-bold text-primary"><?= e($precio) ?></span>
                <span class="text-muted">PEN</span>
            </div>

            <dl class="row small mb-4">
                <dt class="col-sm-3 col-lg-2">Autor</dt>
                <dd class="col-sm-9 col-lg-10"><?= e((string) ($libro['autor'] ?: 'Autor desconocido')) ?></dd>
                <dt class="col-sm-3 col-lg-2">Categoría</dt>
                <dd class="col-sm-9 col-lg-10"><?= e((string) ($libro['categoria'] ?: 'Sin categoría')) ?></dd>
                <dt class="col-sm-3 col-lg-2">Páginas</dt>
                <dd class="col-sm-9 col-lg-10"><?= (int) $libro['cantidad_paginas'] ?> páginas</dd>
                <dt class="col-sm-3 col-lg-2">Formato</dt>
                <dd class="col-sm-9 col-lg-10">PDF digital</dd>
            </dl>

            <div class="d-flex flex-column flex-sm-row gap-2">
                <button type="button" class="btn btn-primary btn-lg" data-add-to-cart="<?= (int) $libro['id_libro'] ?>">
                    Agregar al carrito
                </button>
                <a class="btn btn-outline-secondary btn-lg" href="index.php">Volver al catálogo</a>
            </div>
        </div>
    </div>

    <section class="mt-5">
        <h2 class="h4 fw-bold mb-3">Sinopsis</h2>
        <div class="card border-0 shadow-sm">
            <div class="card-body p-4">
                <p class="mb-0 text-break"><?= $sinopsis ?></p>
            </div>
        </div>
    </section>

    <section class="mt-5" id="comentarios">
        <div class="d-flex flex-column flex-sm-row justify-content-between align-items-sm-end gap-2 mb-3">
            <div>
                <h2 class="h4 fw-bold mb-1">Reseñas del libro</h2>
                <p class="text-muted mb-0">Comparte tu opinión con otros lectores.</p>
            </div>
            <span class="badge bg-dark"><?= $totalComentarios ?> <?= $totalComentarios === 1 ? 'reseña' : 'reseñas' ?></span>
        </div>

        <?php if ($mostrarExito): ?>
            <div class="alert alert-success" role="alert">
                Tu reseña fue publicada correctamente.
            </div>
        <?php endif; ?>

        <?php if ($commentErrors !== []): ?>
            <div class="alert alert-danger" role="alert">
                <ul class="mb-0 ps-3">
                    <?php foreach ($commentErrors as $error): ?>
                        <li><?= e($error) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form class="card border-0 shadow-sm mb-4" method="post" action="detalle_libro.php?id=<?= (int) $libro['id_libro'] ?>#comentarios" novalidate>
            <div class="card-body p-4">
                <h3 class="h5 fw-bold mb-3">Escribe tu reseña</h3>
                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">

                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label" for="nombre_usuario">Tu nombre</label>
                        <input class="form-control" type="text" id="nombre_usuario" name="nombre_usuario"
                               maxlength="150" required value="<?= e($commentValues['nombre_usuario']) ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="calificacion">Calificación</label>
                        <select class="form-select" id="calificacion" name="calificacion" required>
                            <?php for ($estrella = 5; $estrella >= 1; $estrella--): ?>
                                <option value="<?= $estrella ?>" <?= (string) $estrella === $commentValues['calificacion'] ? 'selected' : '' ?>>
                                    <?= e($renderStars($estrella)) ?> (<?= $estrella ?>)
                                </option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div class="col-12">
                        <label class="form-label" for="texto_comentario">Comentario</label>
                        <textarea class="form-control" id="texto_comentario" name="texto_comentario" rows="4"
                                  maxlength="2000" required><?= e($commentValues['texto_comentario']) ?></textarea>
                        <div class="form-text">Máximo 2000 caracteres.</div>
                    </div>
                </div>

                <button class="btn btn-primary mt-3" type="submit">Publicar reseña</button>
            </div>
        </form>

        <?php if ($comentarios === []): ?>
            <div class="card border-0 shadow-sm">
                <div class="card-body p-4 text-center text-muted">
                    Aún no hay reseñas para este libro.
                </div>
            </div>
        <?php else: ?>
            <div class="row g-3">
                <?php foreach ($comentarios as $comentario): ?>
                    <?php
                    $calificacionComentario = (int) $comentario['calificacion'];
                    $timestamp = strtotime((string) $comentario['fecha_creacion']);
                    $fecha = $timestamp !== false
                        ? date('d/m/Y H:i', $timestamp)
                        : (string) $comentario['fecha_creacion'];
                    ?>
                    <div class="col-12">
                        <article class="card border-0 shadow-sm">
                            <div class="card-body p-4">
                                <div class="d-flex flex-column flex-sm-row justify-content-between gap-1 mb-2">
                                    <div>
                                        <h3 class="h6 fw-bold mb-1"><?= e((string) $comentario['nombre_usuario']) ?></h3>
                                        <div class="rating-stars text-warning" aria-label="<?= $calificacionComentario ?> de 5 estrellas">
                                            <?= e($renderStars($calificacionComentario)) ?>
                                        </div>
                                    </div>
                                    <span class="small text-muted"><?= e($fecha) ?></span>
                                </div>
                                <p class="mb-0 text-break"><?= nl2br(e((string) $comentario['texto_comentario'])) ?></p>
                            </div>
                        </article>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
