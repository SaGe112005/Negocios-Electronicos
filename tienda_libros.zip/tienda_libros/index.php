<?php

declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';

$pageTitle = 'Catálogo de libros digitales';
$activePage = 'catalogo';
$pageScripts = ['assets/js/catalogo.js'];

$topLibros = [];

try {
    $topLibrosStmt = db()->query(
        "SELECT l.id_libro, l.titulo, l.descripcion, l.cantidad_paginas, l.precio, l.portada_url,
                c.nombre AS categoria, a.nombre_completo AS autor,
                COALESCE(v.unidades_vendidas, 0) AS unidades_vendidas,
                COALESCE(r.promedio_valoracion, 0) AS promedio_valoracion,
                COALESCE(r.total_valoraciones, 0) AS total_valoraciones
         FROM libros l
         LEFT JOIN categorias c ON c.id_categoria = l.id_categoria
         LEFT JOIN autores a ON a.id_autor = l.id_autor
         LEFT JOIN (
             SELECT dp.id_libro, COUNT(*) AS unidades_vendidas
             FROM detalles_pedido dp
             INNER JOIN pedidos p ON p.id_pedido = dp.id_pedido
             WHERE p.estado_pago = 'completado'
             GROUP BY dp.id_libro
         ) v ON v.id_libro = l.id_libro
         LEFT JOIN (
             SELECT id_libro, AVG(calificacion) AS promedio_valoracion, COUNT(*) AS total_valoraciones
             FROM comentarios_libros
             GROUP BY id_libro
         ) r ON r.id_libro = l.id_libro
         WHERE l.activo = 1
         ORDER BY unidades_vendidas DESC, promedio_valoracion DESC, total_valoraciones DESC, l.id_libro ASC
         LIMIT 5"
    );
    $topLibros = $topLibrosStmt->fetchAll();
} catch (Throwable $error) {
    $topLibros = [];
}

$portadaFallback = 'assets/img/portada-no-disponible.svg';
$portadaDe = static function (array $libro) use ($portadaFallback): string {
    $portada = trim((string) ($libro['portada_url'] ?? ''));

    return $portada !== '' ? $portada : $portadaFallback;
};

$heroBooks = array_values(array_slice($topLibros, 0, 3));
$heroBook = $heroBooks[0] ?? null;

require __DIR__ . '/includes/header.php';
?>
<header class="hero text-white">
    <div class="container py-5">
        <div class="row align-items-center g-4 g-lg-5">
            <div class="col-lg-7">
                <span class="badge bg-warning text-dark mb-3">Biblioteca digital</span>
                <h1 class="display-5 fw-bold mb-3">Tu próxima lectura, a un clic de distancia.</h1>
                <p class="lead text-white-50 mb-4">
                    Explora novelas, programación, finanzas y más. Compra tus libros y descarga tus PDFs al instante.
                </p>
                <div class="d-flex flex-wrap align-items-center gap-3">
                    <a class="btn btn-warning btn-lg" href="#catalogo">Explorar catálogo</a>
                    <span class="small text-white-50">Acceso inmediato · PDF · Compra segura</span>
                </div>
            </div>
            <div class="col-lg-5">
                <div class="hero-visual" aria-hidden="true">
                    <div class="hero-visual-glow"></div>

                    <?php if (isset($heroBooks[1])): ?>
                        <div class="hero-book hero-book--back">
                            <img src="<?= e($portadaDe($heroBooks[1])) ?>" alt="" loading="lazy"
                                 onerror="this.onerror=null;this.src='<?= e($portadaFallback) ?>'">
                        </div>
                    <?php endif; ?>

                    <?php if (isset($heroBooks[2])): ?>
                        <div class="hero-book hero-book--front">
                            <img src="<?= e($portadaDe($heroBooks[2])) ?>" alt="" loading="lazy"
                                 onerror="this.onerror=null;this.src='<?= e($portadaFallback) ?>'">
                        </div>
                    <?php endif; ?>

                    <div class="hero-device">
                        <div class="hero-device-toolbar">
                            <span class="hero-device-dots"><i></i><i></i><i></i></span>
                            <span class="hero-device-file">mi-biblioteca.pdf</span>
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                 stroke-linecap="round" stroke-linejoin="round">
                                <path d="M12 3v12"></path>
                                <path d="m7 10 5 5 5-5"></path>
                                <path d="M5 21h14"></path>
                            </svg>
                        </div>
                        <div class="hero-device-screen">
                            <div class="hero-device-cover">
                                <img src="<?= e($heroBook !== null ? $portadaDe($heroBook) : $portadaFallback) ?>"
                                     alt="" loading="lazy"
                                     onerror="this.onerror=null;this.src='<?= e($portadaFallback) ?>'">
                            </div>
                            <div class="hero-device-info">
                                <span class="hero-device-kicker">Leyendo ahora</span>
                                <strong class="hero-device-title">
                                    <?= e($heroBook['titulo'] ?? 'Tu próxima lectura') ?>
                                </strong>
                                <span class="hero-device-author">
                                    <?= e($heroBook['autor'] ?? 'Biblioteca digital') ?>
                                </span>
                                <span class="hero-line hero-line--full"></span>
                                <span class="hero-line"></span>
                                <span class="hero-line hero-line--short"></span>
                                <span class="hero-progress"><span></span></span>
                            </div>
                        </div>
                        <div class="hero-device-footer">
                            <span>PDF</span>
                            <span><?= e((string) ($heroBook['cantidad_paginas'] ?? 0)) ?> páginas</span>
                        </div>
                    </div>

                    <div class="hero-pdf-chip">
                        <span class="hero-pdf-chip-icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                 stroke-linecap="round" stroke-linejoin="round">
                                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                                <path d="M14 2v6h6"></path>
                                <path d="M9 15h6"></path>
                                <path d="M9 18h4"></path>
                            </svg>
                        </span>
                        <span>
                            <strong>Descarga inmediata</strong>
                            <small>Acceso protegido</small>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>

<main>
    <?php if ($topLibros !== []): ?>
        <section class="top-books-section py-5" aria-labelledby="top-books-title">
            <div class="container">
                <div class="row align-items-end g-3 mb-4 mb-lg-5">
                    <div class="col-lg-8">
                        <span class="top-books-kicker">Ranking editorial</span>
                        <h2 class="display-6 fw-bold text-white mb-2" id="top-books-title">Top 5 Mejores Libros</h2>
                        <p class="text-white-50 mb-0">
                            Los títulos más vendidos y mejor valorados por nuestra comunidad.
                        </p>
                    </div>
                    <div class="col-lg-4 text-lg-end">
                        <span class="top-books-note">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                 stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                <path d="M8 21h8"></path>
                                <path d="M12 17v4"></path>
                                <path d="M7 4h10v4a5 5 0 0 1-10 0V4z"></path>
                                <path d="M17 5h3v2a3 3 0 0 1-3 3"></path>
                                <path d="M7 5H4v2a3 3 0 0 0 3 3"></path>
                            </svg>
                            Actualizado cada semana
                        </span>
                    </div>
                </div>

                <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-xl-5 g-4">
                    <?php foreach ($topLibros as $index => $libro): ?>
                        <?php $rank = $index + 1; ?>
                        <div class="col">
                            <article class="ranking-card card border-0 shadow-lg h-100">
                                <a class="ranking-cover" href="detalle_libro.php?id=<?= (int) $libro['id_libro'] ?>"
                                   aria-label="Ver detalle de <?= e($libro['titulo']) ?>">
                                    <img class="ranking-cover-img" src="<?= e($portadaDe($libro)) ?>"
                                         alt="Portada de <?= e($libro['titulo']) ?>" loading="lazy"
                                         onerror="this.onerror=null;this.src='<?= e($portadaFallback) ?>'">
                                    <span class="ranking-position" aria-hidden="true"><?= $rank ?></span>
                                    <span class="ranking-badge <?= $rank === 1 ? 'ranking-badge--gold' : '' ?>">
                                        <?= $rank === 1 ? 'Top Ventas' : 'Tendencia' ?>
                                    </span>
                                </a>
                                <span class="ranking-watermark" aria-hidden="true"><?= $rank ?></span>
                                <div class="card-body d-flex flex-column p-3">
                                    <span class="ranking-category"><?= e($libro['categoria'] ?? 'Sin categoría') ?></span>
                                    <h3 class="h6 fw-bold mb-1 line-clamp-title">
                                        <a class="text-decoration-none text-dark"
                                           href="detalle_libro.php?id=<?= (int) $libro['id_libro'] ?>">
                                            <?= e($libro['titulo']) ?>
                                        </a>
                                    </h3>
                                    <p class="small text-muted mb-2"><?= e($libro['autor'] ?? 'Autor desconocido') ?></p>
                                    <div class="d-flex align-items-center justify-content-between mb-3">
                                        <span class="ranking-price">S/ <?= number_format((float) $libro['precio'], 2, '.', ',') ?></span>
                                        <span class="small text-muted"><?= (int) $libro['cantidad_paginas'] ?> págs.</span>
                                    </div>
                                    <a class="btn btn-sm ranking-btn w-100 mt-auto"
                                       href="detalle_libro.php?id=<?= (int) $libro['id_libro'] ?>">
                                        Ver libro
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                             stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                            <path d="M5 12h14"></path>
                                            <path d="m13 6 6 6-6 6"></path>
                                        </svg>
                                    </a>
                                </div>
                            </article>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
    <?php endif; ?>

    <div class="container py-4 py-lg-5" id="catalogo">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-end gap-2 mb-4">
            <div>
                <h2 class="h3 fw-bold mb-1">Catálogo</h2>
                <p class="text-muted mb-0">Encuentra tu próximo libro por título, categoría o autor.</p>
            </div>
            <div class="small text-muted" id="resultado-total" aria-live="polite"></div>
        </div>

        <form class="card border-0 shadow-sm mb-4" id="filtros-catalogo">
            <div class="card-body">
                <div class="row g-3 align-items-end">
                    <div class="col-lg-4">
                        <label class="form-label" for="filtro-busqueda">Buscar</label>
                        <input class="form-control" type="search" id="filtro-busqueda" name="busqueda"
                               placeholder="Título, autor o descripción" maxlength="100">
                    </div>
                    <div class="col-6 col-lg-3">
                        <label class="form-label" for="filtro-categoria">Categoría</label>
                        <select class="form-select" id="filtro-categoria" name="categoria">
                            <option value="">Todas</option>
                        </select>
                    </div>
                    <div class="col-6 col-lg-3">
                        <label class="form-label" for="filtro-autor">Autor</label>
                        <select class="form-select" id="filtro-autor" name="autor">
                            <option value="">Todos</option>
                        </select>
                    </div>
                    <div class="col-lg-2 d-grid">
                        <button class="btn btn-outline-secondary" type="button" id="limpiar-filtros">Limpiar filtros</button>
                    </div>
                </div>
            </div>
        </form>

        <div class="alert alert-danger d-none" id="catalogo-error" role="alert"></div>

        <div id="catalogo-cargando" class="text-center py-5">
            <div class="spinner-border text-primary" role="status"></div>
            <p class="text-muted mt-3 mb-0">Cargando libros...</p>
        </div>

        <div class="row g-4" id="catalogo-grid"></div>

        <div class="text-center py-5 d-none" id="catalogo-vacio">
            <h3 class="h5">No encontramos libros</h3>
            <p class="text-muted mb-0">Prueba cambiando la búsqueda o los filtros seleccionados.</p>
        </div>

        <nav class="mt-5" aria-label="Paginación del catálogo">
            <ul class="pagination justify-content-center" id="catalogo-paginacion"></ul>
        </nav>
    </div>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
