-- =====================================================================
-- Actualización del catálogo de libros (tabla `libros`)
-- No se modifican `precio` ni `cantidad_paginas`.
-- Se reemplazan títulos y sinopsis de relleno y se corrige el autor
-- para que cada libro sea coherente con su categoría.
-- =====================================================================

START TRANSACTION;

-- ---------------------------------------------------------------------
-- 1. Autores reales necesarios para los libros asignados
-- ---------------------------------------------------------------------
INSERT INTO `autores` (`id_autor`, `nombre_completo`, `biografia`) VALUES
(6,  'J.R.R. Tolkien',        'Escritor y filólogo británico, autor de El hobbit y El Señor de los Anillos.'),
(7,  'George R.R. Martin',    'Novelista estadounidense conocido por la saga Canción de hielo y fuego.'),
(8,  'C.S. Lewis',            'Escritor británico, autor de Las crónicas de Narnia.'),
(9,  'James Clear',           'Escritor y conferencista estadounidense especializado en hábitos y mejora continua.'),
(10, 'Dale Carnegie',         'Escritor estadounidense pionero en libros de relaciones humanas y autoayuda.'),
(11, 'Napoleon Hill',         'Escritor estadounidense conocido por sus obras sobre el éxito y la riqueza.'),
(12, 'Stephen R. Covey',      'Autor y consultor estadounidense especializado en liderazgo y gestión personal.'),
(13, 'Viktor E. Frankl',      'Psiquiatra y neurólogo austriaco, fundador de la logoterapia.'),
(14, 'Robin Sharma',          'Escritor canadiense de liderazgo y desarrollo personal.'),
(15, 'Eckhart Tolle',         'Maestro espiritual y escritor alemán radicado en Canadá.'),
(16, 'Rhonda Byrne',          'Escritora y productora australiana conocida por El secreto.'),
(17, 'Mark Manson',           'Escritor estadounidense de desarrollo personal y ensayo.'),
(18, 'Angela Duckworth',      'Psicóloga estadounidense e investigadora de la perseverancia y el éxito.'),
(19, 'Carol S. Dweck',        'Psicóloga estadounidense conocida por sus estudios sobre la mentalidad.'),
(20, 'Robert C. Martin',      'Ingeniero de software y autor de referencia en diseño y código limpio.'),
(21, 'Martin Fowler',         'Ingeniero de software británico, autor y divulgador de arquitectura y refactorización.'),
(22, 'Andrew Hunt',           'Desarrollador y autor estadounidense, coautor de El programador pragmático.'),
(23, 'Brian W. Kernighan',    'Científico de la computación canadiense, coautor de El lenguaje de programación C.'),
(24, 'Bjarne Stroustrup',     'Científico de la computación danés, creador del lenguaje C++.'),
(25, 'Joshua Bloch',          'Ingeniero de software estadounidense, autor de Java efectivo.'),
(26, 'Kent Beck',             'Ingeniero de software estadounidense, pionero de Extreme Programming y TDD.'),
(27, 'Eric Evans',            'Ingeniero de software estadounidense, autor de Domain-Driven Design.'),
(28, 'Steve McConnell',       'Ingeniero de software y autor estadounidense especializado en calidad y gestión.'),
(29, 'Thomas H. Cormen',      'Científico de la computación estadounidense, coautor de Introducción a los algoritmos.'),
(30, 'Harold Abelson',        'Profesor e investigador del MIT, coautor de SICP.'),
(31, 'Ian Goodfellow',        'Investigador de inteligencia artificial y coautor de Aprendizaje profundo.'),
(32, 'David Flanagan',        'Programador y autor estadounidense de manuales técnicos sobre JavaScript.'),
(33, 'Douglas Crockford',     'Programador estadounidense, impulsor de JSON y autor de JavaScript: The Good Parts.'),
(34, 'Benjamin Graham',       'Economista e inversor británico-estadounidense, padre de la inversión en valor.'),
(35, 'Burton G. Malkiel',     'Economista estadounidense, autor de Un paseo aleatorio por Wall Street.'),
(36, 'Richard Brealey',       'Economista británico, coautor de Principios de finanzas corporativas.'),
(37, 'Tom Copeland',          'Consultor y autor especializado en valoración y finanzas corporativas.'),
(38, 'Nassim Nicholas Taleb', 'Ensayista y matemático libanés-estadounidense, autor de El cisne negro.')
ON DUPLICATE KEY UPDATE
  `nombre_completo` = VALUES(`nombre_completo`),
  `biografia` = VALUES(`biografia`);

-- ---------------------------------------------------------------------
-- 2. Biografías reales de los autores que ya existían
-- ---------------------------------------------------------------------
UPDATE `autores`
SET `biografia` = CASE `id_autor`
  WHEN 1 THEN 'Inversionista y escritor estadounidense, autor de Padre Rico, Padre Pobre.'
  WHEN 2 THEN 'Escritora británica, creadora de la saga Harry Potter.'
  WHEN 3 THEN 'Ingeniero de software finlandés, creador del núcleo Linux.'
  WHEN 4 THEN 'Escritor estadounidense de novelas de terror, suspenso y fantasía.'
  WHEN 5 THEN 'Escritora chilena conocida por La casa de los espíritus y Eva Luna.'
END
WHERE `id_autor` IN (1, 2, 3, 4, 5);

-- ---------------------------------------------------------------------
-- 3. Catálogo: Novelas (id_categoria = 1)
-- ---------------------------------------------------------------------
UPDATE `libros` SET `id_autor` = 4, `titulo` = 'El resplandor',
  `descripcion` = 'Jack Torrance acepta el puesto de vigilante en el hotel Overlook para escribir y reconstruir su familia. El aislamiento y una presencia maligna despiertan la violencia que acecha en el lugar.'
WHERE `id_libro` = 3;

UPDATE `libros` SET `id_autor` = 4, `titulo` = 'It',
  `descripcion` = 'Un grupo de amigos de Derry se enfrenta a una entidad que adopta la forma de sus peores miedos. Veintisiete años después, los adultos regresan para cumplir una promesa y terminar lo que empezaron.'
WHERE `id_libro` = 10;

UPDATE `libros` SET `id_autor` = 4, `titulo` = 'Carrie',
  `descripcion` = 'Carrie White, una adolescente humillada por sus compañeros y su madre fanática, descubre que posee poderes telequinéticos. La broma cruel del baile de graduación desata una venganza devastadora.'
WHERE `id_libro` = 13;

UPDATE `libros` SET `id_autor` = 4, `titulo` = 'Misery',
  `descripcion` = 'Paul Sheldon, escritor de novelas románticas, es rescatado por una admiradora obsesiva tras un accidente. Atrapado en su casa, deberá escribir el final que ella exige para sobrevivir.'
WHERE `id_libro` = 17;

UPDATE `libros` SET `id_autor` = 4, `titulo` = 'La hora del vampiro',
  `descripcion` = 'Ben Mears regresa a la casa de su infancia y descubre que un antiguo mal ha empezado a extenderse. El pueblo se convierte en escenario de una epidemia vampírica.'
WHERE `id_libro` = 34;

UPDATE `libros` SET `id_autor` = 4, `titulo` = 'La torre oscura I: El pistolero',
  `descripcion` = 'Roland Deschain, el último pistolero, persigue al hombre de negro a través de un mundo desolado. Su búsqueda de la Torre Oscura lo lleva a sacrificios y encuentros decisivos.'
WHERE `id_libro` = 37;

UPDATE `libros` SET `id_autor` = 4, `titulo` = 'Cementerio de animales',
  `descripcion` = 'Louis Creed se muda con su familia cerca de un cementerio indígena que devuelve la vida a los muertos. Cuando la tragedia golpea, la línea entre el amor y el horror se rompe.'
WHERE `id_libro` = 42;

UPDATE `libros` SET `id_autor` = 4, `titulo` = 'Doctor Sueño',
  `descripcion` = 'Danny Torrance, ahora adulto, usa su don para ayudar a morir a pacientes terminales. Su camino se cruza con Abra, una niña con un poder inmenso, y con una secta que se alimenta de él.'
WHERE `id_libro` = 45;

UPDATE `libros` SET `id_autor` = 5, `titulo` = 'La casa de los espíritus',
  `descripcion` = 'La saga de la familia Trueba recorre cuatro generaciones marcadas por amores, secretos y luchas políticas. Clara, con sus poderes sobrenaturales, sostiene la memoria de un linaje inolvidable.'
WHERE `id_libro` = 49;

UPDATE `libros` SET `id_autor` = 5, `titulo` = 'Eva Luna',
  `descripcion` = 'Eva Luna, nacida de una sirvienta y un indio, aprende a contar historias para sobrevivir. Su imaginación la lleva a cruzar caminos con personajes que transforman su destino.'
WHERE `id_libro` = 54;

UPDATE `libros` SET `id_autor` = 5, `titulo` = 'De amor y de sombra',
  `descripcion` = 'Una periodista y un fotógrafo descubren una fosa común que revela los crímenes de una dictadura. La investigación los enfrenta al peligro y a un amor que desafía el miedo.'
WHERE `id_libro` = 56;

UPDATE `libros` SET `id_autor` = 5, `titulo` = 'Paula',
  `descripcion` = 'Isabel Allende escribe a su hija Paula, en coma, un relato íntimo de su historia familiar. La memoria se convierte en una carta de amor y en un testimonio de pérdida.'
WHERE `id_libro` = 61;

UPDATE `libros` SET `id_autor` = 5, `titulo` = 'Hija de la fortuna',
  `descripcion` = 'Eliza Sommers, abandonada por su amante en la fiebre del oro de California, emprende un viaje de independencia. Su historia entrelaza pasión, fortuna y libertad.'
WHERE `id_libro` = 62;

UPDATE `libros` SET `id_autor` = 5, `titulo` = 'Retrato en sepia',
  `descripcion` = 'Aurora del Valle reconstruye su pasado a través de fotografías y recuerdos familiares. La novela explora los secretos de su familia y el peso de la historia chilena.'
WHERE `id_libro` = 63;

UPDATE `libros` SET `id_autor` = 5, `titulo` = 'La isla bajo el mar',
  `descripcion` = 'Zarité, esclava en Saint-Domingue, lucha por su libertad en medio de la revolución haitiana. Su valentía la lleva a convertirse en dueña de su propio destino.'
WHERE `id_libro` = 75;

-- ---------------------------------------------------------------------
-- 4. Catálogo: Fantasía (id_categoria = 4)
-- ---------------------------------------------------------------------
UPDATE `libros` SET `id_autor` = 2, `titulo` = 'Harry Potter y la piedra filosofal',
  `descripcion` = 'Harry Potter descubre en su undécimo cumpleaños que es un mago y que su destino está ligado a una escuela de magia. En Hogwarts hará amigos, enemigos y enfrentará un secreto oculto.'
WHERE `id_libro` = 6;

UPDATE `libros` SET `id_autor` = 2, `titulo` = 'Harry Potter y la cámara secreta',
  `descripcion` = 'Un monstruo petrifica a los estudiantes de Hogwarts y las sospechas apuntan a Harry. Con la ayuda de Ron y Hermione, deberá descubrir la verdad sobre la Cámara de los Secretos.'
WHERE `id_libro` = 7;

UPDATE `libros` SET `id_autor` = 2, `titulo` = 'Harry Potter y el prisionero de Azkaban',
  `descripcion` = 'Sirius Black escapa de la prisión mágica y todos creen que busca a Harry. El joven mago investiga el pasado de sus padres mientras los dementores acechan la escuela.'
WHERE `id_libro` = 8;

UPDATE `libros` SET `id_autor` = 2, `titulo` = 'Harry Potter y el cáliz de fuego',
  `descripcion` = 'Hogwarts acoge el Torneo de los Tres Magos y un nombre inesperado sale del cáliz. Harry deberá sobrevivir a pruebas mortales y a la amenaza del retorno de Voldemort.'
WHERE `id_libro` = 12;

UPDATE `libros` SET `id_autor` = 2, `titulo` = 'Harry Potter y la Orden del Fénix',
  `descripcion` = 'Harry y sus amigos forman el Ejército de Dumbledore ante la negación del Ministerio. Mientras tanto, una profecía y una guerra silenciosa se ciernen sobre el mundo mágico.'
WHERE `id_libro` = 14;

UPDATE `libros` SET `id_autor` = 2, `titulo` = 'Harry Potter y el misterio del príncipe',
  `descripcion` = 'Harry encuentra un libro de pociones con anotaciones misteriosas y sospecha de Draco Malfoy. El pasado de Voldemort y el sacrificio de Dumbledore marcan el inicio del final.'
WHERE `id_libro` = 19;

UPDATE `libros` SET `id_autor` = 2, `titulo` = 'Harry Potter y las Reliquias de la Muerte',
  `descripcion` = 'Harry, Ron y Hermione abandonan Hogwarts para destruir los horrocruxes. La búsqueda de las Reliquias de la Muerte los lleva a la batalla definitiva contra Voldemort.'
WHERE `id_libro` = 22;

UPDATE `libros` SET `id_autor` = 2, `titulo` = 'Animales fantásticos y dónde encontrarlos',
  `descripcion` = 'Newt Scamander llega a Nueva York con una maleta llena de criaturas mágicas. Un escape accidental desata una aventura que revela tensiones en el mundo mágico.'
WHERE `id_libro` = 23;

UPDATE `libros` SET `id_autor` = 2, `titulo` = 'Los cuentos de Beedle el Bardo',
  `descripcion` = 'Una colección de relatos mágicos que Hermione lega a futuras generaciones. Cada cuento encierra una lección sobre el poder, la muerte y la sabiduría.'
WHERE `id_libro` = 24;

UPDATE `libros` SET `id_autor` = 2, `titulo` = 'Quidditch a través de los tiempos',
  `descripcion` = 'Un tratado sobre la historia, las reglas y las jugadas del deporte más popular de la comunidad mágica. Incluye anécdotas y curiosidades sobre los equipos de Quidditch.'
WHERE `id_libro` = 27;

UPDATE `libros` SET `id_autor` = 6, `titulo` = 'El hobbit',
  `descripcion` = 'Bilbo Bolsón deja la comodidad de la Comarca para acompañar a Thorin y su compañía. En el viaje encuentra el Anillo Único y descubre un valor que no sabía que tenía.'
WHERE `id_libro` = 52;

UPDATE `libros` SET `id_autor` = 6, `titulo` = 'La comunidad del anillo',
  `descripcion` = 'Frodo hereda un anillo de poder y debe destruirlo en el Monte del Destino. Una comunidad de hobbits, elfos, enanos y humanos lo acompaña en una misión casi imposible.'
WHERE `id_libro` = 55;

UPDATE `libros` SET `id_autor` = 6, `titulo` = 'Las dos torres',
  `descripcion` = 'La Comunidad se ha dividido y cada grupo enfrenta su propio camino hacia la guerra. Frodo y Sam continúan hacia Mordor mientras los demás resisten el avance de Sauron.'
WHERE `id_libro` = 60;

UPDATE `libros` SET `id_autor` = 7, `titulo` = 'Juego de tronos',
  `descripcion` = 'Las grandes casas de Poniente compiten por el Trono de Hierro mientras un antiguo peligro despierta en el norte. Ned Stark descubre que el honor puede costar la vida.'
WHERE `id_libro` = 64;

UPDATE `libros` SET `id_autor` = 7, `titulo` = 'Choque de reyes',
  `descripcion` = 'Cinco reyes reclaman el trono y la guerra desgarra los Siete Reinos. Mientras tanto, en el norte y al otro lado del mar, fuerzas antiguas y nuevas se preparan.'
WHERE `id_libro` = 68;

UPDATE `libros` SET `id_autor` = 8, `titulo` = 'El león, la bruja y el armario',
  `descripcion` = 'Los hermanos Pevensie descubren Narnia a través de un armario mágico. Con la ayuda de Aslan, deberán liberar el reino del invierno eterno de la Bruja Blanca.'
WHERE `id_libro` = 73;

UPDATE `libros` SET `id_autor` = 8, `titulo` = 'El príncipe Caspian',
  `descripcion` = 'Narnia ha caído bajo el dominio de los telmarinos y Caspian reclama su trono. Los Pevensie regresan para ayudar a restaurar la paz y el equilibrio del reino.'
WHERE `id_libro` = 74;

-- ---------------------------------------------------------------------
-- 5. Catálogo: Autosuperación (id_categoria = 2)
-- ---------------------------------------------------------------------
UPDATE `libros` SET `id_autor` = 9, `titulo` = 'Hábitos atómicos',
  `descripcion` = 'James Clear explica cómo pequeñas mejoras diarias generan resultados extraordinarios. El libro ofrece un método práctico para construir buenos hábitos y abandonar los malos.'
WHERE `id_libro` = 2;

UPDATE `libros` SET `id_autor` = 10, `titulo` = 'Cómo ganar amigos e influir sobre las personas',
  `descripcion` = 'Dale Carnegie reúne principios para mejorar las relaciones personales y profesionales. Sus consejos se basan en la empatía, la escucha y el interés genuino por los demás.'
WHERE `id_libro` = 9;

UPDATE `libros` SET `id_autor` = 11, `titulo` = 'Piense y hágase rico',
  `descripcion` = 'Napoleon Hill sistematiza los principios del éxito y la mentalidad de la riqueza. El libro propone metas claras, fe y perseverancia como bases para alcanzar la prosperidad.'
WHERE `id_libro` = 15;

UPDATE `libros` SET `id_autor` = 12, `titulo` = 'Los 7 hábitos de la gente altamente efectiva',
  `descripcion` = 'Stephen R. Covey propone siete hábitos para pasar de la dependencia a la interdependencia. El libro combina principios de carácter, gestión personal y liderazgo.'
WHERE `id_libro` = 21;

UPDATE `libros` SET `id_autor` = 13, `titulo` = 'El hombre en busca de sentido',
  `descripcion` = 'Viktor Frankl narra su experiencia en los campos de concentración y su teoría logoterapéutica. La obra sostiene que el sentido es la fuerza que permite soportar el sufrimiento.'
WHERE `id_libro` = 31;

UPDATE `libros` SET `id_autor` = 14, `titulo` = 'El monje que vendió su Ferrari',
  `descripcion` = 'Robin Sharma cuenta la transformación de un abogado exitoso que busca equilibrio y sabiduría. A través de un viaje, recibe lecciones sobre la vida, el trabajo y la felicidad.'
WHERE `id_libro` = 32;

UPDATE `libros` SET `id_autor` = 15, `titulo` = 'El poder del ahora',
  `descripcion` = 'Eckhart Tolle enseña a liberarse del sufrimiento mental mediante la atención al momento presente. La obra combina espiritualidad, mindfulness y observación de los pensamientos.'
WHERE `id_libro` = 35;

UPDATE `libros` SET `id_autor` = 16, `titulo` = 'El secreto',
  `descripcion` = 'Rhonda Byrne presenta la ley de la atracción como herramienta para alcanzar metas y bienestar. La obra reúne testimonios y ejercicios sobre visualización y gratitud.'
WHERE `id_libro` = 36;

UPDATE `libros` SET `id_autor` = 17, `titulo` = 'El sutil arte de que te importe un carajo',
  `descripcion` = 'Mark Manson propone elegir con criterio aquello a lo que damos importancia. Su enfoque combina honestidad, aceptación de límites y responsabilidad personal.'
WHERE `id_libro` = 38;

UPDATE `libros` SET `id_autor` = 18, `titulo` = 'Grit: El poder de la pasión y la perseverancia',
  `descripcion` = 'Angela Duckworth investiga por qué la pasión y la perseverancia predicen el éxito. La obra combina estudios y historias para explicar cómo desarrollar la tenacidad.'
WHERE `id_libro` = 43;

UPDATE `libros` SET `id_autor` = 19, `titulo` = 'Mindset: La actitud del éxito',
  `descripcion` = 'Carol S. Dweck distingue entre mentalidad fija y mentalidad de crecimiento. La obra muestra cómo cambiar las creencias sobre la capacidad mejora el aprendizaje y el logro.'
WHERE `id_libro` = 48;

UPDATE `libros` SET `id_autor` = 14, `titulo` = 'El líder que no tenía cargo',
  `descripcion` = 'Robin Sharma plantea que el liderazgo no depende del título sino de la influencia diaria. La historia muestra cómo asumir responsabilidad y servir a los demás.'
WHERE `id_libro` = 53;

UPDATE `libros` SET `id_autor` = 12, `titulo` = 'El 8º hábito',
  `descripcion` = 'Stephen R. Covey sostiene que la grandeza requiere encontrar la propia voz y ayudar a otros a encontrar la suya. El libro aborda el liderazgo y la realización personal en la era del conocimiento.'
WHERE `id_libro` = 57;

UPDATE `libros` SET `id_autor` = 11, `titulo` = 'La ley del éxito',
  `descripcion` = 'Napoleon Hill profundiza en las leyes que rigen el logro personal y la influencia. La obra enseña a alinear pensamiento, acción y propósito para obtener resultados.'
WHERE `id_libro` = 58;

UPDATE `libros` SET `id_autor` = 15, `titulo` = 'Una nueva tierra',
  `descripcion` = 'Eckhart Tolle explora el cambio de conciencia que puede transformar a la persona y a la sociedad. El libro invita a superar el ego y a vivir desde la presencia.'
WHERE `id_libro` = 71;

UPDATE `libros` SET `id_autor` = 17, `titulo` = 'Todo está jodido',
  `descripcion` = 'Mark Manson analiza la esperanza, la muerte y la incertidumbre con humor y crudeza. El libro invita a aceptar el caos y a construir una vida con sentido propio.'
WHERE `id_libro` = 72;

-- ---------------------------------------------------------------------
-- 6. Catálogo: Programación (id_categoria = 3)
-- ---------------------------------------------------------------------
UPDATE `libros` SET `id_autor` = 20, `titulo` = 'Código limpio',
  `descripcion` = 'Robert C. Martin expone principios y prácticas para escribir código legible y mantenible. El libro aborda nombres, funciones, pruebas y diseño con ejemplos concretos.'
WHERE `id_libro` = 1;

UPDATE `libros` SET `id_autor` = 20, `titulo` = 'El arte del código limpio',
  `descripcion` = 'Martin se centra en la profesionalidad del desarrollador y en la excelencia técnica. El libro trata la disciplina, las pruebas y la gestión del tiempo y las estimaciones.'
WHERE `id_libro` = 11;

UPDATE `libros` SET `id_autor` = 20, `titulo` = 'Arquitectura limpia',
  `descripcion` = 'Robert C. Martin propone reglas para diseñar sistemas robustos y desacoplados. El libro conecta principios SOLID, capas y decisiones arquitectónicas sostenibles.'
WHERE `id_libro` = 16;

UPDATE `libros` SET `id_autor` = 21, `titulo` = 'Refactorización',
  `descripcion` = 'Martin Fowler explica cómo mejorar el diseño del código sin cambiar su comportamiento. La obra cataloga técnicas y patrones para reducir la deuda técnica.'
WHERE `id_libro` = 20;

UPDATE `libros` SET `id_autor` = 21, `titulo` = 'Patrones de arquitectura de aplicaciones empresariales',
  `descripcion` = 'Fowler describe soluciones recurrentes para el diseño de sistemas empresariales. El libro organiza patrones de persistencia, lógica de dominio y presentación.'
WHERE `id_libro` = 25;

UPDATE `libros` SET `id_autor` = 22, `titulo` = 'El programador pragmático',
  `descripcion` = 'Andrew Hunt y David Thomas ofrecen hábitos y técnicas para desarrollar software de calidad. La obra cubre responsabilidad, automatización, comunicación y aprendizaje continuo.'
WHERE `id_libro` = 28;

UPDATE `libros` SET `id_autor` = 23, `titulo` = 'El lenguaje de programación C',
  `descripcion` = 'Kernighan y Ritchie presentan el lenguaje C y sus fundamentos con ejemplos concisos. El libro es una referencia clásica para comprender la programación de sistemas.'
WHERE `id_libro` = 33;

UPDATE `libros` SET `id_autor` = 24, `titulo` = 'El lenguaje de programación C++',
  `descripcion` = 'Bjarne Stroustrup explica C++ desde sus fundamentos hasta sus características avanzadas. La obra combina teoría, ejemplos y consejos de diseño.'
WHERE `id_libro` = 39;

UPDATE `libros` SET `id_autor` = 25, `titulo` = 'Java efectivo',
  `descripcion` = 'Joshua Bloch reúne prácticas recomendadas para escribir Java correcto y eficiente. El libro cubre creación de objetos, genéricos, concurrencia y diseño de APIs.'
WHERE `id_libro` = 41;

UPDATE `libros` SET `id_autor` = 26, `titulo` = 'Desarrollo guiado por pruebas',
  `descripcion` = 'Kent Beck introduce el ciclo de prueba, código y refactorización como método de diseño. El libro muestra cómo el TDD mejora la confianza y la calidad del software.'
WHERE `id_libro` = 46;

UPDATE `libros` SET `id_autor` = 26, `titulo` = 'Extreme Programming explicado',
  `descripcion` = 'Kent Beck describe los valores, prácticas y roles de Extreme Programming. La obra explica cómo adaptar el desarrollo ágil a las necesidades del equipo y del cliente.'
WHERE `id_libro` = 47;

UPDATE `libros` SET `id_autor` = 27, `titulo` = 'Domain-Driven Design',
  `descripcion` = 'Eric Evans propone modelar el software a partir del dominio del negocio. El libro introduce el lenguaje ubicuo, los contextos delimitados y los patrones de diseño estratégico.'
WHERE `id_libro` = 50;

UPDATE `libros` SET `id_autor` = 28, `titulo` = 'Código completo',
  `descripcion` = 'Steve McConnell reúne técnicas para construir software de alta calidad. La obra cubre diseño, codificación, pruebas, depuración y mejora del proceso.'
WHERE `id_libro` = 51;

UPDATE `libros` SET `id_autor` = 28, `titulo` = 'Desarrollo rápido de software',
  `descripcion` = 'McConnell presenta prácticas para entregar software en plazos ajustados sin sacrificar calidad. El libro aborda planificación, riesgos y comunicación.'
WHERE `id_libro` = 59;

UPDATE `libros` SET `id_autor` = 29, `titulo` = 'Introducción a los algoritmos',
  `descripcion` = 'Cormen y sus coautores explican el diseño y análisis de algoritmos con rigor matemático. La obra cubre estructuras de datos, grafos, optimización y complejidad.'
WHERE `id_libro` = 65;

UPDATE `libros` SET `id_autor` = 30, `titulo` = 'Estructura e interpretación de programas computacionales',
  `descripcion` = 'Abelson y Sussman enseñan programación mediante Scheme y la abstracción de procesos. El libro explora recursión, evaluación y diseño de lenguajes.'
WHERE `id_libro` = 66;

UPDATE `libros` SET `id_autor` = 31, `titulo` = 'Aprendizaje profundo',
  `descripcion` = 'Ian Goodfellow y sus coautores presentan los fundamentos del deep learning. La obra cubre redes neuronales, optimización, regularización y aplicaciones.'
WHERE `id_libro` = 70;

UPDATE `libros` SET `id_autor` = 32, `titulo` = 'JavaScript: The Definitive Guide',
  `descripcion` = 'David Flanagan ofrece una referencia completa del lenguaje JavaScript y del navegador. El libro cubre sintaxis, objetos, asincronía y APIs modernas.'
WHERE `id_libro` = 77;

UPDATE `libros` SET `id_autor` = 33, `titulo` = 'JavaScript: The Good Parts',
  `descripcion` = 'Douglas Crockford identifica las partes más sólidas y útiles de JavaScript. La obra advierte sobre las trampas del lenguaje y propone un estilo claro y seguro.'
WHERE `id_libro` = 78;

UPDATE `libros` SET `id_autor` = 3, `titulo` = 'Just for Fun',
  `descripcion` = 'Linus Torvalds relata cómo creó Linux y comparte su visión del software libre. El libro mezcla autobiografía, tecnología y reflexiones sobre la colaboración abierta.'
WHERE `id_libro` = 80;

-- ---------------------------------------------------------------------
-- 7. Catálogo: Finanzas (id_categoria = 5)
-- ---------------------------------------------------------------------
UPDATE `libros` SET `id_autor` = 1, `titulo` = 'Padre Rico, Padre Pobre',
  `descripcion` = 'Robert Kiyosaki contrasta dos mentalidades sobre el dinero y la inversión. El libro propone educarse financieramente y construir activos en lugar de depender de un salario.'
WHERE `id_libro` = 4;

UPDATE `libros` SET `id_autor` = 1, `titulo` = 'El cuadrante del flujo del dinero',
  `descripcion` = 'Kiyosaki clasifica las formas de generar ingresos en cuatro cuadrantes. La obra invita a pasar de empleado o autoempleado a dueño de negocio e inversor.'
WHERE `id_libro` = 5;

UPDATE `libros` SET `id_autor` = 1, `titulo` = 'Guía para invertir de Padre Rico',
  `descripcion` = 'Kiyosaki explica cómo pensar como inversor y evaluar oportunidades. El libro aborda activos, riesgo, apalancamiento y educación financiera.'
WHERE `id_libro` = 18;

UPDATE `libros` SET `id_autor` = 1, `titulo` = 'La escuela de negocios',
  `descripcion` = 'Kiyosaki reúne lecciones sobre negocios, ventas y liderazgo. La obra sostiene que la experiencia y la formación práctica superan al título académico.'
WHERE `id_libro` = 26;

UPDATE `libros` SET `id_autor` = 34, `titulo` = 'El inversor inteligente',
  `descripcion` = 'Benjamin Graham propone un método de inversión basado en el valor y el margen de seguridad. El libro distingue entre inversión y especulación y aconseja disciplina.'
WHERE `id_libro` = 29;

UPDATE `libros` SET `id_autor` = 34, `titulo` = 'Security Analysis',
  `descripcion` = 'Graham y Dodd analizan los fundamentos de las empresas y los valores. La obra es un clásico del análisis financiero y de la inversión en valor.'
WHERE `id_libro` = 30;

UPDATE `libros` SET `id_autor` = 34, `titulo` = 'La interpretación de los estados financieros',
  `descripcion` = 'Benjamin Graham enseña a leer balances y cuentas de resultados. El libro ayuda a evaluar la salud financiera de una empresa antes de invertir.'
WHERE `id_libro` = 40;

UPDATE `libros` SET `id_autor` = 35, `titulo` = 'Un paseo aleatorio por Wall Street',
  `descripcion` = 'Burton G. Malkiel cuestiona la capacidad de predecir el mercado y defiende la diversificación. La obra explica la inversión indexada y los costos de las decisiones.'
WHERE `id_libro` = 44;

UPDATE `libros` SET `id_autor` = 36, `titulo` = 'Principios de finanzas corporativas',
  `descripcion` = 'Brealey, Myers y Allen explican la toma de decisiones financieras en la empresa. El libro cubre valoración, riesgo, financiamiento y política de dividendos.'
WHERE `id_libro` = 67;

UPDATE `libros` SET `id_autor` = 37, `titulo` = 'Valoración: Medición y gestión del valor',
  `descripcion` = 'Copeland, Koller y Murrin presentan métodos para valorar empresas y medir su creación de valor. La obra combina teoría financiera y aplicación práctica.'
WHERE `id_libro` = 69;

UPDATE `libros` SET `id_autor` = 38, `titulo` = 'El cisne negro',
  `descripcion` = 'Nassim Nicholas Taleb analiza el impacto de los eventos improbables y extremos. La obra critica los modelos que subestiman la incertidumbre y propone reforzar la resiliencia.'
WHERE `id_libro` = 76;

UPDATE `libros` SET `id_autor` = 38, `titulo` = 'Antifrágil',
  `descripcion` = 'Taleb explora los sistemas que se benefician del caos y la volatilidad. El libro propone diseñar personas y organizaciones capaces de mejorar ante la adversidad.'
WHERE `id_libro` = 79;

COMMIT;
